<?php
include 'db.php';

 // Mengecek apakah ada parameter 'id' pada URL
if (isset($_GET['id'])) {
    //  Menyimpan ID penjualan yang diterima dari URL
    $id = $_GET['id'];
    // Ambil informasi utama penjualan (termasuk pelanggan)
    $sqlPenjualan = "
        SELECT p.PenjualanID, p.TanggalPenjualan, p.TotalHarga, 
               pl.NamaPelanggan 
        FROM penjualan p
        JOIN pelanggan pl ON p.PelangganID = pl.PelangganID
        WHERE p.PenjualanID = ?";
    
     //  Menyiapkan query dan mengikat parameter 'id' untuk menghindari SQL injection
     $stmt = $conn->prepare($sqlPenjualan);
     $stmt->bind_param("i", $id);  // Parameter 'i' menunjukkan tipe data integer untuk ID
     $stmt->execute();  // Menjalankan query
     $resultPenjualan = $stmt->get_result();  // Mendapatkan hasil query
     $dataPenjualan = $resultPenjualan->fetch_assoc();  // Mengambil data hasil query ke dalam array asosiasi
     $stmt->close();  // Menutup statement query setelah digunakan

    // Ambil detail produk dalam transaksi, termasuk harga satuan
    $sqlDetail = "
        SELECT dp.DetailID, pr.NamaProduk, pr.Harga, dp.JumlahProduk, 
               (dp.JumlahProduk * pr.Harga) AS Subtotal
        FROM detailpenjualan dp
        JOIN produk pr ON dp.ProdukID = pr.ProdukID
        WHERE dp.PenjualanID = ?";

    $stmt = $conn->prepare($sqlDetail);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultDetail = $stmt->get_result();
    $stmt->close();
} else {
    echo "ID Penjualan tidak ditemukan!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="container">
    <h2>Detail Penjualan</h2>

    <div class="info-container">
        <p><strong>ID Penjualan:</strong> <?= $dataPenjualan['PenjualanID'] ?></p>
        <p><strong>Tanggal:</strong> <?= $dataPenjualan['TanggalPenjualan'] ?></p>
        <p><strong>Pelanggan:</strong> <?= $dataPenjualan['NamaPelanggan'] ?></p>
        <p><strong>Total Harga:</strong> Rp <?= number_format($dataPenjualan['TotalHarga'], 2) ?></p>
    </div>

    <h3>Produk yang Dibeli</h3>

    <div class="table-container">
        <table>
            <tr>
                <th>Nama Produk</th>
                <th>Harga Satuan</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
            </tr>
            <?php while ($row = $resultDetail->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['NamaProduk'] ?></td>
                    <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                    <td><?= $row['JumlahProduk'] ?></td>
                    <td>Rp <?= number_format($row['Subtotal'], 2) ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <div class="button-container">
        <a href="penjualan.php"><button class="back-button">Kembali</button></a>
    </div>
</div>

</body>
</html>

