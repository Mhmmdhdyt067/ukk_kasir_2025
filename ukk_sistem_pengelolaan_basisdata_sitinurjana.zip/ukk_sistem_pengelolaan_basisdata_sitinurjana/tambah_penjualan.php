<?php 
include 'db.php';  // Mengimpor koneksi ke database dari file db.php

//  Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);  // Mengecek apakah koneksi ke database berhasil
}

//  Proses Tambah Penjualan
if (isset($_POST['tambah'])) {  // Mengecek apakah form telah disubmit
    $pelangganID = $_POST['PelangganID'];  // Menyimpan ID pelanggan dari form
    $tanggal = $_POST['TanggalPenjualan'];  // Menyimpan tanggal penjualan dari form
    $produkID = $_POST['ProdukID'];  // Menyimpan ID produk dari form
    $jumlah = $_POST['Jumlah'];  // Menyimpan jumlah produk yang dibeli dari form

    //  Ambil harga dan stok produk dari database
    $sqlProduk = "SELECT Harga, Stok FROM produk WHERE ProdukID = ?";  // Query untuk mengambil harga dan stok produk berdasarkan ID
    if (!$stmt = $conn->prepare($sqlProduk)) {
        die("Error SQL (Ambil Harga dan Stok): " . $conn->error);  // Menangani kesalahan jika query gagal
    }
    
    $stmt->bind_param("i", $produkID);  // Mengikat parameter untuk query
    $stmt->execute();  // Mengeksekusi query
    $stmt->bind_result($hargaSatuan, $stok);  // Mengambil hasil query (harga dan stok)
    $stmt->fetch();  // Mengambil data hasil query
    $stmt->close();

    //  Periksa apakah produk ditemukan
    if ($hargaSatuan === null) {  // Jika produk tidak ditemukan (hargaSatuan bernilai null)
        die("Produk tidak ditemukan atau query gagal.");
    }

    //  Periksa apakah stok mencukupi
    if ($jumlah > $stok) {  // Jika jumlah yang diminta lebih besar dari stok yang tersedia
        echo "<script>
                alert('Stok tidak mencukupi! Hanya tersedia $stok unit.');  // Menampilkan pesan jika stok tidak mencukupi
                window.location.href='tambah_penjualan.php';  // Redirect ke halaman tambah penjualan
              </script>";
        exit;  // Menghentikan eksekusi lebih lanjut
    }

    $totalHarga = $hargaSatuan * $jumlah;  // Menghitung total harga berdasarkan jumlah dan harga satuan produk

    //  Masukkan data ke tabel penjualan
    $sqlInsertPenjualan = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) VALUES (?, ?, ?)";  // Query untuk memasukkan data penjualan
    if (!$stmt = $conn->prepare($sqlInsertPenjualan)) {
        die("Error SQL (Insert Penjualan): " . $conn->error);  // Menangani kesalahan jika query gagal
    }
    $stmt->bind_param("sid", $tanggal, $pelangganID, $totalHarga);  // Mengikat parameter untuk query
    if (!$stmt->execute()) {  // Mengeksekusi query
        die("Error Execute (Insert Penjualan): " . $stmt->error);  // Menangani kesalahan eksekusi query
    }
    $penjualanID = $stmt->insert_id;  // Mendapatkan ID penjualan yang baru saja dimasukkan
    $stmt->close();

    //  Masukkan data ke tabel detailpenjualan
    $sqlInsertDetail = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) VALUES (?, ?, ?, ?)";  // Query untuk memasukkan data detail penjualan
    if (!$stmt = $conn->prepare($sqlInsertDetail)) {
        die("Error SQL (Insert Detail Penjualan): " . $conn->error);  // Menangani kesalahan jika query gagal
    }
    $stmt->bind_param("iiid", $penjualanID, $produkID, $jumlah, $totalHarga);  // Mengikat parameter untuk query
    if (!$stmt->execute()) {  // Mengeksekusi query
        die("Error Execute (Insert Detail Penjualan): " . $stmt->error);  // Menangani kesalahan eksekusi query
    }
    $stmt->close();

    //  Update stok produk
    $sqlUpdateStok = "UPDATE produk SET Stok = Stok - ? WHERE ProdukID = ?";  // Query untuk memperbarui stok produk
    if (!$stmt = $conn->prepare($sqlUpdateStok)) {
        die("Error SQL (Update Stok): " . $conn->error);  // Menangani kesalahan jika query gagal
    }
    $stmt->bind_param("ii", $jumlah, $produkID);  // Mengikat parameter untuk query
    if (!$stmt->execute()) {  // Mengeksekusi query
        die("Error Execute (Update Stok): " . $stmt->error);  // Menangani kesalahan eksekusi query
    }
    $stmt->close();

    // Redirect kembali ke halaman penjualan
    header("Location: penjualan.php?msg=Penjualan berhasil ditambahkan");  // Redirect ke halaman penjualan dengan pesan sukses
    exit;
}


// Ambil daftar pelanggan dari database
$sqlPelanggan = "SELECT * FROM pelanggan";  // Query untuk mengambil daftar pelanggan
$resultPelanggan = $conn->query($sqlPelanggan);  // Menjalankan query untuk mendapatkan hasil pelanggan

//  Ambil daftar produk dari database
$sqlProduk = "SELECT * FROM produk WHERE Stok > 0";  // Query untuk mengambil daftar produk yang memiliki stok lebih dari 0
$resultProduk = $conn->query($sqlProduk);  // Menjalankan query untuk mendapatkan hasil produk
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Tambah Penjualan</title>
    <link rel="stylesheet" type="text/css" href="style.css">  <!-- Link ke file CSS untuk styling -->
</head>
<body>

<div class="form-container">
    <h2>Tambah Penjualan</h2>

    <form method="POST">
        <!-- Input untuk tanggal penjualan -->
        <div class="form-group">
            <label>Tanggal Penjualan:</label>
            <input type="date" name="TanggalPenjualan" required>  <!-- Input untuk memilih tanggal -->
        </div>

        <!-- Dropdown untuk memilih pelanggan -->
        <div class="form-group">
            <label>Pelanggan:</label>
            <select name="PelangganID" required>
                <option value="">Pilih Pelanggan</option>
                <?php while ($row = $resultPelanggan->fetch_assoc()) : ?>
                    <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Dropdown untuk memilih produk -->
        <div class="form-group">
            <label>Produk:</label>
            <select name="ProdukID" required>
                <option value="">Pilih Produk</option>
                <?php while ($row = $resultProduk->fetch_assoc()) : ?>
                    <option value="<?= $row['ProdukID'] ?>"><?= $row['NamaProduk'] ?> - Rp <?= number_format($row['Harga'], 2) ?> (Stok: <?= $row['Stok'] ?>)</option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Input untuk jumlah produk yang dibeli -->
        <div class="form-group">
            <label>Jumlah:</label>
            <input type="number" name="Jumlah" min="1" required>  <!-- Input untuk jumlah produk -->
        </div>

        <!-- Tombol untuk submit dan tombol kembali -->
        <div class="button-container">
            <button type="submit" name="tambah" class="submit-button">Tambah</button>
            <a href="penjualan.php"><button type="button" class="back-button">Kembali</button></a>
        </div>
    </form>
</div>

</body>
</html>
