<?php
include 'db.php';  // Mengimpor koneksi database dari db.php

// Mengecek apakah form disubmit menggunakan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data yang dikirimkan melalui form
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    // Menyusun query untuk memasukkan data pelanggan ke dalam database
    $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);  // Menyiapkan query untuk dieksekusi
    $stmt->bind_param("sss", $nama, $alamat, $telepon);  // Mengikat parameter yang akan dimasukkan ke dalam query

    // Mengeksekusi query dan menampilkan pesan sukses atau error
    if ($stmt->execute()) {
        echo "<script>alert('Pelanggan berhasil ditambahkan!'); window.location.href='pelanggan.php';</script>";  // Pesan sukses dan redirect ke halaman pelanggan
    } else {
        echo "Error: " . $conn->error;  // Menampilkan pesan error jika query gagal
    }
    $stmt->close();  // Menutup statement
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Tambah Pelanggan</title>  <!-- Judul halaman -->
    <link rel="stylesheet" type="text/css" href="style.css">  <!-- Link ke file CSS untuk styling -->
</head>

<body>
<div class="form-container">  <!-- Container untuk form -->
    <h2>Tambah Pelanggan</h2>  <!-- Judul untuk form tambah pelanggan -->
    <form action="tambah_pelanggan.php" method="POST">  <!-- Form untuk menambah pelanggan, mengirim data menggunakan POST -->
        <!-- Input untuk nama pelanggan -->
        <div class="form-group">
            <label for="nama">Nama Pelanggan:</label>
            <input type="text" id="nama" name="nama" required>  <!-- Input untuk nama pelanggan, wajib diisi -->
        </div>
        
        <!-- Input untuk alamat pelanggan -->
        <div class="form-group">
            <label for="alamat">Alamat:</label>
            <input type="text" id="alamat" name="alamat" required>  <!-- Input untuk alamat pelanggan, wajib diisi -->
        </div>

        <!-- Input untuk nomor telepon pelanggan -->
        <div class="form-group">
            <label for="telepon">Nomor Telepon:</label>
            <input type="text" id="telepon" name="telepon" required>  <!-- Input untuk nomor telepon pelanggan, wajib diisi -->
        </div>

        <!-- Tombol untuk submit form dan tombol untuk kembali ke halaman pelanggan -->
        <div class="button-container">
            <button type="submit" class="add-button">Tambah</button>  <!-- Tombol untuk menambah pelanggan -->
            <a href="pelanggan.php"><button type="button" class="back-button">Kembali</button></a>  <!-- Tombol untuk kembali ke halaman pelanggan -->
        </div>
    </form>
</div>

</body>
</html>
