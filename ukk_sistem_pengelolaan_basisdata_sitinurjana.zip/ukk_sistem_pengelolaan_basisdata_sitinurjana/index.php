<?php
include 'db.php';

// Menghitung jumlah pelanggan
$result_pelanggan = $conn->query ("SELECT COUNT(*) as total FROM pelanggan");
$jumlah_pelanggan = $result_pelanggan->fetch_assoc()['total'];

// Menghitung jumlah produk
$result_produk = $conn->query("SELECT COUNT(*) as total FROM produk");
$jumlah_produk = $result_produk->fetch_assoc()['total'];

// Menghitung jumlah transaksi
$result_transaksi = $conn->query("SELECT COUNT(*) as total FROM penjualan");
$jumlah_transaksi = $result_transaksi->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Manajemen Transaksi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <h1>Dashboard Manajemen Transaksi</h1>

        <div class="navbar">
            <a href="pelanggan.php">Kelola Pelanggan</a>
            <a href="produk.php">Kelola Produk</a>
            <a href="penjualan.php">Kelola Transaksi</a>
        </div>

        <div class="card-container">
            <div class="card">
                <h3>Jumlah Pelanggan</h3>
                <p><?= $jumlah_pelanggan; ?></p>
            </div>

            <div class="card">
                <h3>Jumlah Produk</h3>
                <p><?= $jumlah_produk; ?></p>
            </div>

            <div class="card">
                <h3>Jumlah Transaksi</h3>
                <p><?= $jumlah_transaksi; ?></p>
            </div>
        </div>
    </div>

</body>
</html>
