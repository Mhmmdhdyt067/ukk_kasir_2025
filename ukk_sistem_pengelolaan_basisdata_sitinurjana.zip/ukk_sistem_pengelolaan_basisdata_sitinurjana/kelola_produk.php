<?php
include 'db.php'; // Mengimpor file db.php yang berisi konfigurasi koneksi database

//  Ambil ID dari URL
if (isset($_GET['id'])) { 
    $id = $_GET['id']; // Menyimpan ID produk dari URL
}

//  Proses Hapus Produk
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') { // Mengecek apakah aksi yang diminta adalah 'hapus'
    // Mengecek apakah produk sudah digunakan dalam transaksi (detailpenjualan)
    $cekDetail = "SELECT * FROM detailpenjualan WHERE ProdukID = ?"; 
    $stmt = $conn->prepare($cekDetail); // Menyiapkan query untuk mengecek penggunaan produk
    $stmt->bind_param("i", $id); // Mengikat parameter ID produk untuk query
    $stmt->execute(); // Menjalankan query
    $result = $stmt->get_result(); // Mengambil hasil query
    $stmt->close(); // Menutup statement

    // Jika produk digunakan dalam transaksi (detailpenjualan), tampilkan pesan
    if ($result->num_rows > 0) { 
        echo "<script>
                alert('Produk tidak dapat dihapus karena telah digunakan dalam transaksi!'); // Menampilkan alert
                window.location.href = 'produk.php'; // Mengarahkan kembali ke halaman produk
              </script>";
        exit; // Menghentikan eksekusi lebih lanjut
    }

    // Jika produk tidak digunakan dalam transaksi, hapus dari tabel produk
    $sqlDelete = "DELETE FROM produk WHERE ProdukID = ?"; 
    $stmt = $conn->prepare($sqlDelete); // Menyiapkan query untuk menghapus produk
    $stmt->bind_param("i", $id); // Mengikat parameter ID produk untuk query
    $stmt->execute(); // Menjalankan query
    $stmt->close(); // Menutup statement

    header("Location: produk.php?msg=Produk berhasil dihapus"); // Redirect setelah berhasil menghapus produk
    exit; // Menghentikan eksekusi lebih lanjut
}

//  Proses Ambil Data untuk Edit
if (isset($_GET['aksi']) && $_GET['aksi'] == 'edit') { // Mengecek apakah aksi yang diminta adalah 'edit'
    $sql = "SELECT * FROM produk WHERE ProdukID = ?"; // Query untuk mengambil data produk berdasarkan ID
    $stmt = $conn->prepare($sql); // Menyiapkan query
    $stmt->bind_param("i", $id); // Mengikat parameter ID produk untuk query
    $stmt->execute(); // Menjalankan query
    $result = $stmt->get_result(); // Mengambil hasil query
    $stmt->close(); // Menutup statement

    // Jika data produk ditemukan, simpan hasilnya dalam variabel $row
    if ($result->num_rows > 0) { 
        $row = $result->fetch_assoc(); // Mengambil data produk dalam bentuk array asosiatif
    } else {
        echo "Produk tidak ditemukan!"; // Jika produk tidak ditemukan
        exit; // Menghentikan eksekusi lebih lanjut
    }
}

//  Proses Update Produk
if (isset($_POST['update'])) { // Mengecek apakah form update sudah disubmit
    $nama = $_POST['NamaProduk']; // Menyimpan nama produk yang diinput
    $harga = $_POST['Harga']; // Menyimpan harga produk yang diinput
    $stok = $_POST['Stok']; // Menyimpan stok produk yang diinput

    // Query untuk memperbarui data produk di tabel produk
    $sqlUpdate = "UPDATE produk SET NamaProduk=?, Harga=?, Stok=? WHERE ProdukID=?"; 
    $stmt = $conn->prepare($sqlUpdate); // Menyiapkan query update
    $stmt->bind_param("sdii", $nama, $harga, $stok, $id); // Mengikat parameter ke query
    $stmt->execute(); // Menjalankan query
    $stmt->close(); // Menutup statement

    header("Location: produk.php?msg=Produk berhasil diperbarui"); // Redirect setelah berhasil memperbarui produk
    exit; // Menghentikan eksekusi lebih lanjut
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" type="text/css" href="style.css"> <!-- Link ke CSS -->
</head>
<body>

<?php if (isset($_GET['aksi']) && $_GET['aksi'] == 'edit') : ?>
    <div class="form-container">
    <h2>Edit Produk</h2>
    <form method="POST">
        <div class="form-group">
            <label>Nama Produk:</label>
            <input type="text" name="NamaProduk" value="<?= $row['NamaProduk'] ?>" required>
        </div>

        <div class="form-group">
            <label>Harga:</label>
            <input type="number" step="0.01" name="Harga" value="<?= $row['Harga'] ?>" required>
        </div>

        <div class="form-group">
            <label>Stok:</label>
            <input type="number" name="Stok" value="<?= $row['Stok'] ?>" required>
        </div>

        <div class="button-container">
            <button type="submit" name="update" class="update-button">Update</button>
            <a href="produk.php" class="back-button">Kembali</a>
        </div>
    </form>
</div>
<?php endif; ?>

</body>
</html>
