<?php include 'db.php'; ?> <!-- Mengimpor file koneksi database db.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title> <!-- Judul halaman -->
    <link rel="stylesheet" type="text/css" href="style.css"> <!-- Mengimpor file CSS untuk styling -->
</head>
<body>
    <h2>Data Pelanggan</h2> <!-- Judul utama halaman -->

    <!--  Form Pencarian -->
    <div class="search-container">
        <form method="GET" class="search-form"> <!-- Form untuk melakukan pencarian berdasarkan nama, alamat, atau nomor telepon -->
            <input type="text" name="search" placeholder="Cari Pelanggan" 
                   value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>"> <!-- Menampilkan nilai pencarian yang dimasukkan sebelumnya jika ada -->
            <button type="submit">Cari</button> <!-- Tombol untuk mengirimkan form pencarian -->
            <a href="pelanggan.php"><button type="button">Reset</button></a> <!-- Tombol untuk mereset pencarian dan kembali ke halaman pelanggan -->
        </form>
    </div>

    <!--  Tombol Kembali & Tambah Pelanggan-->
    <div class="button-container">
        <a href="index.php">
            <button class="back-button">Kembali</button> <!-- Tombol untuk kembali ke halaman utama -->
        </a>
        <a href="tambah_pelanggan.php">
            <button class="add-button">Tambah Pelanggan</button> <!-- Tombol untuk menambah pelanggan baru -->
        </a>
    </div>

    <!--  Tabel Data Pelanggan -->
    <div class="table-container">
        <table border="1">
            <tr>
                <th>ID</th> <!-- Kolom untuk ID pelanggan -->
                <th>Nama</th> <!-- Kolom untuk Nama pelanggan -->
                <th>Alamat</th> <!-- Kolom untuk Alamat pelanggan -->
                <th>Nomor Telepon</th> <!-- Kolom untuk Nomor Telepon pelanggan -->
                <th>Aksi</th> <!-- Kolom untuk aksi yang bisa dilakukan pada data pelanggan -->
            </tr>

            <?php
            include 'db.php'; // Mengimpor koneksi database

            //  Query dengan fitur pencarian
            $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : "%"; // Menyiapkan nilai pencarian
            $sql = "SELECT * FROM pelanggan WHERE NamaPelanggan LIKE ? OR Alamat LIKE ? OR NomorTelepon LIKE ?"; // Query untuk mencari pelanggan berdasarkan nama, alamat, atau nomor telepon
            $stmt = $conn->prepare($sql); // Menyiapkan statement untuk query
            $stmt->bind_param("sss", $search, $search, $search); // Mengikat parameter pencarian ke query
            $stmt->execute(); // Menjalankan query
            $result = $stmt->get_result(); // Mengambil hasil query

            // Loop untuk menampilkan data pelanggan dalam tabel
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['PelangganID']}</td> <!-- Menampilkan ID Pelanggan -->
                    <td>{$row['NamaPelanggan']}</td> <!-- Menampilkan Nama Pelanggan -->
                    <td>{$row['Alamat']}</td> <!-- Menampilkan Alamat Pelanggan -->
                    <td>{$row['NomorTelepon']}</td> <!-- Menampilkan Nomor Telepon Pelanggan -->
                    <td>
                        <a href='kelola_pelanggan.php?id={$row['PelangganID']}&aksi=edit'><button>Edit</button></a> <!-- Link untuk mengedit data pelanggan -->
                        <a href='kelola_pelanggan.php?id={$row['PelangganID']}&aksi=hapus' 
                           onclick='return confirm(\"Apakah Anda yakin ingin menghapus pelanggan ini?\")'>
                           <button>Hapus</button> <!-- Link untuk menghapus pelanggan dengan konfirmasi -->
                        </a>
                    </td>
                </tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>
