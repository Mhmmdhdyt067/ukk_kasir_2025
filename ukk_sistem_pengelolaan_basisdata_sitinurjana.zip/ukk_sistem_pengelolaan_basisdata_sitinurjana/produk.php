<?php include 'db.php'; ?> <!-- Mengimpor koneksi database dari db.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Data Produk</title> <!-- Judul halaman -->
    <link rel="stylesheet" type="text/css" href="style.css"> <!-- Link ke file CSS untuk styling -->
</head>
<body>
    <h2>Data Produk</h2> <!-- Judul utama halaman -->

    <!--  Form Pencarian -->
    <div class="search-container">
        <form method="GET" class="search-form"> <!-- Form untuk pencarian produk -->
            <input type="text" name="search" placeholder="Cari Produk" 
                   value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>"> <!-- Menampilkan nilai pencarian jika ada -->
            <button type="submit">Cari</button> <!-- Tombol untuk mengirimkan form pencarian -->
            <a href="produk.php"><button type="button">Reset</button></a> <!-- Tombol untuk mereset pencarian -->
        </form>
    </div>

    <!--  Tombol Kembali & Tambah Produk -->
    <div class="button-container">
        <a href="index.php">
            <button class="back-button">Kembali</button> <!-- Tombol untuk kembali ke halaman utama -->
        </a>
        <a href="tambah_produk.php">
            <button class="add-button">Tambah Produk</button> <!-- Tombol untuk menambah produk baru -->
        </a>
    </div>

    <!--  Tabel Data Produk -->
    <div class="table-container">
        <table border="1"> <!-- Menampilkan tabel produk dengan border -->
            <tr>
                <th>ID</th> <!-- Kolom untuk ID Produk -->
                <th>Nama Produk</th> <!-- Kolom untuk Nama Produk -->
                <th>Harga</th> <!-- Kolom untuk Harga Produk -->
                <th>Stok</th> <!-- Kolom untuk Stok Produk -->
                <th>Aksi</th> <!-- Kolom untuk aksi (Edit dan Hapus) -->
            </tr>

            <?php
            include 'db.php'; // Mengimpor koneksi database dari db.php

            // Query dengan fitur pencarian
            $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : "%"; // Menangkap nilai pencarian
            $sql = "SELECT * FROM produk WHERE NamaProduk LIKE ?"; // Query untuk mencari produk berdasarkan nama
            $stmt = $conn->prepare($sql); // Menyiapkan statement SQL
            $stmt->bind_param("s", $search); // Mengikat parameter pencarian
            $stmt->execute(); // Menjalankan query
            $result = $stmt->get_result(); // Mendapatkan hasil query

            // Menampilkan hasil pencarian dalam bentuk tabel
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['ProdukID']}</td> <!-- Menampilkan ID Produk -->
                    <td>{$row['NamaProduk']}</td> <!-- Menampilkan Nama Produk -->
                    <td>Rp " . number_format($row['Harga'], 2) . "</td> <!-- Menampilkan Harga Produk dalam format Rp -->
                    <td>{$row['Stok']}</td> <!-- Menampilkan Stok Produk -->
                    <td>
                        <a href='kelola_produk.php?id={$row['ProdukID']}&aksi=edit'><button>Edit</button></a> <!-- Tombol untuk mengedit produk -->
                        <a href='kelola_produk.php?id={$row['ProdukID']}&aksi=hapus' 
                           onclick='return confirm(\"Apakah Anda yakin ingin menghapus produk ini?\")'>
                           <button>Hapus</button> <!-- Tombol untuk menghapus produk dengan konfirmasi -->
                        </a>
                    </td>
                </tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>
