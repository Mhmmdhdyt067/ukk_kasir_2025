<?php 
include 'db.php'; // Mengimpor koneksi database dari db.php

//  Proses Hapus Penjualan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus']; // Mendapatkan ID penjualan yang akan dihapus

    // Hapus data yang terkait di tabel detailpenjualan
    $sqlDeleteDetail = "DELETE FROM detailpenjualan WHERE PenjualanID = ?"; // Query untuk menghapus data di detailpenjualan
    $stmt = $conn->prepare($sqlDeleteDetail); // Menyiapkan statement
    $stmt->bind_param("i", $id); // Mengikat parameter ID
    $stmt->execute(); // Menjalankan query
    $stmt->close(); // Menutup statement

    // Hapus data di tabel penjualan
    $sqlDeletePenjualan = "DELETE FROM penjualan WHERE PenjualanID = ?"; // Query untuk menghapus data penjualan
    $stmt = $conn->prepare($sqlDeletePenjualan); // Menyiapkan statement
    $stmt->bind_param("i", $id); // Mengikat parameter ID
    $stmt->execute(); // Menjalankan query
    $stmt->close(); // Menutup statement

    // Redirect ke halaman penjualan dengan pesan bahwa data berhasil dihapus
    header("Location: penjualan.php?msg=Data berhasil dihapus");
    exit; // Menghentikan eksekusi lebih lanjut
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Data Penjualan</title> <!-- Judul halaman -->
    <link rel="stylesheet" type="text/css" href="style.css"> <!-- Link ke file CSS untuk styling -->
</head>
<body>

<h2>Data Penjualan</h2> <!-- Judul utama halaman -->

<!--  Form Pencarian -->
<div class="search-container">
    <form method="GET" class="search-form"> <!-- Form untuk pencarian berdasarkan tanggal penjualan -->
        <input type="text" name="search" placeholder="Cari Tanggal" value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>"> <!-- Menampilkan nilai pencarian jika ada -->
        <button type="submit">Cari</button> <!-- Tombol untuk mengirimkan form pencarian -->
        <a href="penjualan.php"><button type="button">Reset</button></a> <!-- Tombol untuk mereset pencarian -->
    </form>
</div>

<!--  Tombol Kembali & Tambah Penjualan -->
<div class="button-container">
    <a href="index.php">
        <button class="back-button">Kembali</button> <!-- Tombol untuk kembali ke halaman utama -->
    </a>
    <a href="tambah_penjualan.php">
        <button class="add-button">Tambah Penjualan</button> <!-- Tombol untuk menambah penjualan baru -->
    </a>
</div>

<!--  Tabel Data Penjualan -->
<div class="table-container">
    <table>
        <tr>
            <th>ID</th> <!-- Kolom untuk ID Penjualan -->
            <th>Tanggal</th> <!-- Kolom untuk Tanggal Penjualan -->
            <th>Pelanggan</th> <!-- Kolom untuk Nama Pelanggan -->
            <th>Total Harga</th> <!-- Kolom untuk Total Harga -->
            <th>Aksi</th> <!-- Kolom untuk aksi (Detail dan Hapus) -->
        </tr>

        <?php
        //  Proses Pencarian Data
        $search = isset($_GET['search']) ? $_GET['search'] : ''; // Menyimpan nilai pencarian
        $sql = "SELECT penjualan.*, pelanggan.NamaPelanggan 
                FROM penjualan 
                JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID 
                WHERE TanggalPenjualan LIKE '%$search%'"; // Query untuk mencari data penjualan berdasarkan tanggal
        $result = $conn->query($sql); // Menjalankan query dan menyimpan hasilnya

        // Menampilkan data penjualan dalam bentuk tabel
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['PenjualanID']}</td> <!-- Menampilkan ID Penjualan -->
                <td>{$row['TanggalPenjualan']}</td> <!-- Menampilkan Tanggal Penjualan -->
                <td>{$row['NamaPelanggan']}</td> <!-- Menampilkan Nama Pelanggan -->
                <td>Rp " . number_format($row['TotalHarga'], 2) . "</td> <!-- Menampilkan Total Harga dalam format Rp -->
                <td>
                    <a href='detail_penjualan.php?id={$row['PenjualanID']}'><button>Detail</button></a> <!-- Tombol untuk melihat detail penjualan -->
                    <a href='penjualan.php?hapus={$row['PenjualanID']}' onclick='return confirm(\"Yakin ingin menghapus transaksi ini?\")'>
                        <button>Hapus</button> <!-- Tombol untuk menghapus penjualan dengan konfirmasi -->
                    </a>
                </td>
            </tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
