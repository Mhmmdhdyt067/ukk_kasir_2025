<?php
//  Menghubungkan ke file 'db.php' yang berisi kode untuk menghubungkan ke database
include 'db.php';

//  Mengambil ID pelanggan dari URL (jika ada)
if (isset($_GET['id'])) {
    $id = $_GET['id'];  // Menyimpan ID pelanggan yang diterima dari URL
}

//  Proses Hapus Pelanggan
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus') {
    //  Mengecek apakah pelanggan memiliki transaksi yang terkait dengan ID ini
    $cekPenjualan = "SELECT * FROM penjualan WHERE PelangganID = ?";
    $stmt = $conn->prepare($cekPenjualan);
    $stmt->bind_param("i", $id);  // Mengikat parameter ID pelanggan
    $stmt->execute();
    $result = $stmt->get_result();  // Menjalankan query dan mendapatkan hasil
    $stmt->close();

    //  Jika pelanggan memiliki transaksi, tampilkan peringatan dan hentikan eksekusi
    if ($result->num_rows > 0) {
        echo "<script>
                alert('Pelanggan tidak dapat dihapus karena memiliki transaksi!');
                window.location.href = 'pelanggan.php';
              </script>";
        exit;  // Menghentikan eksekusi skrip setelah peringatan
    }

    //  Jika pelanggan tidak memiliki transaksi, hapus data pelanggan dari database
    $sqlDelete = "DELETE FROM pelanggan WHERE PelangganID = ?";
    $stmt = $conn->prepare($sqlDelete);
    $stmt->bind_param("i", $id);  // Mengikat parameter ID pelanggan
    $stmt->execute();  // Menjalankan query penghapusan
    $stmt->close();

    //  Setelah berhasil menghapus, arahkan kembali ke halaman pelanggan dengan pesan berhasil
    header("Location: pelanggan.php?msg=Pelanggan berhasil dihapus");
    exit;  // Menghentikan eksekusi setelah redirect
}

//  Proses Ambil Data untuk Edit
if (isset($_GET['aksi']) && $_GET['aksi'] == 'edit') {
    //  SQL query untuk mengambil data pelanggan yang ingin diedit berdasarkan ID
    $sql = "SELECT * FROM pelanggan WHERE PelangganID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);  // Mengikat parameter ID pelanggan
    $stmt->execute();  // Menjalankan query
    $result = $stmt->get_result();  // Mendapatkan hasil query
    $stmt->close();

    //  Mengecek apakah data pelanggan ditemukan, jika tidak, tampilkan pesan error
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();  // Menyimpan hasil query ke dalam array asosiasi
    } else {
        echo "Pelanggan tidak ditemukan!";
        exit;  // Menghentikan eksekusi jika pelanggan tidak ditemukan
    }
}

//  Proses Update Pelanggan
if (isset($_POST['update'])) {
    //  Menyimpan data yang dikirimkan dari form ke variabel
    $nama = $_POST['NamaPelanggan'];
    $alamat = $_POST['Alamat'];
    $telepon = $_POST['NomorTelepon'];

    //  SQL query untuk memperbarui data pelanggan
    $sqlUpdate = "UPDATE pelanggan SET NamaPelanggan=?, Alamat=?, NomorTelepon=? WHERE PelangganID=?";
    $stmt = $conn->prepare($sqlUpdate);
    $stmt->bind_param("sssi", $nama, $alamat, $telepon, $id);  // Mengikat parameter yang akan diupdate
    $stmt->execute();  // Menjalankan query untuk update
    $stmt->close();

    // Setelah berhasil memperbarui data, arahkan kembali ke halaman pelanggan dengan pesan berhasil
    header("Location: pelanggan.php?msg=Pelanggan berhasil diperbarui");
    exit;  // Menghentikan eksekusi setelah redirect
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pelanggan</title>
    <link rel="stylesheet" type="text/css" href="style.css"> <!-- Link ke CSS -->
</head>
<body>

<?php if (isset($_GET['aksi']) && $_GET['aksi'] == 'edit') : ?>
    <div class="form-container">
    <h2>Update Pelanggan</h2>
    <form method="POST">
        <div class="form-group">
            <label>Nama Pelanggan:</label>
            <input type="text" name="NamaPelanggan" value="<?= $row['NamaPelanggan'] ?>" required>
        </div>

        <div class="form-group">
            <label>Alamat:</label>
            <textarea name="Alamat" required><?= $row['Alamat'] ?></textarea>
        </div>

        <div class="form-group">
            <label>Nomor Telepon:</label>
            <input type="text" name="NomorTelepon" value="<?= $row['NomorTelepon'] ?>" required>
        </div>

        <div class="button-container">
            <button type="submit" name="update" class="update-button">Update</button>
            <a href="pelanggan.php" class="back-button">Kembali</a>
        </div>
    </form>
</div>
<?php endif; ?>

</body>
</html>
