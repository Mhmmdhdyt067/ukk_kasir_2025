<?php
//  Mendefinisikan informasi koneksi ke basis data
$servername = "localhost";  // Nama server database (biasanya "localhost" untuk server lokal)
$username = "root";         // Nama pengguna untuk mengakses database (biasanya "root" untuk XAMPP/WAMP)
$password = "";             // Kata sandi untuk pengguna (kosong jika tidak ada kata sandi untuk pengguna "root")
$dbname = "kasir_ukk_nurjana";  // Nama database yang akan digunakan (disesuaikan dengan nama database Anda)

//  Membuat objek koneksi ke database MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

//  Mengecek apakah terjadi error saat menghubungkan ke database
if ($conn->connect_error) {  // Mengecek apakah terjadi error pada koneksi
    die("Koneksi gagal: " . $conn->connect_error);  // Jika terjadi error, berhenti dan tampilkan pesan error
}
?>
