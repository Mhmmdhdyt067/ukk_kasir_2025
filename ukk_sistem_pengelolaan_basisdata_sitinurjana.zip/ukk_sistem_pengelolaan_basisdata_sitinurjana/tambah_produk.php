<?php
include 'db.php';  // Mengimpor koneksi ke database dari file db.php

// Mengecek apakah form telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];  // Mengambil data nama produk dari form
    $harga = $_POST['harga'];  // Mengambil data harga produk dari form
    $stok = $_POST['stok'];  // Mengambil data stok produk dari form

    // Query untuk menambahkan produk ke tabel 'produk'
    $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);  // Menyiapkan statement
    $stmt->bind_param("sdi", $nama, $harga, $stok);  // Mengikat parameter untuk query (s = string, d = double, i = integer)

    // Mengeksekusi query dan menampilkan pesan sukses jika berhasil
    if ($stmt->execute()) {
        echo "<script>alert('Produk berhasil ditambahkan!'); window.location.href='produk.php';</script>";  // Alert sukses dan redirect
    } else {
        echo "Error: " . $conn->error;  // Menampilkan error jika query gagal
    }
    $stmt->close();  // Menutup statement
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Tambah Produk</title>
    <link rel="stylesheet" type="text/css" href="style.css">  <!-- Link ke file CSS untuk styling -->
</head>
<body>

<div class="form-container">
    <h2>Tambah Produk</h2>

    <!-- Form untuk menambah produk -->
    <form action="tambah_produk.php" method="POST">
        <!-- Input untuk nama produk -->
        <div class="form-group">
            <label for="nama">Nama Produk:</label>
            <input type="text" id="nama" name="nama" required>  <!-- Input untuk nama produk -->
        </div>
        
        <!-- Input untuk harga produk -->
        <div class="form-group">
            <label for="harga">Harga:</label>
            <input type="number" id="harga" name="harga" required>  <!-- Input untuk harga produk -->
        </div>

        <!-- Input untuk stok produk -->
        <div class="form-group">
            <label for="stok">Stok:</label>
            <input type="number" id="stok" name="stok" required>  <!-- Input untuk stok produk -->
        </div>

        <!-- Tombol untuk submit dan tombol kembali -->
        <div class="button-container">
            <button type="submit" class="add-button">Tambah</button>
            <a href="produk.php"><button type="button" class="back-button">Kembali</button></a>
        </div>
    </form>
</div>

</body>
</html>
