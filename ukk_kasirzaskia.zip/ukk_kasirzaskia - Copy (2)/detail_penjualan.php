<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $penjualanID = $_POST['penjualanID'];
    $produkID = $_POST['produkID'];
    $jumlahProduk = $_POST['jumlah_Produk'];

    // Ambil harga produk
    $queryHarga = mysqli_query($conn, "SELECT Harga, Stok FROM produk WHERE ProdukID = $produkID");
    $row = mysqli_fetch_assoc($queryHarga);
    $harga = $row['Harga'];
    $stok = $row['Stok'];
    
    // Pastikan stok mencukupi sebelum menambahkan transaksi
    if ($stok >= $jumlahProduk) {
        $subtotal = $harga * $jumlahProduk;

        // Insert ke detailpenjualan
        $sql = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, Jumlah_Produk, Subtotal) 
                VALUES ('$penjualanID', '$produkID', '$jumlah_Produk', '$subtotal')";
        mysqli_query($conn, $sql);

        // Kurangi stok produk
        $updateStok = "UPDATE produk SET Stok = Stok - $jumlah_Produk WHERE ProdukID = $produkID";
        mysqli_query($conn, $updateStok);
    } else {
        echo "<script>alert('Stok tidak mencukupi!');</script>";
    }
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    // Ambil data sebelum menghapus untuk mengembalikan stok
    $queryDetail = mysqli_query($conn, "SELECT * FROM detailpenjualan WHERE DetailID = $id");
    $row = mysqli_fetch_assoc($queryDetail);
    $produkID = $row['ProdukID'];
    $jumlahProduk = $row['Jumlah_Produk'];

    // Kembalikan stok produk
    $updateStok = "UPDATE produk SET Stok = Stok + $jumlah_Produk WHERE ProdukID = $produkID";
    mysqli_query($conn, $updateStok);

    // Hapus data dari tabel detailpenjualan
    mysqli_query($conn, "DELETE FROM detailpenjualan WHERE DetailID = $id");
}

// Ambil Data
$result = mysqli_query($conn, 
    "SELECT detailpenjualan.*, produk.NamaProduk, penjualan.TanggalPenjualan 
     FROM detailpenjualan
     JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
     JOIN penjualan ON detailpenjualan.PenjualanID = penjualan.PenjualanID");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 60vh;
            margin: 2;
        }

        table {
            width: 70%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 2px solid black;
            padding: 17px;
            text-align: center;
        }

        th {
            background-color:rgb(255, 226, 243);
        }
       
        .aksi {
            display: flex; 
            justify-content: center; 
            gap: 5px; 
        }

        .aksi a {
            padding: 5px 10px; 
            text-decoration: none; 
            border-radius: 7px; 
            color: white; 
        }

        .edit {
            background-color: #f0ad4e; 
        }

        .hapus {
            background-color: #d9534f; /* Warna merah untuk hapus */
        }
    </style>
    <link rel="stylesheet" href="style1.css">
</head>
</head>
<body>
    <h2>Data Detail Penjualan</h2>
    
    <form method="POST">
        <label>Penjualan:</label>
        <select name="penjualanID" required>
            <option value="">Pilih Penjualan</option>
            <?php
            $penjualan = mysqli_query($conn, "SELECT * FROM penjualan");
            while ($row = mysqli_fetch_assoc($penjualan)) {
                echo "<option value='{$row['PenjualanID']}'>ID {$row['PenjualanID']} - {$row['Tanggal_Penjualan']}</option>";
            }
            ?>
        </select>

        <label>Produk:</label>
        <select name="produkID" required>
            <option value="">Pilih Produk</option>
            <?php
            $produk = mysqli_query($conn, "SELECT * FROM produk");
            while ($row = mysqli_fetch_assoc($produk)) {
                echo "<option value='{$row['ProdukID']}'>{$row['Nama_Produk']} - Stok: {$row['Stok']} - Rp. {$row['Harga']}</option>";
            }
            ?>
        </select>

        <label>Jumlah Produk:</label>
        <input type="number" name="jumlahProduk" required>

        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Penjualan ID</th>
            <th>Produk</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['DetailID'] ?></td>
                <td><?= $row['PenjualanID'] ?> - <?= $row['TanggalPenjualan'] ?></td>
                <td><?= $row['NamaProduk'] ?></td>
                <td><?= $row['Jumlah_Produk'] ?></td>
                <td>Rp. <?= number_format($row['Subtotal'], 2, ',', '.') ?></td>
                <td>
                    <a href="detailpenjualan.php?hapus=<?= $row['DetailID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>