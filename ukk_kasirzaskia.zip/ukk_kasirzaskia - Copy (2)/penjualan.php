<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $TotalHarga = $_POST['Total_Harga'];

    $stmt = $conn->prepare("INSERT INTO penjualan (Tanggal_Penjualan, PelangganID, Total_Harga) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $tanggal, $pelangganID, $TotalHarga);

    if ($stmt->execute()) {
        header("Location: penjualan.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

if (isset($_GET['hapus'])) {
    $id_hapus = $_GET['hapus'];

    $stmt_hapus = $conn->prepare("DELETE FROM penjualan WHERE PenjualanID = ?");
    $stmt_hapus->bind_param("i", $id_hapus);

    if ($stmt_hapus->execute()) {
        header("Location: penjualan.php");
        exit();
    } else {
        echo "Error deleting: " . $stmt_hapus->error;
    }
    $stmt_hapus->close();
}

$result = mysqli_query($conn, "SELECT p.*, pl.Nama_Pelanggan FROM penjualan p INNER JOIN pelanggan pl ON p.PelangganID = pl.PelangganID"); // Join with pelanggan table for Nama_Pelanggan
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan</title>
    <style>
        /* ... your existing styles ... */
        .aksi {
            display: flex;
            justify-content: center;
            gap: 5px;
        }

        .aksi a {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 7px;
            color: white;
        }

        .edit {
            background-color: #f0ad4e;
        }

        .hapus {
            background-color: #d9534f;
        }
        .back-to-index {
            margin-top: 20px;
            text-align: center;
        }

        .back-to-index a {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
<div class="back-to-index">
    <a href="index.php">Kembali ke Index</a>
</div>

    <h2>Data Penjualan</h2>

    <form method="POST">
        <label>Tanggal:</label>
        <input type="date" name="tanggal" required>
        <label>Pelanggan:</label>
        <select name="pelangganID">
            <?php while ($row_pelanggan = mysqli_fetch_assoc($pelanggan)) { ?>  <option value="<?= $row_pelanggan['PelangganID'] ?>"><?= $row_pelanggan['Nama_Pelanggan'] ?></option>
            <?php } ?>
        </select>

        <label>Total Harga:</label>
        <input type="number" name="Total_Harga" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Total Harga</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['PenjualanID'] ?></td>
                <td><?= $row['Tanggal_Penjualan'] ?></td>
            <td><?= $row['Nama_Pelanggan'] ?></td> <td>Rp <?= number_format($row['Total_Harga'], 2) ?></td>
                <td class="aksi">
                    <a class="edit" href="edit_penjualan.php?id=<?= $row['PenjualanID'] ?>">Edit</a>
                    <a class="hapus" href="penjualan.php?hapus=<?= $row['PenjualanID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>