<?php
include "koneksi.php";

// Proses hapus data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    // Prepared statement (prevents SQL injection)
    $stmt = $conn->prepare("DELETE FROM pelanggan WHERE PelangganID = ?");
    $stmt->bind_param("i", $id); // "i" indicates integer

    if ($stmt->execute()) {
        header("Location: pelanggan.php?pesan=hapus_sukses");
        exit();
    } else {
        // Better error handling (log the error)
        error_log("Error deleting record: " . $stmt->error);  // Log the error
        header("Location: pelanggan.php?pesan=hapus_gagal");
        exit();
    }

    $stmt->close();
    $conn->close(); // Close the connection
}

// Ambil data pelanggan (this part is fine)
$sql = "SELECT * FROM pelanggan";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="style1.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 60vh;
            margin: 2; /* Corrected margin value */
        }

        table {
            width: 70%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 2px solid black;
            padding: 17px;
            text-align: center;
        }

        th {
            background-color: rgb(255, 226, 243);
        }

        .aksi {
            display: flex;
            justify-content: center;
            gap: 5px;
        }

        .aksi a {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 7px;
            color: white;
        }

        .edit {
            background-color: #f0ad4e;
        }

        .hapus {
            background-color: #d9534f;
        }

        /* Optional: Style for success/error messages */
        .pesan {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .hapus_sukses {
            background-color: #4CAF50; /* Green */
            color: white;
        }
        .hapus_gagal {
            background-color: #f44336; /* Red */
            color: white;
        }

    </style>
</head>
<body>
    <h1>Data Pelanggan</h1>
    <a href="tambah_pelanggan.php">Tambah Pelanggan</a>

    <?php
    // Display messages if set
    if (isset($_GET['pesan'])) {
        $pesan = $_GET['pesan'];
        if ($pesan == "hapus_sukses") {
            echo "<div class='pesan hapus_sukses'>Data berhasil dihapus.</div>";
        } elseif ($pesan == "hapus_gagal") {
            echo "<div class='pesan hapus_gagal'>Data gagal dihapus.</div>";
        }
    }
    ?>

    <table border="2">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>No. Telepon</th>
            <th>Aksi</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["PelangganID"] . "</td>";
            echo "<td>" . $row["Nama_Pelanggan"] . "</td>";
            echo "<td>" . $row["Alamat"] . "</td>";
            echo "<td>" . $row["No_Telepon"] . "</td>";
            echo "<td class='aksi'>";
            echo "<a class='edit' href='edit_pelanggan.php?id=" . $row["PelangganID"] . "' onclick=\"return confirm('Apakah Anda yakin ingin mengubah data ini?')\">Edit</a>"; // Capitalized "Edit"
            echo "<a class='hapus' href='?hapus=" . $row["PelangganID"] . "' onclick=\"return confirm('Apakah Anda yakin ingin menghapus data ini?')\">Hapus</a>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>