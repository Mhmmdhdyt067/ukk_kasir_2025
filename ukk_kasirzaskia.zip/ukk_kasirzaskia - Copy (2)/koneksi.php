<?php
$conn = mysqli_connect("localhost", "root", "", "ukk_kasirzaskia");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>