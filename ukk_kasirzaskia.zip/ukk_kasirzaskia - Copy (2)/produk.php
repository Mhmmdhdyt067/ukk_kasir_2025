<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = $conn->prepare("INSERT INTO produk (Nama_Produk, Harga, Stok) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $nama, $harga, $stok);

    if ($stmt->execute()) {
        header("Location: produk.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

if (isset($_GET['hapus'])) {
    $id_hapus = $_GET['hapus'];

    $stmt_hapus = $conn->prepare("DELETE FROM produk WHERE ProdukID = ?");
    $stmt_hapus->bind_param("i", $id_hapus);

    if ($stmt_hapus->execute()) {
        header("Location: produk.php");
        exit();
    } else {
        echo "Error deleting: " . $stmt_hapus->error;
    }
    $stmt_hapus->close();
}

$result = mysqli_query($conn, "SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk</title>
    <div class="back-to-index">
        <a href="index.php">Kembali ke Index</a>
    </div>

    <style>
        /* ... your existing styles ... */
        .delete-link {
            color: red;
            text-decoration: none;
            margin-left: 10px;
        }
        table {
            width: 100%; /* or a specific width */
            border-collapse: collapse; /* for a cleaner look */
        }

        th, td {
            border: 1px solid #ddd; /* light gray borders */
            padding: 8px;
            text-align: left; /* or center, depending on your preference */
        }

        th {
            background-color: #f2f2f2; /* a light gray background for headers */
        }

        tr:nth-child(even) {
            background-color: #f9f9f9; /* very light gray for even rows */
        }

        .aksi { /* Style for the action buttons container */
            display: flex; /* Arrange buttons horizontally */
            gap: 5px; /* Add some space between buttons */
            justify-content: center; /* Center the buttons */

        }
        .aksi a {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 7px;
            color: white;
        }

        .edit {
            background-color: #f0ad4e;
        }

        .hapus {
            background-color: #d9534f;
        }
    </style>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h2>Data Produk</h2>

    <form method="POST">
        <label>Nama Produk:</label>
        <input type="text" name="nama" required>
        <label>Harga:</label>
        <input type="number" name="harga" required>
        <label>Stok:</label>
        <input type="number" name="stok" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['ProdukID'] ?></td>
                <td><?= $row['Nama_Produk'] ?></td>
                <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                <td><?= $row['Stok'] ?></td>
                <td class="aksi">
                    <a class="edit" href="edit_produk.php?id=<?= $row['ProdukID'] ?>">Edit</a>
                    <a class="hapus" href="produk.php?hapus=<?= $row['ProdukID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>