<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pengelolaan Basis Data | Zaskia Rasti | XII RPL B | UKK 2025</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            background-color:rgb(29, 30, 31); /* Light gray background */
            font-family: sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #343a40; /* Dark gray heading */
            text-align: center;
            margin-bottom: 30px;
        }
        .card {
            border: none; /* Remove card border */
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Add subtle shadow */
            transition: transform 0.2s; /* Smooth hover effect */
            background-color: #fff; /* White card background */
            border-radius: 10px; /* Rounded corners */
        }
        .card:hover {
            transform: scale(1.05); /* Scale up on hover */
        }
        .card-body {
            text-align: center;
            padding: 20px;
        }
        .btn {
            width: 100%;
            border-radius: 5px;
            font-weight: 500;
            transition: background-color 0.3s ease; /* Smooth hover effect */
        }
        .btn-primary {
            background-color: #007bff; /* Blue */
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .btn-success {
            background-color: #28a745; /* Green */
            border-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .btn-warning {
            background-color: #ffc107; /* Yellow */
            border-color: #ffc107;
            color: #000; /* Black text for contrast */
        }
        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #d39e00;
        }
        .btn-danger {
            background-color: #dc3545; /* Red */
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c12a36;
            border-color:rgb(82, 74, 74);
        }
        .icon { /* Style for icons */
            margin-right: 10px; /* Space between icon and text */
        }

    </style>
     <link rel="stylesheet" href="style1.css">
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Selamat Datang di Pengelolaan Basis Data</h1>
        <div class="row justify-content-center">
            <div class="col-md-3 mb-4">
                <div class="card">
                    <div class="card-body">
                        <a href="pelanggan.php" class="btn btn-primary"><i class="fas fa-users icon"></i>Data Pelanggan</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card">
                    <div class="card-body">
                        <a href="produk.php" class="btn btn-success"><i class="fas fa-box-open icon"></i>Data Produk</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card">
                    <div class="card-body">
                        <a href="penjualan.php" class="btn btn-warning"><i class="fas fa-shopping-cart icon"></i>Transaksi Penjualan</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card">
                    <div class="card-body">
                        <a href="detail_penjualan.php" class="btn btn-danger"><i class="fas fa-file-alt icon"></i>Detail Penjualan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>