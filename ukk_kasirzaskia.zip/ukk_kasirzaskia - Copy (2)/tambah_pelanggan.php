<?php
include "koneksi.php";

// Proses form jika data di-submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $alamat = $_POST["alamat"];
    $no_telepon = $_POST["no_telepon"];

    // Query untuk menambahkan data pelanggan baru
    $sql = "INSERT INTO pelanggan (Nama_Pelanggan, Alamat, No_Telepon) 
            VALUES ('$nama', '$alamat', '$no_telepon')";

    if (mysqli_query($conn, $sql)) {
        header("Location: pelanggan.php"); 
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pelanggan</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
</head>
<body>
<form method="post" action="tambah_pelanggan.php" onsubmit="return konfirmasiEdit()">
<div class="mb-3">
    <div class="container">
        <h1>Tambah Pelanggan</h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama:</label>
                <input type="text" class="form-control" name="nama" id="nama" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat:</label>
                <textarea class="form-control" name="alamat" id="alamat" required></textarea>
            </div>
            <div class="mb-3">
                <label for="no_telepon" class="form-label">No. Telepon:</label>
                <input type="text" class="form-control" name="no_telepon" id="no_telepon" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>