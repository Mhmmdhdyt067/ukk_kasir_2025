// Exports the "visualblocks" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/visualblocks')
//   ES2015:
//     import 'tinymce/plugins/visualblocks'
require('./plugin.js');