<?php
include 'db.php'; // Include koneksi database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Dashboard</title>
    <style>
        body {
            display: flex;
            height: 100vh;
            margin: 0;
        }
        /* Sidebar Style */
        .sidebar {
            width: 250px;
            height: 100%;
            background: #343a40;
            color: white;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            padding: 10px 20px;
            display: block;
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            background: #495057;
        }
        /* Main content area */
        .content {
            margin-left: 250px;
            padding: 20px;
            width: 100%;
        }
        .card {
            border-radius: 10px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center text-white">Sistem Pengelolaan Database</h4>
        <a href="index.php">Dashboard</a>
        <a href="produk.php">Produk</a>
        <a href="pelanggan.php">Pelanggan</a>
        <a href="penjualan.php">Penjualan</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1 class="mb-4">Dashboard</h1>
        <div class="row">
           
            <!-- Card for Total Pelanggan -->
            <div class="col-md-4">
                <div class="card text-white bg-secondary mb-3">
                    <div class="card-body">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM pelanggan");
                        $data = $result->fetch_assoc();
                        ?>
                        <h5 class="card-title">Total Pelanggan</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>

             <!-- Card for Total Produk -->
            <div class="col-md-4">
                <div class="card text-white bg-secondary mb-3">
                    <div class="card-body">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM produk");
                        $data = $result->fetch_assoc();
                        ?>
                        <h5 class="card-title">Total Produk</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
            
            
            <!-- Card for Total Penjualan -->
            <div class="col-md-4">
                <div class="card text-white bg-secondary mb-3">
                    <div class="card-body">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM penjualan");
                        $data = $result->fetch_assoc();
                        ?>
                        <h5 class="card-title">Total Penjualan</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
