<?php
$host="localhost";
$user="root";
$password="";
$dbname="kasirjuliana2025";

$conn=mysqli_connect($host,$user,$password,$dbname);

if (!$conn){
    die("koneksi gagal:". mysqli_connect_error());
}
?>