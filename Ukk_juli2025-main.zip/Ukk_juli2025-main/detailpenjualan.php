<?php
include "koneksi.php";

if (!isset($_GET['id'])) {
    die("ID Penjualan tidak ditemukan!");
}

$penjualanID = $_GET['id'];

$penjualan = mysqli_query($conn, "SELECT penjualan.*, pelanggan.NamaPelanggan, pelanggan.Alamat, pelanggan.NomorTelepon
                                  FROM penjualan 
                                  JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
                                  WHERE penjualan.PenjualanID = $penjualanID");
$data_penjualan = mysqli_fetch_assoc($penjualan);

$detail = mysqli_query($conn, "SELECT detailpenjualan.*, produk.NamaProduk, produk.Harga 
                               FROM detailpenjualan 
                               JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
                               WHERE detailpenjualan.PenjualanID = $penjualanID");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Penjualan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h2 {
            color: #2c3e50;
        }
        .card {
            background-color: white;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: rgb(54, 89, 107);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #27ae60;
        }
    </style>
</head>
<body>
    <h2>Detail Penjualan</h2>

    <div class="card">
        <p><strong>ID Penjualan:</strong> <?= $data_penjualan['PenjualanID'] ?></p>
        <p><strong>Tanggal:</strong> <?= $data_penjualan['TanggalPenjualan'] ?></p>
        <p><strong>Pelanggan:</strong> <?= $data_penjualan['NamaPelanggan'] ?></p>
        <p><strong>Alamat:</strong> <?= $data_penjualan['Alamat'] ?></p>
        <p><strong>Nomor Telepon:</strong> <?= $data_penjualan['NomorTelepon'] ?></p>
        <p><strong>Total Harga:</strong> Rp <?= number_format($data_penjualan['TotalHarga'], 3) ?></p>
    </div>

    <div class="card">
        <h3>Detail Produk</h3>
        <table>
            <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($detail)) { ?>
                    <tr>
                        <td><?= $row['NamaProduk'] ?></td>
                        <td>Rp <?= number_format($row['Harga'], 3) ?></td>
                        <td><?= $row['JumlahProduk'] ?></td>
                        <td>Rp <?= number_format($row['Subtotal'], 3) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <a href="penjualan.php" class="btn">Kembali</a>
</body>
</html>
