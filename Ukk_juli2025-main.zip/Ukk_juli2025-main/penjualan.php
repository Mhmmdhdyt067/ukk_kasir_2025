<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $produkID = $_POST['produkID'];
    $jumlah = $_POST['jumlah'];

    $queryHarga = mysqli_query($conn, "SELECT Harga, Stok FROM produk WHERE ProdukID = '$produkID'");
    $dataProduk = mysqli_fetch_assoc($queryHarga);
    $harga = $dataProduk['Harga'];
    $stok = $dataProduk['Stok'];

    if ($stok >= $jumlah) {
        $subtotal = $harga * $jumlah;

        $sqlPenjualan = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) 
                         VALUES ('$tanggal', '$pelangganID', '$subtotal')";
        mysqli_query($conn, $sqlPenjualan);

        $penjualanID = mysqli_insert_id($conn);

        $sqlDetail = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) 
                      VALUES ('$penjualanID', '$produkID', '$jumlah', '$subtotal')";
        mysqli_query($conn, $sqlDetail);

        $queryTotal = mysqli_query($conn, "SELECT SUM(Subtotal) AS Total 
                                           FROM detailpenjualan 
                                           WHERE PenjualanID = '$penjualanID'");
        $totalHarga = mysqli_fetch_assoc($queryTotal)['Total'];

        mysqli_query($conn, "UPDATE penjualan SET TotalHarga = '$totalHarga' WHERE PenjualanID = '$penjualanID'");

        $newStok = $stok - $jumlah;
        mysqli_query($conn, "UPDATE produk SET Stok = '$newStok' WHERE ProdukID = '$produkID'");

        header("Location: penjualan.php");
    } else {
        echo "<script>alert('Stok produk tidak cukup');</script>";
    }
}

if (isset($_GET['hapus'])) {
    $penjualanID = $_GET['hapus'];

    $queryDetail = mysqli_query($conn, "SELECT ProdukID, JumlahProduk FROM detailpenjualan WHERE PenjualanID = '$penjualanID'");
    while ($dataDetail = mysqli_fetch_assoc($queryDetail)) {
        $produkID = $dataDetail['ProdukID'];
        $jumlahProduk = $dataDetail['JumlahProduk'];

        $queryProduk = mysqli_query($conn, "SELECT Stok FROM produk WHERE ProdukID = '$produkID'");
        $dataProduk = mysqli_fetch_assoc($queryProduk);
        $stokSaatIni = $dataProduk['Stok'];

        $newStok = $stokSaatIni + $jumlahProduk;
        mysqli_query($conn, "UPDATE produk SET Stok = '$newStok' WHERE ProdukID = '$produkID'");
    }

    mysqli_query($conn, "DELETE FROM detailpenjualan WHERE PenjualanID = '$penjualanID'");

    mysqli_query($conn, "DELETE FROM penjualan WHERE PenjualanID = '$penjualanID'");

    header("Location: penjualan.php");
}

$result = mysqli_query($conn, "SELECT p.*, pel.NamaPelanggan, pel.Alamat, pel.NomorTelepon 
    FROM penjualan p 
    JOIN pelanggan pel ON p.PelangganID = pel.PelangganID");

$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
$produk = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            padding: 20px;
            text-align: center;
        }
        h2 {
            color: #2c3e50;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-control {
            width: 100%;
            padding: 10px;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            background-color: rgb(54, 89, 107);
            color: white;
            border: none;
        }
        button:hover {
            background-color: #2980b9;
        }
        table {
            width: 99%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: rgb(54, 89, 107);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .hapus-btn {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        .hapus-btn:hover {
            background-color: #c0392b;
        }
        .detail-btn {
            display: inline-block;
            padding: 8px 12px;
            background-color: #3498db;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        .detail-btn:hover {
            background-color: #2980b9;
        }
        .kembali-btn {
            padding: 10px 20px;
            background-color: #2ecc71;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .kembali-btn:hover {
            background-color: #27ae60;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Manajemen Penjualan</h2>

        <form method="POST">
            <input type="date" name="tanggal" class="form-control" style="width:98%;" placeholder="Tanggal" required>
            <select name="pelangganID" class="form-control" required>
                <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                    <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
                <?php } ?>
            </select>
            <select name="produkID" class="form-control" required>
                <?php while ($row = mysqli_fetch_assoc($produk)) { ?>
                    <option value="<?= $row['ProdukID'] ?>"><?= $row['NamaProduk'] ?> - Rp <?= number_format($row['Harga'], 2) ?> (Stok: <?= $row['Stok'] ?>)</option>
                <?php } ?>
            </select>
            <input type="number" name="jumlah" class="form-control" placeholder="Jumlah" style="width:98%;" required>
            <button type="submit" name="tambah">Tambah Penjualan</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tanggal</th>
                    <th>Pelanggan</th>
                    <th>Total Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['PenjualanID'] ?></td>
                        <td><?= $row['TanggalPenjualan'] ?></td>
                        <td><?= $row['NamaPelanggan'] ?></td>
                        <td>Rp <?= number_format($row['TotalHarga'], 3) ?></td>
                        <td>
                            <a href="penjualan.php?hapus=<?= $row['PenjualanID'] ?>" class="hapus-btn" onclick="return confirm('Yakin ingin menghapus penjualan ini?')">Hapus</a>
                            <a href="detailpenjualan.php?id=<?= $row['PenjualanID'] ?>" class="detail-btn">Detail</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <a href="index.php" class="kembali-btn">Kembali</a>
        </div>
</body>
</html>