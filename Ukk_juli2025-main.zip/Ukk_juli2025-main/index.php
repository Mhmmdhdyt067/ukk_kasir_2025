<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir Juliana Putri Y</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 50px;
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 30px;
        }
        .menu-container {
            display: flex;
            justify-content: center;
        }
        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: rgb(54, 89, 107);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        a {
            display: inline-block;
            padding: 10px 15px;
            text-decoration: none;
            color: white;
            background: rgb(54, 89, 107);
            border-radius: 5px;
            font-size: 16px;
            transition: 0.3s;
        }
        a:hover {
            background: #2980b9;
        }
    </style>
<body>
    <h1>Dashboard Kasir</h1>
    <table>
        <tr>
            <th>Menu</th>
            <th>Aksi</th>
        </tr>
        <tr>
            <td>Data Pelanggan</td>
            <td><a href="pelanggan.php">Lihat</a></td>
        </tr>
        <tr>
            <td>Data Produk</td>
            <td><a href="produk.php">Lihat</a></td>
        </tr>
        <tr>
            <td>Data Penjualan</td>
            <td><a href="penjualan.php">Lihat</a></td>
        </tr>
        <tr>
    </table>
</body>
</html>