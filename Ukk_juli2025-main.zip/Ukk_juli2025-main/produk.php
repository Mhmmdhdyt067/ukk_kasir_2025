<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    mysqli_query($conn, $sql);
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM produk WHERE ProdukID = $id");
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "UPDATE produk SET NamaProduk='$nama', Harga='$harga', Stok='$stok' WHERE ProdukID='$id'";
    mysqli_query($conn, $sql);
}

$result = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h2 {
            color: #2c3e50;
        }
        form {
            background: white;
            padding: 15px;
            display: inline-block;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        input, button {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: rgb(54, 89, 107);
            color: white;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        button:hover {
            background-color: #2980b9;
        }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: rgb(54, 89, 107);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .edit-btn, .hapus-btn {
            display: inline-block;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s ease;
        }
        .hapus-btn {
            background-color: #e74c3c; 
            color: white;
        }
        .edit-btn {
            background-color: #f39c12;
            color: white;
        }
        .edit-btn:hover {
            background-color: #e67e22;
        }
    </style>
</head>
<body>

    <h2>Data Produk</h2>

    <form method="POST">
        <label>Nama Produk:</label>
        <input type="text" name="nama" required>
        <label>Harga:</label>
        <input type="number" name="harga" required>
        <label>Stok:</label>
        <input type="number" name="stok" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['ProdukID'] ?></td>
                <td><?= $row['NamaProduk'] ?></td>
                <td>Rp <?= number_format($row['Harga'], 3, ',', '.') ?></td>
                <td><?= $row['Stok'] ?></td>
                <td>
                    <a href="produk.php?edit=<?= $row['ProdukID'] ?>" class="edit-btn">Edit</a>
                    <a href="produk.php?hapus=<?= $row['ProdukID'] ?>" class="hapus-btn" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <?php 
    if (isset($_GET['edit'])) {
        $id = $_GET['edit'];
        $query = mysqli_query($conn, "SELECT * FROM produk WHERE ProdukID = '$id'");
        $data = mysqli_fetch_assoc($query);
    ?>
        <h2>Edit Produk</h2>
        <form method="POST">
            <input type="hidden" name="id" value="<?= $data['ProdukID'] ?>">
            <label>Nama Produk:</label>
            <input type="text" name="nama" value="<?= $data['NamaProduk'] ?>" required>
            <label>Harga:</label>
            <input type="number" name="harga" value="<?= $data['Harga'] ?>" required>
            <label>Stok:</label>
            <input type="number" name="stok" value="<?= $data['Stok'] ?>" required>
            <button type="submit" name="update">Update</button>
        </form>
    <?php } ?>

</body>
<button class="kembali-btn" onclick="window.history.back()">Kembali</button>

</html>