<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) 
            VALUES ('$nama', '$alamat', '$telepon')";
    mysqli_query($conn, $sql);
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE PelangganID = $id");
}
$result = mysqli_query($conn, "SELECT * FROM pelanggan");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h2 {
            color: #2c3e50;
        }
        form {
            margin-bottom: 20px;
        }
        input, button {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: rgb(54, 89, 107);
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #2980b9;
        }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: rgb(54, 89, 107);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .hapus-btn, .edit-btn {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c; 
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 15px;
            transition: background 0.3s ease;
        }

        .hapus-btn:hover {
            background-color: #c0392b; 
        }
        .edit-btn {
            background-color:rgb(126, 211, 57);
        }
        .edit-btn:hover {
            background-color: #e67e22;
        }
        .kembali-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: background 0.3s ease;
        }

        .kembali-btn:hover {
            background-color: #27ae60; 
        }
    </style>
</head>
<body>
    <h2>Data Pelanggan</h2>
    <form method="POST">
        <input type="text" name="nama" placeholder="Nama" required>
        <input type="text" name="alamat" placeholder="Alamat" required>
        <input type="text" name="telepon" placeholder="Telepon" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Telepon</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['PelangganID'] ?></td>
                <td><?= $row['NamaPelanggan'] ?></td>
                <td><?= $row['Alamat'] ?></td>
                <td><?= $row['NomorTelepon'] ?></td>
                <td>
                <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" class="hapus-btn" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
<button class="kembali-btn" onclick="window.history.back()">Kembali</button>
</html>