document.addEventListener("DOMContentLoaded", function () {
    const produkContainer = document.getElementById("produk-container");
    const totalHargaElement = document.getElementById("total-harga");

    function hitungTotal() {
        let total = 0;
        document.querySelectorAll(".produk-item").forEach(function (row) {
            const selectProduk = row.querySelector("select");
            const jumlahInput = row.querySelector(".jumlah");
            const subtotalElement = row.querySelector(".subtotal");

            const harga = parseFloat(selectProduk.selectedOptions[0].getAttribute("data-harga")) || 0;
            const jumlah = parseInt(jumlahInput.value) || 1;
            const subtotal = harga * jumlah;

            subtotalElement.textContent = "Rp " + subtotal.toLocaleString("id-ID");
            total += subtotal;
        });
        totalHargaElement.textContent = "Rp " + total.toLocaleString("id-ID");
    }

    produkContainer.addEventListener("change", hitungTotal);
    produkContainer.addEventListener("input", hitungTotal);
});
