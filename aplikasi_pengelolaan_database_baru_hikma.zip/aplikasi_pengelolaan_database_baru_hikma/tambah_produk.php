<?php
include "database.php"; // Koneksi ke database

// Inisialisasi variabel untuk edit
$id = "";
$nama_produk = "";
$harga = "";
$stok = "";

// Jika ada parameter id (edit produk)
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM produk4 WHERE ProdukID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $nama_produk = $row['NamaProduk'];
        $harga = $row['Harga'];
        $stok = $row['Stok'];
    }
}

// Proses Simpan atau Update
if (isset($_POST['simpan'])) {
    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    
    if ($id) {
        // Proses Update
        $query = "UPDATE produk4 SET NamaProduk = ?, Harga = ?, Stok = ? WHERE ProdukID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sdii", $nama_produk, $harga, $stok, $id);
    } else {
        // Proses Tambah Baru
        $query = "INSERT INTO produk4 (NamaProduk, Harga, Stok) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sdi", $nama_produk, $harga, $stok);
    }
    
    if ($stmt->execute()) {
        header("Location: produk.php"); // Redirect ke halaman produk setelah berhasil
        exit;
    } else {
        echo "Gagal menyimpan data: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id ? 'Edit' : 'Tambah'; ?> Produk</title>
    <link rel="stylesheet" href="style_tambah_produk.css"> <!-- Hubungkan dengan file CSS -->
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <nav class="sidebar">
        <h2>Menu</h2>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="pelanggan.php">Data Pelanggan</a></li>
            <li><a href="produk.php">Data Produk</a></li>
            <li><a href="penjualan.php">Data Penjualan</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1><?php echo $id ? 'Edit' : 'Tambah'; ?> Produk</h1>
        <form action="" method="POST">
            <label for="nama_produk">Nama Produk:</label>
            <input type="text" id="nama_produk" name="nama_produk" value="<?php echo htmlspecialchars($nama_produk); ?>" required>
            
            <label for="harga">Harga:</label>
            <input type="number" id="harga" name="harga" value="<?php echo htmlspecialchars($harga); ?>" required>
            
            <label for="stok">Stok:</label>
            <input type="number" id="stok" name="stok" value="<?php echo htmlspecialchars($stok); ?>" required>
            
            <button type="submit" name="simpan">Simpan</button>
            <a href="produk.php" class="btn-kembali">Kembali</a>
        </form>
    </div>
</div>
</body>
</html>
