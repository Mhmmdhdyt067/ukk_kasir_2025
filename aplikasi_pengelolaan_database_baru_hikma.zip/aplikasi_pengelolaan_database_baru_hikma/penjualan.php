<?php 
include "get_harga.php"; // Koneksi ke database

// Jika tombol simpan ditekan, simpan transaksi baru
if (isset($_POST['simpan'])) {
    $tanggal = date('Y-m-d'); // Ambil tanggal hari ini
    $pelanggan_id = $_POST['pelanggan_id']; // Ambil ID pelanggan dari form

    // Simpan transaksi ke tabel "penjualan"
    $query = "INSERT INTO penjualan (TanggalPenjualan, PelangganID) VALUES ('$tanggal', '$pelanggan_id')";
    if (mysqli_query($conn, $query)) {
        $penjualan_id = mysqli_insert_id($conn); // Ambil ID transaksi yang baru dibuat

        // Simpan detail transaksi
        $total_harga = 0;
        foreach ($_POST['produk_id'] as $index => $produk_id) {
            $jumlah = $_POST['jumlah'][$index];
            $harga = $_POST['harga'][$index];
            $subtotal = $jumlah * $harga;
            $total_harga += $subtotal;
            
            $query_detail = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) VALUES ('$penjualan_id', '$produk_id', '$jumlah', '$subtotal')";
            mysqli_query($conn, $query_detail);
        }

        // Update total harga di tabel penjualan
        $query_update_total = "UPDATE penjualan SET TotalHarga = '$total_harga' WHERE PenjualanID = '$penjualan_id'";
        mysqli_query($conn, $query_update_total);

        header("Location: penjualan.php"); // Redirect ke halaman penjualan
        exit;
    } else {
        echo "Gagal menyimpan transaksi";
    }
}

// Jika tombol hapus ditekan, hapus transaksi
if (isset($_GET['hapus'])) {
    $penjualan_id = $_GET['hapus'];
    
    // Hapus detail transaksi terlebih dahulu
    $conn->query("DELETE FROM detailpenjualan WHERE PenjualanID = '$penjualan_id'");
    
    // Hapus transaksi dari tabel penjualan
    if ($conn->query("DELETE FROM penjualan WHERE PenjualanID = '$penjualan_id'")) {
        header("Location: penjualan.php"); // Redirect ke halaman penjualan setelah penghapusan
        exit;
    } else {
        echo "Gagal menghapus transaksi";
    }
}

// Ambil data penjualan untuk ditampilkan dalam tabel, termasuk total harga
$result = $conn->query("SELECT 
                            p.PenjualanID, 
                            p.TanggalPenjualan, 
                            pel.NamaPelanggan, 
                            IFNULL(p.TotalHarga, 0) AS TotalHarga 
                        FROM penjualan p 
                        JOIN pelanggan pel ON p.PelangganID = pel.PelangganID");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Transaksi</title>
    <link rel="stylesheet" href="style_penjualan.css"> <!-- Hubungkan dengan file CSS -->
</head>
<body>
<div class="wrapper">
    <nav class="sidebar">
        <h2>Menu</h2>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="pelanggan.php">Data Pelanggan</a></li>
            <li><a href="produk.php">Data Produk</a></li>
            <li><a href="penjualan.php">Data Penjualan</a></li>
        </ul>
    </nav>
    <div class="main-content">
    <div class="container">
        <h1>Kelola Transaksi Penjualan</h1>
        
        <a href="tambah_penjualan.php" class="btn-tambah">Tambah Transaksi</a>
        
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tanggal</th>
                    <th>Pelanggan</th>
                    <th>Total Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?> 
                    <tr>
                        <td><?php echo $row['PenjualanID']; ?></td>
                        <td><?php echo $row['TanggalPenjualan']; ?></td>
                        <td><?php echo $row['NamaPelanggan']; ?></td>
                        <td>Rp <?php echo number_format($row['TotalHarga'], 2, ',', '.'); ?></td>
                        <td>
                            <a href="detail_penjualan.php?id=<?= $row['PenjualanID']; ?>" class="btn-view">Lihat Detail</a>
                            <a href="penjualan.php?hapus=<?= $row['PenjualanID']; ?>" class="btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus transaksi ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
