<?php
include "database.php";

if (isset($_GET['produk_id'])) {
    $produk_id = $_GET['produk_id'];
    $query = "SELECT Harga FROM produk4 WHERE ProdukID = '$produk_id'";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    
    echo json_encode(["harga" => $row['Harga']]);
}
?>
