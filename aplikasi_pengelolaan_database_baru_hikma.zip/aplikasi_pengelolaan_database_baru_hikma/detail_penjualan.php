<?php
include "database.php"; // Koneksi ke database

// Pastikan ada parameter ID transaksi
if (!isset($_GET['id'])) {
    echo "ID transaksi tidak ditemukan!";
    exit;
}

$penjualan_id = $_GET['id'];

// Ambil informasi transaksi
$query = "SELECT p.TanggalPenjualan, pel.NamaPelanggan, SUM(d.Subtotal) as TotalHarga 
          FROM penjualan p 
          JOIN pelanggan pel ON p.PelangganID = pel.PelangganID 
          JOIN detailpenjualan d ON p.PenjualanID = d.PenjualanID 
          WHERE p.PenjualanID = '$penjualan_id'";
$result = $conn->query($query);
$transaksi = $result->fetch_assoc();

// Ambil daftar produk yang dibeli
$search = "";
$whereClause = "";
if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $whereClause = " AND pr.NamaProduk LIKE '%$search%'";
}

$query_produk = "SELECT pr.NamaProduk, d.JumlahProduk, d.Subtotal 
                 FROM detailpenjualan d 
                 JOIN produk4 pr ON d.ProdukID = pr.ProdukID 
                 WHERE d.PenjualanID = '$penjualan_id' $whereClause";
$result_produk = $conn->query($query_produk);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penjualan</title>
    <link rel="stylesheet" href="style_detail_penjualan.css"> <!-- Hubungkan dengan file CSS -->
</head>
<body>
<div class="wrapper">
    <div class="container">
        <h1>Detail Transaksi Penjualan</h1>
        <p><strong>Tanggal:</strong> <?php echo $transaksi['TanggalPenjualan']; ?></p>
        <p><strong>Pelanggan:</strong> <?php echo $transaksi['NamaPelanggan']; ?></p>
        <p><strong>Total Harga:</strong> Rp <?php echo number_format($transaksi['TotalHarga'], 0, ',', '.'); ?></p>
        
        <!-- Form Pencarian -->
        <form method="GET" action="">
            <input type="hidden" name="id" value="<?php echo $penjualan_id; ?>">
            <input type="text" name="search" value="<?php echo $search; ?>" placeholder="Cari produk...">
            <button type="submit">Cari</button>
            <a href="detail_penjualan.php?id=<?php echo $penjualan_id; ?>" class="btn-reset">Reset</a>
        </form>
        
        <!-- Tabel Produk -->
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result_produk->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['NamaProduk']; ?></td>
                        <td><?php echo $row['JumlahProduk']; ?></td>
                        <td>Rp <?php echo number_format($row['Subtotal'], 0, ',', '.'); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="penjualan.php" class="btn-kembali">Kembali</a>
    </div>
</div>
</body>
</html>
