<?php
include "get_harga.php"; // Koneksi ke database

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil data pelanggan dari database
$pelangganResult = $conn->query("SELECT * FROM pelanggan");

// Ambil data produk dari database
$produkResult = $conn->query("SELECT * FROM produk4");

// Jika form disubmit
if (isset($_POST['tambah'])) {
    $pelangganID = $_POST['pelanggan'];
    $tanggal = date("Y-m-d");
    $totalHarga = 0;

    // Simpan transaksi ke tabel `penjualan`
    $query = "INSERT INTO penjualan (TanggalPenjualan, TotalHarga, PelangganID) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sdi", $tanggal, $totalHarga, $pelangganID);

    if ($stmt->execute()) {
        $penjualanID = $stmt->insert_id; // ID transaksi terakhir

        // Simpan detail transaksi
        foreach ($_POST['produk'] as $index => $produkID) {
            $jumlah = $_POST['jumlah'][$index];

            // Ambil harga dan stok produk dari database
            $produkQuery = $conn->query("SELECT Harga, Stok FROM produk4 WHERE ProdukID = '$produkID'");
            $produkData = $produkQuery->fetch_assoc();

            if (!$produkData) {
                echo "Produk dengan ID $produkID tidak ditemukan!";
                exit;
            }

            // Pastikan stok cukup
            if ($produkData['Stok'] < $jumlah) {
                echo "Stok produk tidak mencukupi untuk produk: " . $produkID;
                exit;
            }
            $harga = $produkData['Harga'];
            $subtotal = $harga * $jumlah;
            $totalHarga += $subtotal;

            // Simpan detail transaksi ke `detailpenjualan`
            $detailQuery = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) VALUES (?, ?, ?, ?)";
            $detailStmt = $conn->prepare($detailQuery);
            $detailStmt->bind_param("iiid", $penjualanID, $produkID, $jumlah, $subtotal);
            $detailStmt->execute();

            // Update stok produk
            $stokQuery = "UPDATE produk4 SET Stok = Stok - ? WHERE ProdukID = ?";
            $stokStmt = $conn->prepare($stokQuery);
            $stokStmt->bind_param("ii", $jumlah, $produkID);
            $stokStmt->execute();
        }

        // Ambil total harga dari detailpenjualan
        $query_total = "SELECT SUM(Subtotal) AS total FROM detailpenjualan WHERE PenjualanID = ?";
        $detailStmt = $conn->prepare($query_total);
        $detailStmt->bind_param("i", $penjualanID);
        $detailStmt->execute();
        $detailResult = $detailStmt->get_result();
        $data = $detailResult->fetch_assoc();
        $totalHarga = $data['total'];

        // Update total harga di tabel penjualan
        $query_update = "UPDATE penjualan SET TotalHarga = ? WHERE PenjualanID = ?";
        $updateStmt = $conn->prepare($query_update);
        $updateStmt->bind_param("di", $totalHarga, $penjualanID);
        $updateStmt->execute();

        header("Location: penjualan.php");
        exit;
    } else {
        echo "Gagal menambahkan transaksi: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
    <link rel="stylesheet" href="style_tambah_penjualan3.css">
    <script src="tambah_penjualan.js"></script>
</head>
<body>
<div class="wrapper">
<div class="sidebar">
    <h2>Menu</h2>
    <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="pelanggan.php">Data Pelanggan</a></li>
        <li>
          <li><a href="produk.php">Data Produk</a></li>
                <li><a href="penjualan.php">Kelola Transaksi</a></li>
        </li>
    </ul>
</div>

    <h1>Tambah Transaksi</h1>
    <div class="main-content">
    <form method="POST" class="form-input">
        <label>Pelanggan:</label>
        <select name="pelanggan" required>
            <option value="">-- Pilih Pelanggan --</option>
            <?php while ($row = $pelangganResult->fetch_assoc()) { ?>
                <option value="<?= $row['PelangganID']; ?>"><?= $row['NamaPelanggan']; ?></option>
            <?php } ?>
        </select>

        <label>Produk:</label>
        <div id="produk-container">
    <div class="produk-item">
        <select name="produk[]" required>
            <?php
            $produkResult->data_seek(0);
            while ($row = $produkResult->fetch_assoc()) { ?>
                <option value="<?= $row['ProdukID']; ?>" data-harga="<?= $row['Harga']; ?>">
                    <?= $row['NamaProduk']; ?> - Rp <?= number_format($row['Harga'], 2, ',', '.'); ?>
                </option>
            <?php } ?>
        </select>
        <input type="number" name="jumlah[]" min="1" value="1" required class="jumlah">
        <span class="subtotal">Rp 0</span>
    </div>
</div>

<p>Total Harga: <span id="total-harga">Rp 0</span></p>

        <button type="submit" name="tambah">Simpan Transaksi</button>
        <a href="penjualan.php" class="cancel-btn">Batal</a>
    </form>
</div>
</body>
</html>
