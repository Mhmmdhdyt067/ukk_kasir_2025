<?php
include "database.php"; // Sertakan koneksi database

// Jika ada parameter hapus
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM produk4 WHERE ProdukID = $id");
    header("Location: produk.php");
}

// Jika ada pencarian produk
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $result = $conn->query("SELECT * FROM produk4 WHERE NamaProduk LIKE '%$search%'");
} else {
    $result = $conn->query("SELECT * FROM produk4");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk</title>
    <link rel="stylesheet" href="style_produk.css"> <!-- Hubungkan dengan file CSS -->
</head>
<body>
<div class="wrapper">
    <!-- Sidebar (Menu Navigasi) -->
    <nav class="sidebar">
        <h2>Menu</h2>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="pelanggan.php">Data Pelanggan</a></li>
            <li><a href="produk.php">Data Produk</a></li>
            <li><a href="penjualan.php">Data Penjualan</a></li>
        </ul>
    </nav>
    <div class="main-content">
    <div class="container">
  
        <h1>Manajemen Produk</h1>

        <!-- Tombol Tambah Produk -->
        <a href="tambah_produk.php" class="btn-tambah">Tambah Produk</a>

        <!-- Form Pencarian -->
        <form method="GET" class="form-cari">
            <input type="text" name="search" placeholder="Cari nama produk..." value="<?php echo $search; ?>">
            <button type="submit" class="btn-cari">Cari</button>
            <a href="produk.php" class="btn-reset">Reset</a>
        </form>

        <!-- Tabel Produk -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?> 
                    <tr>
                        <td><?php echo $row['ProdukID']; ?></td>
                        <td><?php echo $row['NamaProduk']; ?></td>
                        <td>Rp <?php echo number_format($row['Harga'], 2, ',', '.'); ?></td>
                        <td><?php echo $row['Stok']; ?></td>
                        <td>
                            <a href="tambah_produk.php?id=<?= $row['ProdukID']; ?>" class="btn-warning">Edit</a>
                            <a href="produk.php?hapus=<?php echo $row['ProdukID']; ?>" onclick="return confirm('Yakin ingin menghapus?')" class="btn-hapus">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
