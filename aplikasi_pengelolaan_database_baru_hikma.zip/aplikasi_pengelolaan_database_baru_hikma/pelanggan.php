<?php
// Sertakan file konfigurasi database untuk koneksi
include "database.php"; 

// Jika tombol tambah ditekan, maka data akan disimpan ke database
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    // Query SQL untuk menambahkan data pelanggan ke dalam tabel pelanggan
    $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NoTelp) VALUES ('$nama', '$alamat', '$telepon')";
    $conn->query($sql);
}

// Jika tombol edit ditekan, maka data akan diperbarui di database
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    // Query SQL untuk update data pelanggan
    $sql = "UPDATE pelanggan SET NamaPelanggan='$nama', Alamat='$alamat', NoTelp='$telepon' WHERE PelangganID=$id";
    $conn->query($sql);
}

// Jika ada parameter hapus pada URL (misalnya pelanggan.php?hapus=1), maka data akan dihapus
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM pelanggan WHERE PelangganID = $id");
}

// Jika ada parameter edit, ambil data pelanggan yang akan diedit
$editData = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $resultEdit = $conn->query("SELECT * FROM pelanggan WHERE PelangganID = $id");
    $editData = $resultEdit->fetch_assoc();
}

// Pencarian data pelanggan
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM pelanggan WHERE NamaPelanggan LIKE '%$search%' OR Alamat LIKE '%$search%' OR NoTelp LIKE '%$search%'";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="style_pelanggan2.css">
</head>
<body>
    <div class="wrapper">
        <nav class="sidebar">
            <h2>Menu</h2>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="pelanggan.php">Data Pelanggan</a></li>
                <li><a href="produk.php">Data Produk</a></li>
                <li><a href="penjualan.php">Data Penjualan</a></li>
            </ul>
        </nav>

        <div class="main-content">
            <h1>Data Pelanggan</h1>
            
            <!-- Form Tambah / Edit Pelanggan -->
            <form method="POST" class="form-input">
                <input type="hidden" name="id" value="<?php echo $editData ? $editData['PelangganID'] : ''; ?>">
                
                <label>Nama Pelanggan:</label>
                <input type="text" name="nama" value="<?php echo $editData ? $editData['NamaPelanggan'] : ''; ?>" required>
                
                <label>Alamat:</label>
                <textarea name="alamat" required><?php echo $editData ? $editData['Alamat'] : ''; ?></textarea>
                
                <label>Nomor Telepon:</label>
                <input type="text" name="telepon" value="<?php echo $editData ? $editData['NoTelp'] : ''; ?>" required>
                
                <?php if ($editData): ?>
                    <button type="submit" name="update">Update Pelanggan</button>
                    <a href="pelanggan.php" class="cancel-btn">Batal</a>
                <?php else: ?>
                    <button type="submit" name="tambah">Tambah Pelanggan</button>
                <?php endif; ?>
            </form>

<!-- Form Pencarian -->
<form method="GET" class="search-form">
                <input type="text" name="search" placeholder="Cari pelanggan..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Cari</button>
                <a href="pelanggan.php" class="reset-btn">Reset</a>
            </form>
            <!-- Tabel Data Pelanggan -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Nomor Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?> 
                        <tr>
                            <td><?php echo $row['PelangganID']; ?></td>
                            <td><?php echo $row['NamaPelanggan']; ?></td>
                            <td><?php echo $row['Alamat']; ?></td>
                            <td><?php echo $row['NoTelp']; ?></td>
                            <td>
                                <a href="pelanggan.php?edit=<?php echo $row['PelangganID']; ?>" class="edit-btn">Edit</a>
                                <a href="pelanggan.php?hapus=<?php echo $row['PelangganID']; ?>" onclick="return confirm('Yakin ingin menghapus?')" class="delete-btn">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
