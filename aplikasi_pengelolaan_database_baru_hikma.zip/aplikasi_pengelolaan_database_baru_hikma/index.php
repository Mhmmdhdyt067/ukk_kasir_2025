<?php
include "database.php";

// Ambil total produk
$resultProduk = $conn->query("SELECT COUNT(*) AS total FROM produk4");
$totalProduk = $resultProduk->fetch_assoc()['total'];

// Ambil total pelanggan
$resultPelanggan = $conn->query("SELECT COUNT(*) AS total FROM pelanggan");
$totalPelanggan = $resultPelanggan->fetch_assoc()['total'];

// Ambil total penjualan
$resultPenjualan = $conn->query("SELECT COUNT(*) AS total FROM penjualan");
$totalPenjualan = $resultPenjualan->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Aplikasi Kasir</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav class="sidebar">
            <h2>Menu</h2>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="pelanggan.php">Data Pelanggan</a></li>
                <li><a href="produk.php">Data Produk</a></li>
                <li><a href="penjualan.php">Data Penjualan</a></li>
            </ul>
        </nav>

        <!-- Konten Utama -->
        <div class="main-content">
            <h1>Dashboard</h1>
            <div class="stats">
                <div class="card blue">
                    <h3>Total Produk</h3>
                    <p><?php echo $totalProduk; ?></p>
                </div>
                <div class="card green">
                    <h3>Total Pelanggan</h3>
                    <p><?php echo $totalPelanggan; ?></p>
                </div>
                <div class="card yellow">
                    <h3>Total Penjualan</h3>
                    <p><?php echo $totalPenjualan; ?></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
