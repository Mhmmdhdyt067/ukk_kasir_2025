<?php
include 'db.php'; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir</title>
</head>
<body>
    <h1>Selamat Datang di Sistem Kasir</h1>
    <nav>
        <ul>
            <li><a href="pelanggan.php" class="button">Kelola Pelanggan</a></li>
            <li><a href="produk.php" class="button">Kelola Produk</a></li>
            <li><a href="penjualan.php" class="button">Kelola Penjualan</a></li>
        </ul>
   </nav>
</body>
<head>
    <style>
body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right, #6a11cb, #2575fc);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
.container {
    background: rgba(255, 255, 255, 0.2);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(10px);
    width: 300px;
}

h1 {
    color: white;
    font-size: 24px;
    margin-bottom: 20px;
}

.button {
    display: block;
    width: 100%;
    padding: 12px;
    font-size: 16px;
    font-weight: bold;
    text-decoration: none;
    color: white;
    background: #007bff;
    border-radius: 8px;
    margin: 10px 0;
    transition: 0.3s ease-in-out;
    border: none;
    cursor: pointer;
    text-transform: uppercase;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.button:hover {
    background: #0056b3;
    transform: scale(1.05);
}

.button:first-child {
    background: #004080;
}

.button:first-child:hover {
    background: #002f5e;
}
</head>
</style>
</html>
