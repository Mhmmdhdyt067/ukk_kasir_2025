<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);

    $query = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Produk berhasil ditambahkan!'); window.location='produk.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
</head>
<body>
    <h1>Tambah Produk</h1>
    <form action="" method="POST">
        <label for="nama">Nama Produk:</label>
        <input type="text" id="nama" name="nama" required>

        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" step="0.01" required>

        <label for="stok">Stok:</label>
        <input type="number" id="stok" name="stok" required>

        <button type="submit">Simpan</button>
        <a href="produk.php">Batal</a>
    </form>
</body>
<head>
    <style>
        /* Formulir */
form {
    width: 50%;
    margin: 20px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}

label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}

h1 {
    color: #333;
    text-align: center;
    margin-bottom: 20px;
}

input {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    border: none;
    cursor: pointer;
    margin-top: 10px;
}

button:hover {
    background-color: #45a049;
}

a {
    display: inline-block;
    padding: 10px 15px;
    text-decoration: none;
    background-color: #f44336;
    color: white;
    margin-top: 10px;
    border-radius: 5px;
}

a:hover {
    background-color: #d32f2f;
}
</head>
</style>
</html>
