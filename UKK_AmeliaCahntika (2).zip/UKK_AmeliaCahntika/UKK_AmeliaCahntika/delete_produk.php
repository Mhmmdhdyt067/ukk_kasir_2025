<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "ID Produk tidak ditemukan!";
    exit;
}

$produk_id = $_GET['id'];

// Hapus produk dari database
$delete_query = "DELETE FROM produk WHERE ProdukID = $produk_id";

if (mysqli_query($conn, $delete_query)) {
    echo "<script>alert('Produk berhasil dihapus!'); window.location='produk.php';</script>";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
