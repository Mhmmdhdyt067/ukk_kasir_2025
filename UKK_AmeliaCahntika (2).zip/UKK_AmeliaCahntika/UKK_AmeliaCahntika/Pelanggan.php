<?php
include 'db.php';

$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pelanggan</title>
</head>
<body>
    <h1>Data Pelanggan</h1>
    <a href="index.php">Kembali ke Dashboard</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Nomor Telepon</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?php echo $row['PelangganID']; ?></td>
            <td><?php echo $row['NamaPelanggan']; ?></td>
            <td><?php echo $row['Alamat']; ?></td>
            <td><?php echo $row['NomorTelepon']; ?></td>
            <td>
                <a href="edit_pelanggan.php?id=<?php echo $row['PelangganID']; ?>">Edit</a>
                <a href="delete_pelanggan.php?id=<?php echo $row['PelangganID']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="tambah_pelanggan.php">Tambah Pelanggan</a>
</body>
<head>
    <style>
 body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}

h1 {
    color: #333;
    text-align: center;
}

a {
    text-decoration: none;
    background-color:rgb(67, 190, 238);
    color: white;
    padding: 8px 12px;
    border-radius: 4px;
    display: inline-block;
    margin-bottom: 10px;
}

a:hover {
    background-color: rgb(67, 190, 238);
}

table {
    width: 100%;
    border-collapse: collapse;
    background-color: white;
}

table, th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}

th {
    background-color: #007bff;
    color: white;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

th, td {
    padding: 10px;
    text-align: center;
}

td a {
    margin: 0 5px;
    padding: 6px 10px;
    border-radius: 4px;
    font-size: 14px;
}

td a[href*='edit_pelanggan'] {
    background-color: #ffc107;
    color: black;
}

td a[href*='edit_pelanggan']:hover {
    background-color: #e0a800;
}

td a[href*='delete_pelanggan'] {
    background-color: #dc3545;
    color: white;
}

td a[href*='delete_pelanggan']:hover {
    background-color: #c82333;
}
</style>
</head>
</html>
