<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "ukk_ameliacahntika";

$conn = mysqli_connect($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
