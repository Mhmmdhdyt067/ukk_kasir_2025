<?php
include 'db.php';

$result = mysqli_query($conn, "SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Produk</title>
</head>
<body>
    <h1>Data Produk</h1>
    <a href="index.php">Kembali ke Dashboard</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?php echo $row['ProdukID']; ?></td>
            <td><?php echo $row['NamaProduk']; ?></td>
            <td><?php echo $row['Harga']; ?></td>
            <td><?php echo $row['Stok']; ?></td>
            <td>
                <a href="edit_produk.php?id=<?php echo $row['ProdukID']; ?>">Edit</a>
                <a href="delete_produk.php?id=<?php echo $row['ProdukID']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="tambah_produk.php">Tambah Produk</a>
</body>
<head>
    <style>
        body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}

h1 {
    color: #333;
    text-align: center;
    margin-bottom: 20px;
}

a {
    text-decoration: none;
    padding: 8px 12px;
    background-color: #007bff;
    color: #fff;
    border-radius: 5px;
    margin: 5px;
    display: inline-block;
}

a:hover {
    background-color: #0056b3;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    margin-top: 10px;
}

table, th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
}

th {
    background-color: #007bff;
    color: white;
}

td {
    background-color: #f9f9f9;
}

td a {
    padding: 6px 10px;
    border-radius: 5px;
    font-size: 14px;
}

td a:first-child {
    background-color: #28a745; 
}

td a:first-child:hover {
    background-color: #218838;
}

td a:last-child {
    background-color: #dc3545;
}

td a:last-child:hover {
    background-color: #c82333;
}
</head>
</style>
</html>
