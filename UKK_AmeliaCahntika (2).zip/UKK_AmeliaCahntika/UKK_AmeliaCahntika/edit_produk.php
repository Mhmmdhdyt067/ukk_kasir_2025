<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "ID Produk tidak ditemukan!";
    exit;
}

$produk_id = $_GET['id'];

// Ambil data produk berdasarkan ID
$query = mysqli_query($conn, "SELECT * FROM produk WHERE ProdukID = $produk_id");
$produk = mysqli_fetch_assoc($query);

if (!$produk) {
    echo "Produk tidak ditemukan!";
    exit;
}

// Jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);

    $update_query = "UPDATE produk SET NamaProduk = '$nama', Harga = '$harga', Stok = '$stok' WHERE ProdukID = $produk_id";
    
    if (mysqli_query($conn, $update_query)) {
        echo "<script>alert('Produk berhasil diperbarui!'); window.location='produk.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
</head>
<body>
    <h1>Edit Produk</h1>
    <form action="" method="POST">
        <label for="nama">Nama Produk:</label>
        <input type="text" id="nama" name="nama" value="<?php echo $produk['NamaProduk']; ?>" required>

        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" step="0.01" value="<?php echo $produk['Harga']; ?>" required>

        <label for="stok">Stok:</label>
        <input type="number" id="stok" name="stok" value="<?php echo $produk['Stok']; ?>" required>

        <button type="submit">Simpan Perubahan</button>
        <a href="produk.php">Batal</a>
    </form>
</body>
<head>
    <style>
        /* Formulir */
form {
    width: 50%;
    margin: 20px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}

input {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    border: none;
    cursor: pointer;
    margin-top: 10px;
}

button:hover {
    background-color: #45a049;
}

a {
    display: inline-block;
    padding: 10px 15px;
    text-decoration: none;
    background-color: #f44336;
    color: white;
    margin-top: 10px;
    border-radius: 5px;
}

a:hover {
    background-color: #d32f2f;
}
</head>
</style>
</html>
