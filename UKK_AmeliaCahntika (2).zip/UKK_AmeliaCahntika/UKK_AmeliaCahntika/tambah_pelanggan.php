<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $telepon = mysqli_real_escape_string($conn, $_POST['telepon']);

    $query = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$telepon')";
    if (mysqli_query($conn, $query)) {

        echo "<script>alert('Pelanggan berhasil ditambahkan!'); window.location='pelanggan.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
</head>
<body>
    <h1>Tambah Pelanggan</h1>
    <form action="" method="POST">
        <label for="nama">Nama Pelanggan:</label>
        <input type="text" id="nama" name="nama" required>

        <label for="alamat">Alamat:</label>
        <textarea id="alamat" name="alamat" required></textarea>

        <label for="telepon">Nomor Telepon:</label>
        <input type="text" id="telepon" name="telepon" required>

        <button type="submit">Simpan</button>
        <a href="pelanggan.php">Batal</a>
    </form>
</body>
<head>
    <style>
form {
    width: 50%;
    margin: 20px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}

h1 {
    color: #333;
    text-align: center;
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}

input, textarea {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    border: none;
    cursor: pointer;
    margin-top: 10px;
}

button:hover {
    background-color: #45a049;
}

a {
    display: inline-block;
    padding: 10px 15px;
    text-align: justify;
    background-color: #f44336;
    color: white;
    margin-top: 10px;
    border-radius: 5px;
}

a:hover {
    background-color: #d32f2f;
}
</head>
</style>
</html>
