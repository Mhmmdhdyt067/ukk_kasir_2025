<?php
include 'db.php';
$query_pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");

$query_produk = mysqli_query($conn, "SELECT * FROM produk");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pelanggan_id = $_POST['pelanggan_id'];
    $tanggal = date("Y-m-d"); 
    $query = "INSERT INTO penjualan (PelangganID, TanggalPenjualan, TotalHarga) VALUES ('$pelanggan_id', '$tanggal', 0)";
    if (mysqli_query($conn, $query)) {
        $penjualan_id = mysqli_insert_id($conn); 

        $total_harga = 0;
        foreach ($_POST['produk'] as $produk_id => $jumlah) {
            if ($jumlah > 0) {
                $result = mysqli_query($conn, "SELECT Harga FROM produk WHERE ProdukID = '$produk_id'");
                $produk = mysqli_fetch_assoc($result);
                $harga = $produk['Harga'];
                $subtotal = $harga * $jumlah;
                $total_harga += $subtotal;

                mysqli_query($conn, "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) 
                                     VALUES ('$penjualan_id', '$produk_id', '$jumlah', '$subtotal')");

                mysqli_query($conn, "UPDATE produk SET Stok = Stok - $jumlah WHERE ProdukID = '$produk_id'");
            }
        }

        mysqli_query($conn, "UPDATE penjualan SET TotalHarga = '$total_harga' WHERE PenjualanID = '$penjualan_id'");

        echo "<script>alert('Penjualan berhasil ditambahkan!'); window.location='penjualan.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Penjualan</title>
</head>
<body>
    <h1>Tambah Penjualan</h1>
    <form method="post">
        <label>Pilih Pelanggan:</label>
        <select name="pelanggan_id" required>
            <option value="">-- Pilih Pelanggan --</option>
            <?php while ($pelanggan = mysqli_fetch_assoc($query_pelanggan)) : ?>
                <option value="<?php echo $pelanggan['PelangganID']; ?>"><?php echo $pelanggan['NamaPelanggan']; ?></option>
            <?php endwhile; ?>
        </select>

        <h2>Pilih Produk:</h2>
        <?php while ($produk = mysqli_fetch_assoc($query_produk)) : ?>
            <label>
                <input type="number" name="produk[<?php echo $produk['ProdukID']; ?>]" min="0" max="<?php echo $produk['Stok']; ?>" value="0">
                <?php echo $produk['NamaProduk']; ?> (Stok: <?php echo $produk['Stok']; ?>) - Rp <?php echo number_format($produk['Harga'], 2, ',', '.'); ?>
            </label>
            <br>
        <?php endwhile; ?>

        <button type="submit">Simpan Penjualan</button>
    </form>
    <a href="penjualan.php">Kembali</a>
</body>
<head>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 20px;
    padding: 0;
    background-color: #f4f4f4;
}

h1 {
    color: #333;
    text-align: center;
    margin-bottom: 20px;
}

body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}

form {
    background: #fff;
    padding: 20px;
    max-width: 500px;
    margin: 20px auto;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
    color: #555;
}

select, input[type="number"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

button {
    background-color:rgb(70, 223, 239);
    color: white;
    padding: 10px;
    margin-top: 15px;
    width: 100%;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: rgb(70, 223, 239);
}

a {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
}

a:hover {
    text-decoration: underline;
}

h2 {
    text-align: center;
    color: #333;
    margin-top: 20px;
}

label input {
    margin-right: 10px;
}
</head>
</style>
</html>