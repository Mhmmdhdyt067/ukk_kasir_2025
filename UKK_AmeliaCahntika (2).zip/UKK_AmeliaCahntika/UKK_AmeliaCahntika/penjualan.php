<?php
include 'db.php';

$result = mysqli_query($conn, "SELECT penjualan.PenjualanID, penjualan.TanggalPenjualan, penjualan.TotalHarga, pelanggan.NamaPelanggan FROM penjualan INNER JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Penjualan</title>
</head>
<body>
    <h1>Data Penjualan</h1>
    <a href="index.php">Kembali ke Dashboard</a>
    <table border="1">
        <tr>
            <th>ID Penjualan</th>
            <th>Tanggal</th>
            <th>Total Harga</th>
            <th>Pelanggan</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?php echo $row['PenjualanID']; ?></td>
            <td><?php echo $row['TanggalPenjualan']; ?></td>
            <td><?php echo $row['TotalHarga']; ?></td>
            <td><?php echo $row['NamaPelanggan']; ?></td>
            <td>
                <a href="detail_penjualan.php?id=<?php echo $row['PenjualanID']; ?>">Detail</a>
                <a href="delete_penjualan.php?id=<?php echo $row['PenjualanID']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="tambah_penjualan.php">Tambah Penjualan</a>
</body>
<head>
    <style>
 body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}

h1 {
    color: #333;
}

a {
    text-decoration: none;
    color: white;
    background-color:rgb(40, 169, 212);
    padding: 10px 15px;
    border-radius: 5px;
    display: inline-block;
    margin-bottom: 10px;
}

a:hover {
    background-color:rgb(40, 169, 212);
}

table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: center;
}

th {
    background-color: #007bff;
    color: white;
}

td a {
    background-color: #dc3545;
    padding: 5px 10px;
    border-radius: 3px;
}

td a:hover {
    background-color: #c82333;
}
</style>
</head>
</html>