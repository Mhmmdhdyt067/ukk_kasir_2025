<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "ID Penjualan tidak ditemukan!";
    exit;
}

$penjualan_id = $_GET['id']; 

$query_penjualan = mysqli_query($conn, "SELECT penjualan.PenjualanID, penjualan.TanggalPenjualan, penjualan.TotalHarga, pelanggan.NamaPelanggan 
    FROM penjualan 
    INNER JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
    WHERE penjualan.PenjualanID = $penjualan_id");


$penjualan = mysqli_fetch_assoc($query_penjualan);


if (!$penjualan) {
    echo "Data penjualan tidak ditemukan!";
    exit;
}

$query_detail = mysqli_query($conn, "SELECT detailpenjualan.JumlahProduk, detailpenjualan.Subtotal, 
    produk.NamaProduk, produk.Harga 
    FROM detailpenjualan 
    INNER JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
    WHERE detailpenjualan.PenjualanID = $penjualan_id");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penjualan</title>
</head>
<body>
    <h1>Detail Penjualan</h1>
    <p><strong>ID Penjualan:</strong> <?php echo $penjualan['PenjualanID']; ?></p>
    <p><strong>Tanggal Penjualan:</strong> <?php echo $penjualan['TanggalPenjualan']; ?></p>
    <p><strong>Pelanggan:</strong> <?php echo $penjualan['NamaPelanggan']; ?></p>
    <p><strong>Total Harga:</strong> Rp <?php echo number_format($penjualan['TotalHarga'], 2, ',', '.'); ?></p>

    <h2>Produk yang Dibeli</h2>
    <table border="1">
        <tr>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
        </tr>
        <?php while ($detail = mysqli_fetch_assoc($query_detail)) : ?>
        <tr>
            <td><?php echo $detail['NamaProduk']; ?></td>
            <td>Rp <?php echo number_format($detail['Harga'], 2, ',', '.'); ?></td>
            <td><?php echo $detail['JumlahProduk']; ?></td>
            <td>Rp <?php echo number_format($detail['Subtotal'], 2, ',', '.'); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <a href="penjualan.php">Kembali ke Daftar Penjualan</a>
</body>
<head>
    <style>
body {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    background: linear-gradient(to right,rgb(249, 247, 251),hsl(218, 96.20%, 79.60%));
    margin: 20px;
    padding: 20px;
}


h1, h2 {
    text-align: center;
    color:rgb(28, 31, 29);
}

p {
    font-size: 18px;
    margin: 5px 0;
}

strong {
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    margin-top: 20px;
}

th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}

th {
    background-color:rgb(59, 37, 183);
    color: white;
}

a {
    display: inline-block;
    text-decoration: none;
    padding: 10px 15px;
    border-radius: 5px;
    background-color: #008CBA;
    color: white;
    margin-top: 20px;
    text-align: center;
}

a:hover {
    background-color: #005f73;
}
</head>
</style>
<html>
