<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Pengelolaan Basis Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #D4EDDA ;
        }
        .card:hover {
            transform: scale(1.05);
            transition: 0.3s;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
        <div class="container d-flex justify-content-center">
        <div class="card-header text-center bg-success text-white">
           <h2>Dashboard Admin</h2>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h2 class="text-center text-success mb-5">Aplikasi Pengelolaan Basis Data</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">👤 Data Pelanggan</h5>
                        <a href="pelanggan.php" class="btn btn-success">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">🛍 Manajemen Produk</h5>
                        <a href="produk.php" class="btn btn-success">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">💰 Manajemen Penjualan</h5>
                        <a href="penjualan.php" class="btn btn-success">Lihat</a>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>