<?php 
include 'db.php'; 

if (!isset($_GET['id'])) { 
    header("Location: penjualan.php"); 
    exit(); 
}

$id = $_GET['id']; 
$query = "SELECT penjualan.*, pelanggan.nama AS pelanggan_nama, pelanggan.alamat, pelanggan.nomor_telepon 
          FROM penjualan 
          JOIN pelanggan ON penjualan.pelanggan_id = pelanggan.id 
          WHERE penjualan.id = '$id'"; 
$result = mysqli_query($conn, $query); 
$penjualan = mysqli_fetch_assoc($result); 

$query_detail = "SELECT detail_penjualan.*, produk.nama AS produk_nama 
                 FROM detail_penjualan 
                 JOIN produk ON detail_penjualan.produk_id = produk.id 
                 WHERE detail_penjualan.penjualan_id = '$id'"; 
$result_detail = mysqli_query($conn, $query_detail); 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Detail Penjualan</title> 
    <link rel="stylesheet" href="css/style.css"> 
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3> 
            <li><a href="index.php">Dashboard</a></li> 
            <li><a href="produk.php">Produk</a></li> 
            <li><a href="pelanggan.php">Pelanggan</a></li> 
            <li><a href="penjualan.php">Penjualan</a></li> 
        </ul>
    </nav>

    <div class="container">
        <h1>Detail Penjualan</h1> 
        <p><strong>ID:</strong> <?= $penjualan['id']; ?></p> 
        <p><strong>Tanggal:</strong> <?= $penjualan['tanggal']; ?></p> 
        <p><strong>Pelanggan:</strong> <?= $penjualan['pelanggan_nama']; ?></p> 
        <p><strong>Alamat:</strong> <?= $penjualan['alamat']; ?></p>
        <p><strong>Nomor Telepon:</strong> <?= $penjualan['nomor_telepon']; ?></p> 
        <p><strong>Total Harga:</strong> <?= $penjualan['total_harga']; ?></p>
        <h2>Detail Produk</h2> 
        <table>
            <thead>
                <tr>
                    <th>Produk</th> 
                    <th>Harga</th> 
                    <th>Jumlah</th> 
                    <th>Subtotal</th> 
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result_detail)) { ?> 
                <tr>
                    <td><?= $row['produk_nama']; ?></td> 
                    <td><?= $row['harga']; ?></td> 
                    <td><?= $row['jumlah']; ?></td> 
                    <td><?= $row['subtotal']; ?></td> 
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <br>
        <a href="penjualan.php" class="btn-kembali">Kembali ke Penjualan</a> 
