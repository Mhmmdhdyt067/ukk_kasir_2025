<?php
include 'db.php';


if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID produk tidak ditemukan!");
}

$id = $_GET['id'];


$query = "SELECT * FROM produk WHERE id = '$id'";
$result = mysqli_query($conn, $query);
$produk = mysqli_fetch_assoc($result);

if (!$produk) {
    die("Produk tidak ditemukan!");
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);

    
    $updateQuery = "UPDATE produk SET nama='$nama', harga='$harga', stok='$stok' WHERE id='$id'";
    if (mysqli_query($conn, $updateQuery)) {
        header("Location: produk.php");
        exit();
    } else {
        echo "Gagal mengupdate produk: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="pelanggan.php">Pelanggan</a></li>
            <li><a href="penjualan.php">Penjualan</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Edit Produk</h1>
        <form method="POST" action="" class="tambah">
            <label for="nama">Nama Produk:</label>
            <input type="text" id="nama" name="nama" value="<?= $produk['nama']; ?>" required>

            <label for="harga">Harga:</label>
            <input type="number" id="harga" name="harga" value="<?= $produk['harga']; ?>" required>

            <label for="stok">Stok:</label>
            <input type="number" id="stok" name="stok" value="<?= $produk['stok']; ?>" required>

            <button type="submit" class="btn-form">Simpan</button>
            <button type="button" onclick="window.location.href='produk.php'" class="btn-form">Batal</button>
        </form>
    </div>
</body>
</html>
