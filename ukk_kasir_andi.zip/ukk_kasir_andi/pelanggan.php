<?php 
include 'db.php';

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE id='$id'");
    header("Location: pelanggan.php");
}


$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';


$query = "SELECT * FROM pelanggan  WHERE nama LIKE '%$search%'";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Pelanggan</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="pelanggan.php">Pelanggan</a></li>
            <li><a href="penjualan.php">Penjualan</a></li>
        </ul>
    </nav>

    <div class="container">
    <h1>Manajemen Pelanggan</h1>

    
    <a href="tambah_pelanggan.php" class="btn-tambah">Tambah Pelanggan</a>

     
     <form method="GET" action="pelanggan.php" class="search-form">
            <input type="text" name="search" placeholder="Cari Nama Pelanggan..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Cari</button>
            <button class="reset" onclick="window.location.href='pelanggan.php'">Reset</button>
    </form>

    
    <h2>Daftar Pelanggan</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>NAMA</th>
                <th>ALAMAT</th>
                <th>NOMOR TELEPON</th>
                <th>AKSI</th>
            </tr>
        </thead>
        <tbody>
        <?php 
        $result = mysqli_query($conn, "SELECT * FROM pelanggan");
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['nama']; ?></td>
                <td><?= $row['alamat']; ?></td>
                <td><?= $row['nomor_telepon']; ?></td>
                <td>
                    <a href="edit_pelanggan.php?id=<?= $row['id']; ?>">Edit</a> 
                    <a href="pelanggan.php?hapus=<?= $row['id']; ?>">Hapus</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

    
</body>
</html>