<?php
include 'db.php'; // Menghubungkan ke database dengan menyertakan file koneksi

// Ambil daftar pelanggan
$pelanggan_query = "SELECT id, nama FROM pelanggan"; // Query untuk mengambil ID dan nama pelanggan dari tabel pelanggan
$pelanggan_result = mysqli_query($conn, $pelanggan_query); // Menjalankan query dan menyimpan hasilnya

// Ambil daftar produk
$produk_query = "SELECT id, nama, harga FROM produk"; // Query untuk mengambil ID, nama, dan harga produk dari tabel produk
$produk_result = mysqli_query($conn, $produk_query); // Menjalankan query dan menyimpan hasilnya

// Proses form ketika dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Mengecek apakah form dikirim menggunakan metode POST
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']); // Mengamankan input tanggal
    $pelanggan_id = mysqli_real_escape_string($conn, $_POST['pelanggan_id']); // Mengamankan input pelanggan_id
    $produk_id = mysqli_real_escape_string($conn, $_POST['produk_id']); // Mengamankan input produk_id
    $jumlah = mysqli_real_escape_string($conn, $_POST['jumlah']); // Mengamankan input jumlah produk

    // Ambil harga produk
    $harga_query = "SELECT harga FROM produk WHERE id = '$produk_id'"; // Query untuk mengambil harga produk berdasarkan ID produk
    $harga_result = mysqli_query($conn, $harga_query); // Menjalankan query
    $harga_row = mysqli_fetch_assoc($harga_result); // Mengambil hasil query sebagai array asosiatif
    $harga = $harga_row['harga']; // Menyimpan harga produk dalam variabel
    $subtotal = $harga * $jumlah; // Menghitung subtotal harga berdasarkan jumlah produk yang dibeli

    // Simpan data ke tabel penjualan terlebih dahulu
    $query_penjualan = "INSERT INTO penjualan (tanggal, pelanggan_id, total_harga) 
                        VALUES ('$tanggal', '$pelanggan_id', '$subtotal')"; // Query untuk menyimpan data penjualan

    if (mysqli_query($conn, $query_penjualan)) { // Mengeksekusi query penjualan dan memeriksa apakah berhasil
        // Ambil ID terakhir yang baru saja dimasukkan
        $penjualan_id = mysqli_insert_id($conn); // Mendapatkan ID terakhir yang dimasukkan ke tabel penjualan

        // Simpan data ke tabel detail_penjualan
        $query_detail = "INSERT INTO detail_penjualan (penjualan_id, produk_id, harga, jumlah, subtotal) 
                         VALUES ('$penjualan_id', '$produk_id', '$harga', '$jumlah', '$subtotal')"; // Query untuk menyimpan detail penjualan

        if (mysqli_query($conn, $query_detail)) { // Mengeksekusi query detail penjualan dan memeriksa apakah berhasil
            header("Location: penjualan.php"); // Mengarahkan ke halaman penjualan setelah berhasil menyimpan data
            exit(); // Menghentikan eksekusi script setelah pengalihan halaman
        } else {
            echo "Gagal menambahkan detail penjualan: " . mysqli_error($conn); // Menampilkan pesan error jika gagal menyimpan detail penjualan
        }
    } else {
        echo "Gagal menambahkan penjualan: " . mysqli_error($conn); // Menampilkan pesan error jika gagal menyimpan penjualan
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> <!-- Menentukan karakter set sebagai UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Menyesuaikan tampilan untuk perangkat mobile -->
    <title>Tambah Penjualan</title> <!-- Judul halaman -->
    <link rel="stylesheet" href="css/style.css"> <!-- Memuat file CSS eksternal -->
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3> <!-- Judul navigasi -->
            <li><a href="index.php">Dashboard</a></li> <!-- Link menuju halaman dashboard -->
            <li><a href="produk.php">Produk</a></li> <!-- Link menuju halaman produk -->
            <li><a href="pelanggan.php">Pelanggan</a></li> <!-- Link menuju halaman pelanggan -->
            <li><a href="penjualan.php">Penjualan</a></li> <!-- Link menuju halaman penjualan -->
        </ul>
    </nav>
    <div class="container">
        <h1>Tambah Penjualan</h1> <!-- Judul utama halaman -->

        <!-- Form Tambah Penjualan -->
        <form method="POST" action="" class="tambah">
            <label for="tanggal">Tanggal Penjualan</label>
            <input type="date" id="tanggal" name="tanggal" required> <!-- Input tanggal penjualan -->

            <label for="pelanggan_id">Pelanggan</label>
            <select id="pelanggan_id" name="pelanggan_id" class="form-control" required> <!-- Dropdown untuk memilih pelanggan -->
                <option value="">Pilih Pelanggan</option>
                 <?php while ($row = mysqli_fetch_assoc($pelanggan_result)) { ?> <!-- Loop untuk menampilkan daftar pelanggan -->
                     <option value="<?= $row['id']; ?>"><?= $row['nama']; ?></option> <!-- Menampilkan opsi pelanggan -->
                <?php } ?>
            </select>

            <label for="produk_id">Produk</label>
            <select id="produk_id" name="produk_id" class="form-control" required> <!-- Dropdown untuk memilih produk -->
                <option value="">Pilih Produk</option>
                <?php while ($row = mysqli_fetch_assoc($produk_result)) { ?> <!-- Loop untuk menampilkan daftar produk -->
                    <option value="<?= $row['id']; ?>"><?= $row['nama']; ?> - Rp <?= number_format($row['harga'], 0, ',', '.'); ?></option> <!-- Menampilkan opsi produk beserta harga -->
                <?php } ?>
            </select>

            <label for="jumlah">Jumlah Produk</label>
            <input type="number" id="jumlah" name="jumlah" required min="1"> <!-- Input jumlah produk -->

            <button type="submit" class="btn-form">Simpan</button> <!-- Tombol submit untuk menyimpan data -->
            <button type="button" onclick="window.location.href='produk.php'" class="btn-form">Batal</button> <!-- Tombol batal yang mengarahkan kembali ke halaman produk -->
        </form>
    </div>
</body>
</html>
