<?php
include 'db.php';

// Cek apakah ada parameter ID di URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID pelanggan tidak ditemukan!");
}

$id = $_GET['id'];

// Ambil data pelanggan berdasarkan ID
$query = "SELECT * FROM pelanggan WHERE id = '$id'";
$result = mysqli_query($conn, $query);
$pelanggan = mysqli_fetch_assoc($result);

if (!$pelanggan) {
    die("Pelanggan tidak ditemukan!");
}

// Jika tombol Update ditekan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $nomor_telepon = mysqli_real_escape_string($conn, $_POST['nomor_telepon']);

    // Update produk dalam database
    $updateQuery = "UPDATE pelanggan SET nama='$nama', alamat='$alamat', nomor_telepon='$nomor_telepon' WHERE id='$id'";
    if (mysqli_query($conn, $updateQuery)) {
        header("Location: pelanggan.php");
        exit();
    } else {
        echo "Gagal mengupdate pelanggan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelanggan</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="pelanggan.php">Pelanggan</a></li>
            <li><a href="penjualan.php">Penjualan</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Edit Pelanggan</h1>
        <form method="POST" action="" class="tambah">
            <label for="nama">Nama Pelanggan:</label>
            <input type="text" id="nama" name="nama" value="<?= $pelanggan['nama']; ?>" required>

            <label for="alamat">Alamat:</label>
            <input type="text" id="alamat" name="alamat" value="<?= $pelanggan['alamat']; ?>" required>

            <label for="telepon">Nomor Telepon:</label>
            <input type="tel" id="nomor_telepon" name="nomor_telepon" value="<?= $pelanggan['nomor_telepon']; ?>" required>

            <button type="submit" class="btn-form">Simpan</button>
            <button type="button" onclick="window.location.href='pelanggan.php'" class="btn-form">Batal</button>
        </form>
    </div>
</body>
</html>
