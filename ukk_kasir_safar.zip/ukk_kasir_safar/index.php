<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir</title>
    <link rel="stylesheet" href="css/style.css"> <!-- link style untuk menghubungkan dengan style.css -->
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3> 
            <li><a href="index.php">Dashboard</a></li> <!-- Link Navbar yang mengarahkan ke halaman index.php (halaman utama) -->
            <li><a href="produk.php">Produk</a></li> <!-- Link Navbar yang mengarahkan ke halaman produk -->
            <li><a href="pelanggan.php">Pelanggan</a></li> <!-- Link Navbar yang mengarahkan ke halaman Pelanggan -->
            <li><a href="penjualan.php">Penjualan</a></li> <!-- Link Navbar yang mengarahkan ke halaman Penjualan -->
        </ul>
    </nav>
    
    <div class="container">
        <h1>Dashboard</h1>
        <div class="info-box">
        <div class="card">
            <h3>Total Produk
                <p>
                <?php 
                $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM produk"); //looping pengambilan data total dari tabel produk 
                $data = mysqli_fetch_assoc($result);
                echo $data['total']; //perintah mencetak data total dan menampilkannya di halaman browser 
                ?>
                </p>
            </h3>
        </div>
        <div class="card">
            <h3>Total Pelanggan 
                <p> <?php 
                $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM pelanggan"); //looping pengambilan data total dari tabel produk 
                $data = mysqli_fetch_assoc($result);
                echo $data['total']; //perintah mencetak data total dan menampilkannya 
                ?>
                </p>
            </h3>
        </div>
        <div class="card">
            <h3>Total Penjualan
                <p>
                <?php 
                $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM penjualan");
                $data = mysqli_fetch_assoc($result);
                echo $data['total'];
                ?>
                </p>
            </h3>
        </div>
        </div>
    </div>
</body>
</html>
