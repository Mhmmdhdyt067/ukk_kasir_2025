<?php 
include 'db.php';


if (isset($_GET['hapus'])) { 
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM penjualan WHERE id='$id'"); 
    header("Location: penjualan.php"); 
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT penjualan.*, pelanggan.nama AS pelanggan_nama 
          FROM penjualan 
          JOIN pelanggan ON penjualan.pelanggan_id = pelanggan.id 
          WHERE nama LIKE '%$search%'";
$result = mysqli_query($conn, $query);



?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Manajemen Penjualan</title> 
    <link rel="stylesheet" href="css/style.css"> 
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3> 
            <li><a href="index.php">Dashboard</a></li> 
            <li><a href="produk.php">Produk</a></li> 
            <li><a href="pelanggan.php">Pelanggan</a></li> 
            <li><a href="penjualan.php">Penjualan</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Manajemen Penjualan</h1> 

        
        <a href="tambah_penjualan.php" class="btn-tambah">Tambah Penjualan</a> 

        
        <form method="GET" action="penjualan.php" class="search-form">
            <input type="text" name="search" placeholder="Cari id penjualan..." value="<?= htmlspecialchars($search) ?>"> 
            <button type="submit">Cari</button> 
            <button class="reset">Reset</button> 
        </form>

        
        <h2>Daftar Penjualan</h2> 
        <table>
            <thead>
                <tr>
                    <th>ID</th> 
                    <th>TANGGAL</th> 
                    <th>PELANGGAN</th> 
                    <th>TOTAL HARGA</th> 
                    <th>AKSI</th> 
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?> 
                <tr>
                    <td><?= $row['id']; ?></td> 
                    <td><?= $row['tanggal']; ?></td> 
                    <td><?= $row['pelanggan_nama']; ?></td> 
                    <td><?= $row['total_harga']; ?></td> 
                    <td>
                        <a href="detail_penjualan.php?id=<?= $row['id']; ?>" class="detail-button">Detail</a> 
                        <a href="penjualan.php?hapus=<?= $row['id']; ?>">Hapus</a> 
                    </td>
                </tr>
            <?php } ?> 
            </tbody>
        </table>
    </div>
</body>
</html>
