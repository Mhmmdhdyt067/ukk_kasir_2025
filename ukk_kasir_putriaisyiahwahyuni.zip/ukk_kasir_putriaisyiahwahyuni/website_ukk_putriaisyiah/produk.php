<?php 
include 'db.php';

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    mysqli_begin_transaction($conn); // Memulai transaksi

    $query = "DELETE FROM produk WHERE id='$id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        mysqli_commit($conn); // Jika berhasil, simpan perubahan
        header("Location: produk.php");
        exit();
    } else {
        mysqli_rollback($conn); // Jika gagal, batalkan perubahan
        echo "Gagal menghapus data!";
    }
}

// Mengambil data pencarian dari input user
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Query untuk mencari berdasarkan nama produk
$query = "SELECT * FROM produk WHERE nama LIKE '%$search%'";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk</title>
    <link rel="stylesheet" href="css/style.css">
    <script>
        function konfirmasiHapus(event) {
            var yakin = confirm("Apakah Anda yakin ingin menghapus produk ini?");
            if (!yakin) {
                event.preventDefault(); // Mencegah penghapusan jika pengguna membatalkan
            }
        }
    </script>
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database Putri</h3>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="pelanggan.php">Pelanggan</a></li>
            <li><a href="penjualan.php">Penjualan</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Manajemen Produk</h1>

        <!-- Tombol Tambah Produk -->
        <a href="tambah_produk.php" class="btn-tambah">Tambah Produk</a>

        <!-- Form Pencarian -->
        <form method="GET" action="produk.php" class="search-form">
            <input type="text" name="search" placeholder="Cari Nama Produk..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Cari</button>
            <button type="button" class="reset" onclick="window.location.href='produk.php'">Reset</button>
        </form>

        <!-- Daftar Produk -->
        <h2>Daftar Produk</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAMA</th>
                    <th>HARGA</th>
                    <th>STOK</th>
                    <th>AKSI</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['nama']; ?></td>
                    <td><?= $row['harga']; ?></td>
                    <td><?= $row['stok']; ?></td>
                    <td>
                        <a href="edit_produk.php?id=<?= $row['id']; ?>">Edit</a> 
                        <a href="produk.php?hapus=<?= $row['id']; ?>" onclick="konfirmasiHapus(event)">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
