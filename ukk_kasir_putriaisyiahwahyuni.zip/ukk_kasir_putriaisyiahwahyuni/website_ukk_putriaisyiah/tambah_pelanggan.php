<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $nomor_telepon = mysqli_real_escape_string($conn, $_POST['nomor_telepon']);
    
    $query = "INSERT INTO pelanggan (nama, alamat, nomor_telepon) VALUES ('$nama', '$alamat', '$nomor_telepon')";
    if (mysqli_query($conn, $query)) {
        header("Location: pelanggan.php");
        exit();
    } else {
        echo "Gagal menambahkan pelanggan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav>
        <ul>
            <h3> Sistem Pengelolaan Database Putri</h3>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="pelanggan.php">Pelanggan</a></li>
            <li><a href="penjualan.php">Penjualan</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>Tambah Pelanggan</h1>
        <form method="POST" action="" class="tambah">
            <label for="nama">Nama Pelanggan:</label>
            <input type="text" id="nama" name="nama" required>
            
            <label for="alamat">Alamat:</label>
            <input type="text" id="alamat" name="alamat" required>
            
            <label for="telepon">Nomor Telepon:</label>
            <input type="tel" id="nomor_telepon" name="nomor_telepon" required pattern="[0-9]{10,15}" title="Masukkan nomor telepon yang valid (10-15 digit angka)">
            
            <button type="submit" class="btn-form">Simpan</button>
            <button type="button" onclick="window.location.href='produk.php'" class="btn-form">Batal</button>
        </form>
    </div>
</body>
</html>
