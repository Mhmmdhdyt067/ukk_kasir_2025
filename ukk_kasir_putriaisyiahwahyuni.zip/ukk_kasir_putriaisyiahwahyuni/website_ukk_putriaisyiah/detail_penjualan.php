<?php 
include 'db.php'; // Menghubungkan file ini dengan database melalui koneksi yang ada di 'db.php'

if (!isset($_GET['id'])) { // Mengecek apakah parameter 'id' tersedia di URL
    header("Location: penjualan.php"); // Jika tidak ada, pengguna diarahkan kembali ke halaman 'penjualan.php'
    exit(); // Menghentikan eksekusi kode selanjutnya
}

$id = $_GET['id']; // Mengambil nilai 'id' dari parameter URL
$query = "SELECT penjualan.*, pelanggan.nama AS pelanggan_nama, pelanggan.alamat, pelanggan.nomor_telepon 
          FROM penjualan 
          JOIN pelanggan ON penjualan.pelanggan_id = pelanggan.id 
          WHERE penjualan.id = '$id'"; // Query untuk mengambil data penjualan berdasarkan ID serta informasi pelanggan terkait
$result = mysqli_query($conn, $query); // Menjalankan query
$penjualan = mysqli_fetch_assoc($result); // Mengambil hasil query dalam bentuk array asosiatif

$query_detail = "SELECT detail_penjualan.*, produk.nama AS produk_nama 
                 FROM detail_penjualan 
                 JOIN produk ON detail_penjualan.produk_id = produk.id 
                 WHERE detail_penjualan.penjualan_id = '$id'"; // Query untuk mengambil detail produk yang terkait dengan  

$result_detail = mysqli_query($conn, $query_detail); // Menjalankan query dan menyimpan hasilnya
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> <!-- Menentukan karakter encoding sebagai UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Menyesuaikan tampilan agar responsif -->
    <title>Detail Penjualan</title> <!-- Judul halaman -->
    <link rel="stylesheet" href="css/style.css"> <!-- Menghubungkan halaman dengan file CSS eksternal -->
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database Putri</h3> <!-- Judul menu navigasi -->
            <li><a href="index.php">Dashboard</a></li> <!-- Link menuju dashboard -->
            <li><a href="produk.php">Produk</a></li> <!-- Link menuju halaman produk -->
            <li><a href="pelanggan.php">Pelanggan</a></li> <!-- Link menuju halaman pelanggan -->
            <li><a href="penjualan.php">Penjualan</a></li> <!-- Link menuju halaman penjualan -->
        </ul>
    </nav>

    <div class="container">
        <h1>Detail Penjualan</h1> <!-- Judul halaman -->
        <p><strong>ID:</strong> <?= $penjualan['id']; ?></p> <!-- Menampilkan ID transaksi -->
        <p><strong>Tanggal:</strong> <?= $penjualan['tanggal']; ?></p> <!-- Menampilkan tanggal transaksi -->
        <p><strong>Pelanggan:</strong> <?= $penjualan['pelanggan_nama']; ?></p> <!-- Menampilkan nama pelanggan -->
        <p><strong>Alamat:</strong> <?= $penjualan['alamat']; ?></p> <!-- Menampilkan alamat pelanggan -->
        <p><strong>Nomor Telepon:</strong> <?= $penjualan['nomor_telepon']; ?></p> <!-- Menampilkan nomor telepon pelanggan -->
        <p><strong>Total Harga:</strong> <?= $penjualan['total_harga']; ?></p> <!-- Menampilkan total harga transaksi -->
        
        <h2>Detail Produk</h2> <!-- Subjudul untuk daftar produk dalam transaksi -->
        <table>
            <thead>
                <tr>
                    <th>Produk</th> <!-- Kolom nama produk -->
                    <th>Harga</th> <!-- Kolom harga produk -->
                    <th>Jumlah</th> <!-- Kolom jumlah produk yang dibeli -->
                    <th>Subtotal</th> <!-- Kolom subtotal harga produk -->
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result_detail)) { ?> <!-- Perulangan untuk menampilkan detail transaksi -->
                <tr>
                    <td><?= $row['produk_nama']; ?></td> <!-- Menampilkan nama produk -->
                    <td><?= $row['harga']; ?></td> <!-- Menampilkan harga produk -->
                    <td><?= $row['jumlah']; ?></td> <!-- Menampilkan jumlah produk -->
                    <td><?= $row['subtotal']; ?></td> <!-- Menampilkan subtotal harga berdasarkan jumlah produk -->
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <br>
        <a href="penjualan.php" class="btn-kembali">Kembali ke Penjualan</a> <!-- Tombol untuk kem
