<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $TotalHarga = $_POST['TotalHarga'];
    $sql = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) VALUES ('$tanggal', '$pelangganID', $TotalHarga)";
    mysqli_query($conn, $sql);
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM penjualan WHERE PenjualanID = $id");
}

// Ambil Data
$result = mysqli_query($conn, "SELECT * FROM penjualan");
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            width: 300px;
        }

        label {
            margin-bottom: 5px;
        }

        input[type="date"],
        select,
        input[type="number"] {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color:rgb(222, 52, 157);
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color:rgb(0, 0, 0);
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            color:rgb(221, 187, 214);
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <h2>Data Penjualan</h2>

    <form method="POST">
        <label>Tanggal:</label>
        <input type="date" name="tanggal" required>
        <label>Pelanggan:</label>
        <select name="pelangganID">
            <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
            <?php } ?>
        </select>

        <label>Total Harga:</label>
        <input type="number" name="TotalHarga" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Total Harga</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['PenjualanID'] ?></td>
                <td><?= $row['TanggalPenjualan'] ?></td>
                <td><?= $row['PelangganID'] ?></td>
                <td>Rp <?= number_format($row['TotalHarga'], 2) ?></td>
                <td><a href="penjualan.php?hapus=<?= $row['PenjualanID'] ?>">Hapus</a></td>
            </tr>
        <?php } ?>
    </table>
    <a href="index.php" class="btn-dashboard">Kembali ke Dashboard</a>

</body>

</html>