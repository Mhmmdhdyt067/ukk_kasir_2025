<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color:rgb(219, 138, 209);
            padding: 50px;
        }
        h1 {
            color: #333;
        }
        a {
            display: block;
            margin: 10px auto;
            padding: 15px;
            width: 200px;
            text-decoration: none;
            color: white;
            background:rgb(0, 0, 0);
            border-radius: 5px;
            font-size: 18px;
        }
        a:hover {
            background:rgb(201, 100, 149);
        }
    </style>
</head>
<body>

    <h1>Dashboard Kasir</h1>
    <a href="pelanggan.php">Data Pelanggan</a>
    <a href="produk.php">Data Produk</a>
    <a href="penjualan.php">Data Penjualan</a>
    <a href="detailpenjualan.php">Detail Penjualan</a>

</body>
</html>