<?php
include "koneksi.php";

// Tambah Data Produk
if (isset($_POST['tambah'])) {
    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = $conn->prepare("INSERT INTO produk (NamaProduk, Harga, Stok) VALUES (?,?,?)");
    $stmt->bind_param("sii", $nama_produk, $harga, $stok); // "sii" karena string dan dua integer

    if ($stmt->execute()) {
        echo "<script>alert('Data produk berhasil ditambahkan.'); window.location.href='produk.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Edit Data Produk
if (isset($_POST['edit'])) {
    $produk_id = $_POST['produk_id'];
    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = $conn->prepare("UPDATE produk SET NamaProduk = ?, Harga = ?, Stok = ? WHERE ProdukID = ?");
    $stmt->bind_param("siii", $nama_produk, $harga, $stok, $produk_id);

    if ($stmt->execute()) {
        echo "<script>alert('Data produk berhasil diubah.'); window.location.href='produk.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Hapus Data Produk
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    $stmt = $conn->prepare("DELETE FROM produk WHERE ProdukID = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Data produk berhasil dihapus.'); window.location.href='produk.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Ambil Data Produk
$result_produk = $conn->query("SELECT * FROM produk");

// Ambil Data Produk Berdasarkan ID (untuk Edit)
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result_edit = $conn->query("SELECT * FROM produk WHERE ProdukID = $id");
    $edit_produk = $result_edit->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Produk</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            width: 400px;
        }

        select, input[type="text"], input[type="number"] {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color:rgb(245, 119, 147);
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        table {
            width: 90%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 5px rgba(157, 52, 52, 0.1);
            background-color: #fff;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color:rgb(196, 66, 170);
            color: white;
        }

        tr:nth-child(even) {
            background-color:rgb(216, 146, 146);
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Data Produk</h2>

    <!-- Form Tambah Produk -->
    <form method="POST">
        <input type="text" name="nama_produk" placeholder="Nama Produk" required>
        <input type="number" name="harga" placeholder="Harga Produk" required>
        <input type="number" name="stok" placeholder="Stok Produk" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <!-- Form Edit Produk -->
    <?php if (isset($edit_produk)) { ?>
        <form method="POST">
            <input type="hidden" name="produk_id" value="<?= $edit_produk['ProdukID'] ?>">
            <input type="text" name="nama_produk" value="<?= $edit_produk['NamaProduk'] ?>" required>
            <input type="number" name="harga" value="<?= $edit_produk['Harga'] ?>" required>
            <input type="number" name="stok" value="<?= $edit_produk['Stok'] ?>" required>
            <button type="submit" name="edit">Edit</button>
        </form>
    <?php } ?>

    <!-- Tabel Produk -->
    <table>
        <tr>
            <th>ID Produk</th>
            <th>Nama Produk</th>
            <th>Harga Produk</th>
            <th>Stok Produk</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row_produk = $result_produk->fetch_assoc()) { ?>
            <tr>
                <td><?= $row_produk['ProdukID'] ?></td>
                <td><?= $row_produk['NamaProduk'] ?></td>
                <td><?= $row_produk['Harga'] ?></td>
                <td><?= $row_produk['Stok'] ?></td>
                <td>
                    <a href="produk.php?edit=<?= $row_produk['ProdukID'] ?>">Edit</a> | 
                    <a href="produk.php?hapus=<?= $row_produk['ProdukID'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <a href="index.php" class="btn-dashboard">Kembali ke Dashboard</a>

</body>
</html>
