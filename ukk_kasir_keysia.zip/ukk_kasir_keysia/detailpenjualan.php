<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $penjualanID = $_POST['penjualanID'];
    $produkID = $_POST['produkID'];
    $jumlahProduk = $_POST['jumlahProduk'];

    // Ambil harga produk
    $queryHarga = mysqli_query($conn, "SELECT Harga, Stok FROM produk WHERE ProdukID = $produkID");
    $row = mysqli_fetch_assoc($queryHarga);
    $harga = $row['Harga'];
    $stok = $row['Stok'];
    
    // Pastikan stok mencukupi sebelum menambahkan transaksi
    if ($stok >= $jumlahProduk) {
        $subtotal = $harga * $jumlahProduk;

        // Insert ke detailpenjualan
        $sql = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) 
                VALUES ('$penjualanID', '$produkID', '$jumlahProduk', '$subtotal')";
        mysqli_query($conn, $sql);

        // Kurangi stok produk
        $updateStok = "UPDATE produk SET Stok = Stok - $jumlahProduk WHERE ProdukID = $produkID";
        mysqli_query($conn, $updateStok);
    } else {
        echo "<script>alert('Stok tidak mencukupi!');</script>";
    }
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    // Ambil data sebelum menghapus untuk mengembalikan stok
    $queryDetail = mysqli_query($conn, "SELECT * FROM detailpenjualan WHERE DetailID = $id");
    $row = mysqli_fetch_assoc($queryDetail);
    $produkID = $row['ProdukID'];
    $jumlahProduk = $row['JumlahProduk'];

    // Kembalikan stok produk
    $updateStok = "UPDATE produk SET Stok = Stok + $jumlahProduk WHERE ProdukID = $produkID";
    mysqli_query($conn, $updateStok);

    // Hapus data dari tabel detailpenjualan
    mysqli_query($conn, "DELETE FROM detailpenjualan WHERE DetailID = $id");
}

// Ambil Data
$result = mysqli_query($conn, 
    "SELECT detailpenjualan.*, produk.NamaProduk, penjualan.TanggalPenjualan 
     FROM detailpenjualan
     JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
     JOIN penjualan ON detailpenjualan.PenjualanID = penjualan.PenjualanID");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penjualan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* General Styling */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #f8d0e1, #f0c4d8);
            color: #333;
        }

        h2 {
            text-align: center;
            color: #4b2a73;
            margin-top: 40px;
            font-size: 32px;
            font-weight: 700;
            text-transform: uppercase;
        }

        /* Container Styling */
        .container {
            width: 85%;
            max-width: 1200px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 16px 50px rgba(0, 0, 0, 0.2);
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            font-size: 18px;
            color: #5c3b69;
            font-weight: 600;
        }

        select, input[type="number"] {
            padding: 14px 20px;
            border-radius: 10px;
            border: 1px solid #ddd;
            font-size: 16px;
            background-color: #f4e3f5;
            transition: 0.3s ease-in-out;
        }

        select:focus, input[type="number"]:focus {
            outline: none;
            border-color: #4b2a73;
            background-color: #fff;
        }

        button {
            background: linear-gradient(45deg, #4b2a73, #6b3a9e);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        button:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 16px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f8d0e1;
            color: #4b2a73;
            font-size: 16px;
            font-weight: 600;
        }

        td {
            background-color: #f9f1f9;
            color: #555;
        }

        tr:nth-child(even) td {
            background-color: #f2e3f4;
        }

        tr:hover {
            background-color: #f7d6e4;
            transform: scale(1.02);
            transition: all 0.3s ease-in-out;
        }

        .footer {
            text-align: center;
            margin-top: 50px;
            font-size: 14px;
            color: #5c3b69;
            opacity: 0.8;
        }

        .footer p {
            margin: 0;
        }

        a {
            color: #ff3b3b;
            font-weight: 600;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

    <h2>Detail Penjualan</h2>

    <div class="container">
        <form method="POST">
            <label for="penjualanID">Penjualan:</label>
            <select name="penjualanID" id="PenjualanID" required>
                <option value="">Pilih Penjualan</option>
                <?php
                $penjualan = mysqli_query($conn, "SELECT * FROM penjualan");
                while ($row = mysqli_fetch_assoc($penjualan)) {
                    echo "<option value='{$row['PenjualanID']}'>ID {$row['PenjualanID']} - {$row['TanggalPenjualan']}</option>";
                }
                ?>
            </select>

            <label for="produkID">Produk:</label>
            <select name="produkID" id="produkID" required>
                <option value="">Pilih Produk</option>
                <?php
                $produk = mysqli_query($conn, "SELECT * FROM produk");
                while ($row = mysqli_fetch_assoc($produk)) {
                    echo "<option value='{$row['ProdukID']}'>{$row['NamaProduk']} - Stok: {$row['Stok']} - Rp. {$row['Harga']}</option>";
                }
                ?>
            </select>

            <label for="jumlahProduk">Jumlah Produk:</label>
            <input type="number" name="jumlahProduk" id="jumlahProduk" required>

            <button type="submit" name="tambah">Tambah</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Penjualan ID</th>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['DetailID'] ?></td>
                        <td><?= $row['PenjualanID'] ?> - <?= $row['TanggalPenjualan'] ?></td>
                        <td><?= $row['NamaProduk'] ?></td>
                        <td><?= $row['JumlahProduk'] ?></td>
                        <td>Rp. <?= number_format($row['Subtotal'], 2, ',', '.') ?></td>
                        <td>
                            <a href="detailpenjualan.php?hapus=<?= $row['DetailID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="index.php" class="btn-dashboard">Kembali ke Dashboard</a>

    </div>

    <div class="footer">
    </div>

</body>
</html>
