<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = htmlspecialchars($_POST['NamaProduk']);
    $harga = (int) $_POST['Harga'];
    $stok = (int) $_POST['Stok'];

    $query = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    if (mysqli_query($conn, $query)) {
        header("Location: produk.php");
        exit();
    } else {
        echo "<script>alert('Gagal menambahkan produk!');</script>";
    }
}

$result = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f4f7fc;
            font-family: 'Arial', sans-serif;
        }
        .container {
            margin-top: 40px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .btn-primary {
            background-color: #4a90e2;
            border-radius: 30px;
            padding: 12px 20px;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #357ABD;
        }
        .btn-danger {
            border-radius: 30px;
        }
        .table thead {
            background-color: #4a90e2;
            color: white;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px;
        }
        .table-hover tbody tr:hover {
            background-color: #eef4ff;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4 text-primary"><i class="fas fa-box-open"></i> Manajemen Produk</h2>

    <!-- Form Tambah Produk -->
    <div class="card p-4">
        <h5 class="card-title text-center mb-3"><i class="fas fa-plus-circle"></i> Tambah Produk</h5>
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Nama Produk</label>
                    <input type="text" name="NamaProduk" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Harga</label>
                    <input type="number" name="Harga" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Stok</label>
                    <input type="number" name="Stok" class="form-control" required>
                </div>
            </div>
            <div class="mt-3 d-flex justify-content-between">
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah</button>
                <a href="index.php" class="btn btn-dark"><i class="fas fa-arrow-left"></i> Kembali</a>
            </div>
        </form>
    </div>

    <!-- Tabel Data Produk -->
    <div class="card mt-4">
        <div class="card-header bg-primary text-white">
            <i class="fas fa-list"></i> <strong>Daftar Produk</strong>
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr class="text-center">
                        <th>ID</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr class="text-center">
                            <td><?= htmlspecialchars($row['ProdukID']) ?></td>
                            <td><?= htmlspecialchars($row['NamaProduk']) ?></td>
                            <td>Rp<?= number_format($row['Harga'], 2, ',', '.') ?></td>
                            <td><?= htmlspecialchars($row['Stok']) ?></td>
                            <td>
                                <a href="edit_produk.php?id=<?= $row['ProdukID'] ?>" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit"></i> Ubah
                                </a>
                                <a href="hapus_produk.php?id=<?= $row['ProdukID'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center text-danger">Data tidak ditemukan!</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
