<?php
include "koneksi.php";

if (!isset($_GET['id'])) {
    die("ID Penjualan tidak ditemukan!");
}

$penjualanID = $_GET['id'];

// Ambil data penjualan
$penjualan = mysqli_query($conn, "SELECT penjualan.*, pelanggan.NamaPelanggan, pelanggan.Alamat, pelanggan.NomorTelepon
                                  FROM penjualan 
                                  JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
                                  WHERE penjualan.PenjualanID = $penjualanID");
$data_penjualan = mysqli_fetch_assoc($penjualan);

// Ambil data detail penjualan
$detail = mysqli_query($conn, "SELECT detailpenjualan.*, produk.NamaProduk, produk.Harga 
                               FROM detailpenjualan 
                               JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
                               WHERE detailpenjualan.PenjualanID = $penjualanID");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Penjualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 20px; }
        .card-header { background-color: #343a40; color: white; }
        .table thead { background-color: #6c757d; color: white; }
        .btn-back { background-color: #ff6b6b; color: white; }
        .btn-back:hover { background-color: #ff4757; }
    </style>
</head>
<body>
<div class="container">
    <div class="card shadow-lg mb-4">
        <div class="card-header text-center">
            <h4>Detail Penjualan</h4>
        </div>
        <div class="card-body">
            <p><strong>ID Penjualan:</strong> <?= $data_penjualan['PenjualanID'] ?></p>
            <p><strong>Tanggal:</strong> <?= $data_penjualan['TanggalPenjualan'] ?></p>
            <p><strong>Pelanggan:</strong> <?= $data_penjualan['NamaPelanggan'] ?></p>
            <p><strong>Alamat:</strong> <?= $data_penjualan['Alamat'] ?></p>
            <p><strong>Nomor Telepon:</strong> <?= $data_penjualan['NomorTelepon'] ?></p>
            <p><strong>Total Harga:</strong> <span class="badge bg-success">Rp <?= number_format($data_penjualan['TotalHarga'], 2) ?></span></p>
        </div>
    </div>

    <div class="card shadow-lg">
        <div class="card-header text-center">
            <h5>Detail Produk</h5>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($detail)) { ?>
                        <tr>
                            <td><?= $row['NamaProduk'] ?></td>
                            <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                            <td><?= $row['JumlahProduk'] ?></td>
                            <td><strong>Rp <?= number_format($row['Subtotal'], 2) ?></strong></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <a href="penjualan.php" class="btn btn-back mt-3 d-block text-center">Kembali ke Penjualan</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>