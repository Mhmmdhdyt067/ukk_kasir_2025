<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "ukk2025_kasir_bungalia";

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>