<?php 
include "koneksi.php";

// Inisialisasi variabel
$nama = "";
$alamat = "";
$telepon = "";
$editMode = false;
$idPelanggan = "";

// Jika tombol "Tambah" atau "Update" ditekan
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    
    if ($_POST['idPelanggan'] == "") {
        $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$telepon')";
    } else {
        $idPelanggan = $_POST['idPelanggan'];
        $sql = "UPDATE pelanggan SET NamaPelanggan='$nama', Alamat='$alamat', NomorTelepon='$telepon' WHERE PelangganID=$idPelanggan";
    }

    mysqli_query($conn, $sql);
    header("Location: pelanggan.php");
}

// Jika tombol "Hapus" ditekan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE PelangganID = $id");
    header("Location: pelanggan.php");
} 

// Jika tombol "Ubah" ditekan
if (isset($_GET['edit'])) {
    $idPelanggan = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM pelanggan WHERE PelangganID = $idPelanggan");
    $data = mysqli_fetch_assoc($result);
    
    if ($data) {
        $nama = $data['NamaPelanggan'];
        $alamat = $data['Alamat'];
        $telepon = $data['NomorTelepon'];
        $editMode = true;
    }
}

// Ambil semua data pelanggan
$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #F9FAFB;
            font-family: 'Roboto', sans-serif;
        }
        .container {
            margin-top: 60px;
        }
        .card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .btn-primary {
            background-color: rgb(56, 239, 215);
            border: none;
            border-radius: 50px;
            padding: 12px 25px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .btn-primary:hover {
            background-color:rgb(56, 239, 215);
        }
        .btn-dark {
            background-color: #343a40;
            color: white;
            border-radius: 50px;
            padding: 12px 25px;
        }
        .btn-dark:hover {
            background-color: #23272b;
        }
        .btn-danger {
            background-color: #dc3545;
            border-radius: 50px;
            padding: 12px 25px;
            color: white;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .table thead {
            background-color: rgb(56, 239, 215);
            color: white;
        }
        .table td, .table th {
            vertical-align: middle;
            text-align: center;
            padding: 20px;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f2f9fc;
        }
        .table-hover tbody tr:hover {
            background-color: #e9f7fc;
        }
        .table-bordered {
            border: 1px solid #ddd;
        }
        .form-label {
            font-weight: 600;
            color: #555;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
            border-color:rgb(56, 239, 215);
        }
        .mb-4 {
            margin-bottom: 20px;
        }
        .card-header {
            background-color: rgb(56, 239, 215);
            color: white;
            font-size: 1.2rem;
            font-weight: 600;
        }
        .icon-btn {
            font-size: 14px;
            padding: 5px 10px;
            border-radius: 25px;
            background-color: #e1f7d5;
            border: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4 text-primary">Manajemen Data Pelanggan</h2>

    <!-- Form Tambah / Edit Pelanggan -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-user-plus"></i> <?= $editMode ? "Edit Pelanggan" : "Tambah Pelanggan" ?>
        </div>
        <form method="POST">
            <div class="mb-4">
                <label class="form-label">Nama Pelanggan</label>
                <input type="text" name="nama" class="form-control" value="<?= $nama ?>" required>
            </div>
            <div class="mb-4">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" value="<?= $alamat ?>" required>
            </div>
            <div class="mb-4">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="telepon" class="form-control" value="<?= $telepon ?>" required>
            </div>
            <button type="submit" name="simpan" class="btn btn-primary"><?= $editMode ? "Simpan Perubahan" : "Tambah" ?></button>
            <?php if ($editMode) { ?>
                <a href="pelanggan.php" class="btn btn-danger">Batal</a>
            <?php } ?>
            <a href="index.php" class="btn btn-dark">Kembali ke Beranda</a>
        </form>
    </div>

    <!-- Tabel Data Pelanggan -->
    <div class="card mt-4">
        <div class="card-header">
            <i class="fas fa-list"></i> Daftar Pelanggan
        </div>
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['PelangganID'] ?></td>
                        <td><?= $row['NamaPelanggan'] ?></td>
                        <td><?= $row['Alamat'] ?></td>
                        <td><?= $row['NomorTelepon'] ?></td>
                        <td>
                            <a href="pelanggan.php?edit=<?= $row['PelangganID'] ?>" class="btn btn-primary btn-sm icon-btn">
                                <i class="fas fa-edit"></i> Ubah
                            </a>
                            <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" class="btn btn-danger btn-sm icon-btn" onclick="return confirm('Yakin ingin menghapus?')">
                                <i class="fas fa-trash-alt"></i> Hapus
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
