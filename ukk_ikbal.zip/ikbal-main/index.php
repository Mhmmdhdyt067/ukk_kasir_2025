<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
            color: white;
            font-family: 'Poppins', sans-serif;
        }
        .navbar {
            background: rgba(0, 0, 0, 0.6) !important;
            backdrop-filter: blur(10px);
        }
        .card {
            border: none;
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease-in-out;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0px 8px 20px rgba(255, 255, 255, 0.2);
        }
        .card i {
            font-size: 50px;
            margin-bottom: 15px;
        }
        .btn-custom {
            background-color: rgba(0, 168, 150, 0.9);
            color: white;
            font-weight: bold;
            border-radius: 50px;
            padding: 10px 20px;
        }
        .btn-custom:hover {
            background-color: rgba(2, 128, 144, 0.9);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand mx-auto" href="#"><h2 class="fw-bold">Dashboard Admin</h2></a>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h2 class="text-center fw-bold mb-5">Aplikasi Pengelolaan Basis Data</h2>
        <div class="row justify-content-center">
            <div class="col-md-4 mb-4">
                <div class="card text-white text-center p-4">
                    <i class="fas fa-users"></i>
                    <h5 class="card-title">Data Pelanggan</h5>
                    <a href="pelanggan.php" class="btn btn-custom">Lihat</a>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card text-white text-center p-4">
                    <i class="fas fa-box"></i>
                    <h5 class="card-title">Manajemen Produk</h5>
                    <a href="produk.php" class="btn btn-custom">Lihat</a>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card text-white text-center p-4">
                    <i class="fas fa-shopping-cart"></i>
                    <h5 class="card-title">Manajemen Penjualan</h5>
                    <a href="penjualan.php" class="btn btn-custom">Lihat</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
