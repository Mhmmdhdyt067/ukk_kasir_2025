<!DOCTYPE html> 
<html lang="en"> 
<head>     
    <meta charset="UTF-8">     
    <meta name="viewport" content="width=device-width, initial-scale=1.0">     
    <title>Pengelolaan Basis Data</title>     
    <link rel="stylesheet" href="style.css"> 
</head> 
<body>    

 
    <div class="container">         
        <h1>Pengelolaan Basis Data</h1>         
        <nav>             
            <ul>                 
                <li><a href="produk.php">Produk</a></li>                 
                <li><a href="pelanggan.php">Pelanggan</a></li>                 
                <li><a href="penjualan.php">Penjualan</a></li>                              
            </ul>         
        </nav>     
    </div> 
    
</body> 
</html> 
