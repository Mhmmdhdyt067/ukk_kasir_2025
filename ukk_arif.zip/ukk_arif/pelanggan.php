<?php
require_once 'config.php';

// Hapus pelanggan
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $conn->query("DELETE FROM pelanggan WHERE PelangganID = $id");
    header("Location: pelanggan.php");
    exit;
}

// Tambah pelanggan
if (isset($_POST['add'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $conn->query("INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$telepon')");
    header("Location: pelanggan.php");
    exit;
}

// Ubah pelanggan
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $conn->query("UPDATE pelanggan SET NamaPelanggan = '$nama', Alamat = '$alamat', NomorTelepon = '$telepon' WHERE PelangganID = $id");
    header("Location: pelanggan.php");
    exit;
}

// Ambil data pelanggan dari database
$sql = "SELECT * FROM pelanggan";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1>Daftar Pelanggan</h1>

        <form method="POST" action="" onsubmit="return validateForm()">
            <input type="hidden" name="id" id="id">
            <input type="text" name="nama" id="nama" placeholder="Nama Pelanggan" required>
            <input type="text" name="alamat" id="alamat" placeholder="Alamat" required>
            <input type="text" name="telepon" id="telepon" placeholder="Nomor Telepon" required>
            <button type="submit" name="add" class="btn btn-primary">Tambah</button>
            <button type="submit" name="update" class="btn btn-primary">Ubah</button>
        </form>

        <table border="1" class="styled-table">
            <thead>
                <tr>
                    <th>ID Pelanggan</th>
                    <th>Nama Pelanggan</th>
                    <th>Alamat</th>
                    <th>Nomor Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php
$counter = 1; // Initialize a counter variable

while ($row = $result->fetch_assoc()) :
?>
    <tr>
        <td><?= $counter++; ?></td> <!-- Display the current counter value and increment it -->
        <td><?= $row['NamaPelanggan']; ?></td>
        <td><?= $row['Alamat']; ?></td>
        <td><?= $row['NomorTelepon']; ?></td>
        <td>
        <button onclick="editPelanggan(<?= $row['PelangganID']; ?>, '<?= $row['NamaPelanggan']; ?>', '<?= $row['Alamat']; ?>', '<?= $row['NomorTelepon']; ?>') " class="btn btn-warning">Ubah</button>

            <a href="?delete_id=<?= $row['PelangganID']; ?>" onclick="return confirm('Yakin ingin menghapus?')"
            class="btn btn-danger">Hapus</a>
            
        </td>
    </tr>
<?php endwhile; ?>

            </tbody>
        </table>

        <!-- Back Button -->
        <a href="index.php"><button class="btn btn-success">Back to Dashboard</button></a>
    </div>

    <script>
        function editPelanggan(id, nama, alamat, telepon) {
            if (confirm("Apakah Anda yakin ingin mengubah data pelanggan?")) {
                document.getElementById('id').value = id;
                document.getElementById('nama').value = nama;
                document.getElementById('alamat').value = alamat;
                document.getElementById('telepon').value = telepon;
            }
        }

        function validateForm() {
            let nama = document.getElementById('nama').value;
            let alamat = document.getElementById('alamat').value;
            let telepon = document.getElementById('telepon').value;

            if (nama == "" || alamat == "" || telepon == "") {
                alert("Semua field harus diisi!");
                return false;
            }

            return true;
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
