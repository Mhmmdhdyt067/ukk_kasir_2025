<?php
require_once 'config.php';

// Hapus produk
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $conn->query("DELETE FROM produk WHERE ProdukID = $id");
    header("Location: produk.php");
    exit;
}

// Tambah produk
if (isset($_POST['add'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $conn->query("INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')");
    header("Location: produk.php");
    exit;
}

// Ubah produk
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $conn->query("UPDATE produk SET NamaProduk = '$nama', Harga = '$harga', Stok = '$stok' WHERE ProdukID = $id");
    header("Location: produk.php");
    exit;
}

// Ambil data produk dari database
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$start_from = ($page - 1) * $limit; // Calculate starting record for SQL query

// Modify your SQL query to include LIMIT and OFFSET
$sql = "SELECT * FROM produk LIMIT $start_from, $limit";
$result = $conn->query($sql);

// Fetch total records for pagination
$total_sql = "SELECT COUNT(*) FROM produk";
$total_result = $conn->query($total_sql);
$total_rows = $total_result->fetch_row()[0];
$total_pages = ceil($total_rows / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1>Daftar Produk</h1>

        <form method="POST" action="" onsubmit="return validateForm()">
            <input type="hidden" name="id" id="id">
            <input type="text" name="nama" id="nama" placeholder="Nama Produk" required>
            <input type="number" name="harga" id="harga" placeholder="Harga" required>
            <input type="number" name="stok" id="stok" placeholder="Stok" required>
            <button type="submit" name="add" class="btn btn-primary">Tambah</button>
            <button type="submit" name="update" class="btn btn-info">Ubah</button>
        </form>

        <table border="1" class="styled-table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>ID Produk</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 1; // Initialize counter for the row number, start at 1
                $max_counter = 5; // Define the number limit, after this it will repeat

                while ($row = $result->fetch_assoc()) :
                ?>
                    <tr>
                        <td><?= $counter; ?></td> <!-- Display the current counter value -->
                        <td><?= $row['ProdukID']; ?></td>
                        <td><?= $row['NamaProduk']; ?></td>
                        <td><?= $row['Harga']; ?></td>
                        <td><?= $row['Stok']; ?></td>
                        <td>
                        <button onclick="editProduk(<?= $row['ProdukID']; ?>, '<?= $row['NamaProduk']; ?>', <?= $row['Harga']; ?>, <?= $row['Stok']; ?>)" class="btn btn-warning">Ubah</button>

                            <a href="?delete_id=<?= $row['ProdukID']; ?>" onclick="return confirm('Yakin ingin menghapus?')" class="btn btn-danger">Hapus</a>
                            
                        </td>
                    </tr>
                    <?php
                    $counter++; // Increment the counter
                    if ($counter > $max_counter) { // Reset counter after reaching 5
                        $counter = 1;
                    }
                    ?>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Pagination Links -->
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                <a href="?page=<?= $i; ?>" <?= ($i == $page) ? 'class="active"' : ''; ?>><?= $i; ?></a>
            <?php endfor; ?>
        </div>

        <!-- Back Button -->
        <a href="index.php"><button class="btn btn-success">Back to Dashboard</button></a>
    </div>

    <script>
        function editProduk(id, nama, harga, stok) {
            if (confirm("Apakah Anda yakin ingin mengubah data produk?")) {
                document.getElementById('id').value = id;
                document.getElementById('nama').value = nama;
                document.getElementById('harga').value = harga;
                document.getElementById('stok').value = stok;
            }
        }

        function validateForm() {
            let nama = document.getElementById('nama').value;
            let harga = document.getElementById('harga').value;
            let stok = document.getElementById('stok').value;

            if (nama == "" || harga == "" || stok == "") {
                alert("Semua field harus diisi!");
                return false;
            }

            if (isNaN(harga) || isNaN(stok)) {
                alert("Harga dan Stok harus berupa angka!");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
