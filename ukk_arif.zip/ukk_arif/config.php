<?php
// Konfigurasi database
$host = 'localhost'; // Server database
$user = 'root'; // Username database
$password = ''; // Password database (kosong jika default XAMPP)
$dbname = 'ukk_kasir_arif'; // Nama database

// Koneksi ke database
$conn = new mysqli($host, $user, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>