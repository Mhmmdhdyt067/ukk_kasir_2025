<?php
include 'db.php'; // Menghubungkan ke database

// Ambil daftar pelanggan
$pelanggan_query = "SELECT id, nama FROM pelanggan";
$pelanggan_result = mysqli_query($conn, $pelanggan_query);

// Ambil daftar produk
$produk_query = "SELECT id, nama, harga, stok FROM produk WHERE stok IS NOT NULL AND stok > 0";
$produk_result = mysqli_query($conn, $produk_query);

// Proses form ketika dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $pelanggan_id = mysqli_real_escape_string($conn, $_POST['pelanggan_id']);
    $produk_ids = $_POST['produk_id']; // Array produk yang dipilih
    $jumlahs = $_POST['jumlah']; // Array jumlah produk

    $total_harga = 0;
    $detail_penjualan = [];

    foreach ($produk_ids as $index => $produk_id) {
        $produk_id = mysqli_real_escape_string($conn, $produk_id);
        $jumlah = mysqli_real_escape_string($conn, $jumlahs[$index]);

        // Ambil harga produk
        $harga_query = "SELECT harga FROM produk WHERE id = '$produk_id'";
        $harga_result = mysqli_query($conn, $harga_query);
        $harga_row = mysqli_fetch_assoc($harga_result);
        $harga = $harga_row['harga'];
        $subtotal = $harga * $jumlah;
        $total_harga += $subtotal;

        // Simpan detail penjualan ke array
        $detail_penjualan[] = [
            'produk_id' => $produk_id,
            'harga' => $harga,
            'jumlah' => $jumlah,
            'subtotal' => $subtotal
        ];
    }

    // Simpan data ke tabel penjualan terlebih dahulu
    $query_penjualan = "INSERT INTO penjualan (tanggal, pelanggan_id, total_harga) 
                        VALUES ('$tanggal', '$pelanggan_id', '$total_harga')";

    if (mysqli_query($conn, $query_penjualan)) {
        $penjualan_id = mysqli_insert_id($conn);

        // Simpan detail penjualan
        foreach ($detail_penjualan as $detail) {
            $query_detail = "INSERT INTO detail_penjualan (penjualan_id, produk_id, harga, jumlah, subtotal) 
                             VALUES ('$penjualan_id', '{$detail['produk_id']}', '{$detail['harga']}', '{$detail['jumlah']}', '{$detail['subtotal']}')";
            mysqli_query($conn, $query_detail);
        }

        header("Location: penjualan.php");
        exit();
    } else {
        echo "Gagal menambahkan penjualan: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> <!-- Menentukan karakter set sebagai UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Menyesuaikan tampilan untuk perangkat mobile -->
    <title>Tambah Penjualan</title> <!-- Judul halaman -->
    <link rel="stylesheet" href="css/style.css"> <!-- Memuat file CSS eksternal -->
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3> <!-- Judul navigasi -->
            <li><a href="index.php">Dashboard</a></li> <!-- Link menuju halaman dashboard -->
            <li><a href="produk.php">Produk</a></li> <!-- Link menuju halaman produk -->
            <li><a href="pelanggan.php">Pelanggan</a></li> <!-- Link menuju halaman pelanggan -->
            <li><a href="penjualan.php">Penjualan</a></li> <!-- Link menuju halaman penjualan -->
        </ul>
    </nav>
    <div class="container">
        <h1>Tambah Penjualan</h1> <!-- Judul utama halaman -->

        <!-- Form Tambah Penjualan -->
        <form method="POST" action="" class="tambah">
            <label for="tanggal">Tanggal Penjualan</label>
            <input type="date" id="tanggal" name="tanggal" required> <!-- Input tanggal penjualan -->

            <label for="pelanggan_id">Pelanggan</label>
            <select id="pelanggan_id" name="pelanggan_id" class="form-control" required> <!-- Dropdown untuk memilih pelanggan -->
                <option value="">Pilih Pelanggan</option>
                 <?php while ($row = mysqli_fetch_assoc($pelanggan_result)) { ?> <!-- Loop untuk menampilkan daftar pelanggan -->
                     <option value="<?= $row['id']; ?>"><?= $row['nama']; ?></option> <!-- Menampilkan opsi pelanggan -->
                <?php } ?>
            </select>

            <label for="produk_id">Produk</label>
            <select id="produk_id" name="produk_id" class="form-control" required> <!-- Dropdown untuk memilih produk -->
                <option value="">Pilih Produk</option>
                <?php while ($row = mysqli_fetch_assoc($produk_result)) { ?> <!-- Loop untuk menampilkan daftar produk -->
                    <option value="<?= $row['id']; ?>"><?= $row['nama']; ?> - Rp <?= number_format($row['harga'], 0, ',', '.'); ?></option> <!-- Menampilkan opsi produk beserta harga -->
                <?php } ?>
            </select>

            <label for="jumlah">Jumlah Produk</label>
            <input type="number" id="jumlah" name="jumlah" required min="1"> <!-- Input jumlah produk -->

            <button type="submit" class="btn-form">Simpan</button> <!-- Tombol submit untuk menyimpan data -->
            <button type="button" onclick="window.location.href='produk.php'" class="btn-form">Batal</button> <!-- Tombol batal yang mengarahkan kembali ke halaman produk -->
        </form>
    </div>
</body>
</html>
