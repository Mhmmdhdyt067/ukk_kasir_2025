<?php 
include 'db.php'; // Menghubungkan ke database dengan menyertakan file koneksi

// Hapus Penjualan dengan transaksi
if (isset($_GET['hapus'])) { // Mengecek apakah ada parameter 'hapus' pada URL
    $id = $_GET['hapus']; // Mengambil nilai 'id' dari parameter 'hapus'
    
    mysqli_begin_transaction($conn); // Memulai transaksi
    
    $query = "DELETE FROM penjualan WHERE id='$id'";
    $result = mysqli_query($conn, $query); // Menjalankan query hapus
    
    if ($result) {
        mysqli_commit($conn); // Konfirmasi perubahan jika berhasil
        header("Location: penjualan.php"); // Mengarahkan kembali ke halaman penjualan
        exit();
    } else {
        mysqli_rollback($conn); // Batalkan perubahan jika terjadi kesalahan
        echo "Gagal menghapus data!";
    }
}

$search = isset($_GET['search']) ? $_GET['search'] : ''; // Mengambil nilai pencarian dari URL jika ada
$query = "SELECT penjualan.*, pelanggan.nama AS pelanggan_nama 
          FROM penjualan 
          JOIN pelanggan ON penjualan.pelanggan_id = pelanggan.id 
          WHERE penjualan.id LIKE '%$search%'"; // Query untuk mengambil data penjualan beserta nama pelanggan, dengan pencarian berdasarkan ID
$result = mysqli_query($conn, $query); // Menjalankan query ke database

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> <!-- Menentukan karakter set sebagai UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Menyesuaikan tampilan untuk perangkat mobile -->
    <title>Manajemen Penjualan</title> <!-- Judul halaman -->
    <link rel="stylesheet" href="css/style.css"> <!-- Memuat file CSS eksternal -->
</head>
<body>
    <nav>
        <ul>
            <h3> Sistem Pengelolaan Database </h3> <!-- Judul navigasi -->
            <li><a href="index.php">Dashboard</a></li> <!-- Link menuju halaman dashboard -->
            <li><a href="produk.php">Produk</a></li> <!-- Link menuju halaman produk -->
            <li><a href="pelanggan.php">Pelanggan</a></li> <!-- Link menuju halaman pelanggan -->
            <li><a href="penjualan.php">Penjualan</a></li> <!-- Link menuju halaman penjualan -->
        </ul>
    </nav>

    <div class="container">
        <h1>Manajemen Penjualan</h1> <!-- Judul utama halaman -->

        <!-- Tombol Tambah Penjualan -->
        <a href="tambah_penjualan.php" class="btn-tambah">Tambah Penjualan</a> <!-- Tombol untuk menambah data penjualan -->

        <!-- Form Pencarian -->
        <form method="GET" action="penjualan.php" class="search-form">
            <input type="text" name="search" placeholder="Cari id penjualan..." value="<?= htmlspecialchars($search) ?>"> <!-- Input pencarian berdasarkan ID -->
            <button type="submit">Cari</button> <!-- Tombol untuk menjalankan pencarian -->
            <button class="reset">Reset</button> <!-- Tombol reset untuk menghapus pencarian -->
        </form>

        <!-- Daftar Penjualan -->
        <h2>Daftar Penjualan</h2> <!-- Judul tabel daftar penjualan -->
        <table>
            <thead>
                <tr>
                    <th>ID</th> <!-- Kolom ID penjualan -->
                    <th>TANGGAL</th> <!-- Kolom tanggal transaksi -->
                    <th>PELANGGAN</th> <!-- Kolom nama pelanggan -->
                    <th>TOTAL HARGA</th> <!-- Kolom total harga transaksi -->
                    <th>AKSI</th> <!-- Kolom aksi (Detail & Hapus) -->
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?> <!-- Loop untuk menampilkan semua data dari query -->
                <tr>
                    <td><?= $row['id']; ?></td> <!-- Menampilkan ID penjualan -->
                    <td><?= $row['tanggal']; ?></td> <!-- Menampilkan tanggal transaksi -->
                    <td><?= $row['pelanggan_nama']; ?></td> <!-- Menampilkan nama pelanggan -->
                    <td><?= $row['total_harga']; ?></td> <!-- Menampilkan total harga transaksi -->
                    <td>
                        <a href="detail_penjualan.php?id=<?= $row['id']; ?>" class="detail-button">Detail</a> <!-- Tombol untuk melihat detail penjualan -->
                        <a href="penjualan.php?hapus=<?= $row['id']; ?>">Hapus</a> <!-- Tombol untuk menghapus penjualan berdasarkan ID -->
                    </td>
                </tr>
            <?php } ?> <!-- Akhir loop -->
            </tbody>
        </table>
    </div>
</body>
</html>
