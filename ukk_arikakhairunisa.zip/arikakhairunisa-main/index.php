<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Pengelolaan Basis Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General body styling */
        body {
            background-color: #e0f7fa; /* Light blue background */
            font-family: 'Helvetica Neue', Arial, sans-serif;
            color: #34495e;
        }

        /* Container styling */
        .container {
            margin-top: 50px;
        }

        /* Card styling */
        .card {
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card-header {
            background-color: #1abc9c;
            color: white;
            font-size: 20px;
            padding: 20px;
            border-radius: 20px 20px 0 0;
        }

        /* Button Customization */
        .btn-custom {
            border-radius: 30px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            padding: 10px 30px;
            background-color: #1abc9c;
            color: white;
            border: none;
        }

        .btn-custom:hover {
            background-color: #16a085;
        }

        /* Page Header */
        h2 {
            color: #2c3e50;
            font-size: 36px;
            text-align: center;
            margin-bottom: 50px;
            font-weight: bold;
        }

        /* Navbar Styling */
        .navbar {
            background-color: #34495e;
            border-radius: 0 0 30px 30px;
        }

        .navbar .navbar-brand {
            color: white;
            font-size: 24px;
            font-weight: bold;
        }

        /* Card Icons */
        .card-header i {
            font-size: 40px;
            color: white;
            margin-right: 10px;
        }

        /* Grid Layout for Cards */
        .row {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }

        /* Title Hover Effect */
        h2:hover {
            color: #1abc9c;
            transition: color 0.3s ease;
        }

        /* Icon Container */
        .icon-container {
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #ffffff;
            border-radius: 50%;
            padding: 15px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }

        .icon {
            font-size: 3rem;
            color: #1abc9c;
        }

        .card-body {
            text-align: center;
            padding: 40px 20px;
            position: relative;
        }

        .card-body h5 {
            font-size: 1.6rem;
            font-weight: bold;
            color: #1abc9c;
            margin-bottom: 25px;
        }

        .card-body p {
            font-size: 1.1rem;
            color: #34495e;
            margin-bottom: 25px;
        }

        .card-body .btn {
            padding: 12px 35px;
            font-size: 1.1rem;
            border-radius: 50px;
            background-color: #1abc9c;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
        }

        .card-body .btn:hover {
            background-color: #16a085;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Aplikasi Pengelolaan Basis Data</h2>
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-users icon"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Data Pelanggan</h5>
                        <p>Kelola data pelanggan Anda dengan mudah dan cepat.</p>
                        <a href="pelanggan.php" class="btn btn-custom">Lihat</a>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-box-open icon"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Manajemen Produk</h5>
                        <p>Tambah, ubah, atau hapus produk dengan satu klik.</p>
                        <a href="produk.php" class="btn btn-custom">Lihat</a>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-cash-register icon"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Manajemen Penjualan</h5>
                        <p>Lihat dan kelola semua transaksi penjualan dengan mudah.</p>
                        <a href="penjualan.php" class="btn btn-custom">Lihat</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>
