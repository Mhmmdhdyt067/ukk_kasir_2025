<?php
include "koneksi.php";

if (!isset($_GET['id'])) {
    die("ID Penjualan tidak ditemukan!");
}

$penjualanID = $_GET['id'];

// Ambil data penjualan
$penjualan = mysqli_query($conn, "SELECT penjualan.*, pelanggan.NamaPelanggan, pelanggan.Alamat, pelanggan.NomorTelepon
                                  FROM penjualan 
                                  JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID
                                  WHERE penjualan.PenjualanID = $penjualanID");
$data_penjualan = mysqli_fetch_assoc($penjualan);

// Ambil data detail penjualan
$detail = mysqli_query($conn, "SELECT detailpenjualan.*, produk.NamaProduk, produk.Harga 
                               FROM detailpenjualan 
                               JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
                               WHERE detailpenjualan.PenjualanID = $penjualanID");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detail Penjualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <!-- Informasi Penjualan -->
    <div class="card p-4 mb-4">
        <div class="card-header">Detail Penjualan</div>
        <div class="card-body">
            <p><strong>ID Penjualan:</strong> <?= $data_penjualan['PenjualanID'] ?></p>
            <p><strong>Tanggal Penjualan:</strong> <?= $data_penjualan['TanggalPenjualan'] ?></p>
            <p><strong>Pelanggan:</strong> <?= $data_penjualan['NamaPelanggan'] ?></p>
            <p><strong>Alamat:</strong> <?= $data_penjualan['Alamat'] ?></p>
            <p><strong>Nomor Telepon:</strong> <?= $data_penjualan['NomorTelepon'] ?></p>
            <p><strong>Total Harga:</strong> Rp <?= number_format($data_penjualan['TotalHarga'], 2) ?></p>
        </div>
    </div>

    <!-- Tabel Detail Penjualan -->
    <div class="card p-4">
        <div class="card-header">Detail Produk yang Dibeli</div>
        <div class="card-body">
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($detail)) { ?>
                        <tr>
                            <td><?= $row['NamaProduk'] ?></td>
                            <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                            <td><?= $row['JumlahProduk'] ?></td>
                            <td>Rp <?= number_format($row['Subtotal'], 2) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Kembali ke Penjualan -->
    <a href="penjualan.php" class="btn btn-dark btn-custom mt-3">Kembali ke Daftar Penjualan</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
