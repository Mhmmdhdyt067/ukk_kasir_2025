<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) 
            VALUES ('$nama', '$alamat', '$telepon')";
    mysqli_query($conn, $sql);
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE PelangganID = $id");
}

// Ambil Data
$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Data Pelanggan</h2>
    <form method="POST">
        <input type="text" name="nama" placeholder="Nama" required>
        <input type="text" name="alamat" placeholder="Alamat" required>
        <input type="text" name="telepon" placeholder="Telepon" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>
    <table>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Telepon</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['PelangganID'] ?></td>
                <td><?= $row['NamaPelanggan'] ?></td>
                <td><?= $row['Alamat'] ?></td>
                <td><?= $row['NomorTelepon'] ?></td>
                <td>
                    <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        th {
    background: #fc930a;
    color: white;
}
button{
    background: #fc930a;
}
        a:hover {
            background-color:rgb(10, 123, 252); /* Warna latar belakang saat hover */
            color: white;              /* Warna teks saat hover */
        }
    </style>
    <a href="index.php">Kembali</a>
</body>
</html>