
<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    mysqli_query($conn, $sql);
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM produk WHERE ProdukID = $id");
}

$result = mysqli_query($conn, "SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk</title>
    <style>
        <?php include "style.css"; ?>
    </style>
</head>
<body>

    <h2>Data Produk</h2>

    <form method="POST">
        <label>Nama Produk:</label>
        <input type="text" name="nama" required>
        <label>Harga:</label>
        <input type="number" name="harga" required>
        <label>Stok:</label>
        <input type="number" name="stok" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['ProdukID'] ?></td>
                <td><?= $row['NamaProduk'] ?></td>
                <td>Rp <?= number_format($row['Harga'], 2) ?></td>
                <td><?= $row['Stok'] ?></td>
                <td><a href="produk.php?hapus=<?= $row['ProdukID'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a></td>
            </tr>
        <?php } ?>
    </table>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        a:hover {
            background-color: #fc930a; /* Warna latar belakang saat hover */
            color: white;              /* Warna teks saat hover */
        }
    </style>
    <a href="index.php">Kembali</a>
</body>
</html>