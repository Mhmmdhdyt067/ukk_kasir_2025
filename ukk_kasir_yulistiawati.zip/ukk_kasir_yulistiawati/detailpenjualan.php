<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $penjualanID = $_POST['penjualanID'];
    $produkID = $_POST['produkID'];
    $jumlahProduk = $_POST['jumlahProduk'];

    // Ambil harga produk
    $queryHarga = mysqli_query($conn, "SELECT Harga, Stok FROM produk WHERE ProdukID = $produkID");
    $row = mysqli_fetch_assoc($queryHarga);
    $harga = $row['Harga'];
    $stok = $row['Stok'];
    
    // Pastikan stok mencukupi sebelum menambahkan transaksi
    if ($stok >= $jumlahProduk) {
        $subtotal = $harga * $jumlahProduk;

        // Insert ke detailpenjualan
        $sql = "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) 
                VALUES ('$penjualanID', '$produkID', '$jumlahProduk', '$subtotal')";
        mysqli_query($conn, $sql);

        // Kurangi stok produk
        $updateStok = "UPDATE produk SET Stok = Stok - $jumlahProduk WHERE ProdukID = $produkID";
        mysqli_query($conn, $updateStok);
    } else {
        echo "<script>alert('Stok tidak mencukupi!');</script>";
    }
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    // Ambil data sebelum menghapus untuk mengembalikan stok
    $queryDetail = mysqli_query($conn, "SELECT * FROM detailpenjualan WHERE DetailID = $id");
    $row = mysqli_fetch_assoc($queryDetail);
    $produkID = $row['ProdukID'];
    $jumlahProduk = $row['JumlahProduk'];

    // Kembalikan stok produk
    $updateStok = "UPDATE produk SET Stok = Stok + $jumlahProduk WHERE ProdukID = $produkID";
    mysqli_query($conn, $updateStok);

    // Hapus data dari tabel detailpenjualan
    mysqli_query($conn, "DELETE FROM detailpenjualan WHERE DetailID = $id");
}

// Ambil Data
$result = mysqli_query($conn, 
    "SELECT detailpenjualan.*, produk.NamaProduk, penjualan.TanggalPenjualan 
     FROM detailpenjualan
     JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID
     JOIN penjualan ON detailpenjualan.PenjualanID = penjualan.PenjualanID");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Data Detail Penjualan</h2>
    
    <form method="POST">
        <label>Penjualan:</label>
        <select name="penjualanID" required>
            <option value="">Pilih Penjualan</option>
            <?php
            $penjualan = mysqli_query($conn, "SELECT * FROM penjualan");
            while ($row = mysqli_fetch_assoc($penjualan)) {
                echo "<option value='{$row['PenjualanID']}'>ID {$row['PenjualanID']} - {$row['TanggalPenjualan']}</option>";
            }
            ?>
        </select>

        <label>Produk:</label>
        <select name="produkID" required>
            <option value="">Pilih Produk</option>
            <?php
            $produk = mysqli_query($conn, "SELECT * FROM produk");
            while ($row = mysqli_fetch_assoc($produk)) {
                echo "<option value='{$row['ProdukID']}'>{$row['NamaProduk']} - Stok: {$row['Stok']} - Rp. {$row['Harga']}</option>";
            }
            ?>
        </select>

        <label>Jumlah Produk:</label>
        <input type="number" name="jumlahProduk" required>
        
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Penjualan ID</th>
            <th>Produk</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['DetailID'] ?></td>
                <td><?= $row['PenjualanID'] ?> - <?= $row['TanggalPenjualan'] ?></td>
                <td><?= $row['NamaProduk'] ?></td>
                <td><?= $row['JumlahProduk'] ?></td>
                <td>Rp. <?= number_format($row['Subtotal'], 2, ',', '.') ?></td>
                <td>
                    <a href="detailpenjualan.php?hapus=<?= $row['DetailID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        th {
    background: #fc930a;
    color: white;
}
button{
    background: #fc930a;
}
        a:hover {
            background-color:rgb(10, 123, 252); /* Warna latar belakang saat hover */
            color: white;              /* Warna teks saat hover */
        }
    </style>
    <a href="index.php">Kembali</a>
</body>
</html>