<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $TotalHarga = $_POST['TotalHarga'];
    $sql = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) VALUES ('$tanggal', '$pelangganID', $TotalHarga)";
    mysqli_query($conn, $sql);
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE PelangganID = $id");
}

$result = mysqli_query($conn, "SELECT * FROM penjualan");
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan</title>
    <style>
        <?php include "style.css"; ?>
    </style>
</head>
<body>

    <h2>Data Penjualan</h2>

    <form method="POST">
        <label>Tanggal:</label>
        <input type="date" name="tanggal" required>
        <label>Pelanggan:</label>
        <select name="pelangganID">
            <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
            <?php } ?>
        </select>

        <label>Total Harga:</label>
        <input type="number" name="TotalHarga" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Total Harga</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['PenjualanID'] ?></td>
                <td><?= $row['TanggalPenjualan'] ?></td>
                <td><?= $row['PelangganID'] ?></td>
                <td>Rp <?= number_format($row['TotalHarga'], 2) ?></td>
                <td><a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a></td>
            </tr>
        <?php } ?>
    </table>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        a:hover {
            background-color: #fc930a; /* Warna latar belakang saat hover */
            color: white;              /* Warna teks saat hover */
        }
    </style>
    <a href="index.php">Kembali</a>
</body>
</html>