<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengelolaan Basis Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to bottom right, #74ebd5, #9face6);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .navbar {
            background-color: #4CAF50 !important;
        }
        .navbar-brand {
            font-size: 1.75rem;
            font-weight: bold;
        }
        .container h2 {
            font-family: 'Arial', sans-serif;
            color: #ffffff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: scale(1.08);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }
        .card-title {
            font-size: 1.3rem;
            font-weight: bold;
        }
        .btn {
            font-size: 1rem;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
        }
        footer {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 1rem 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand text-white" href="#">Dashboard Admin</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-5">Aplikasi Pengelolaan Basis Data</h2>
        <div class="row justify-content-center">
            <div class="col-md-4 mb-4">
                <div class="card text-center bg-light">
                    <div class="card-body">
                        <h5 class="card-title">👤 Data Pelanggan</h5>
                        <p class="card-text">Kelola data pelanggan dengan mudah.</p>
                        <a href="pelanggan.php" class="btn btn-success">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card text-center bg-light">
                    <div class="card-body">
                        <h5 class="card-title">🛍️ Manajemen Produk</h5>
                        <p class="card-text">Atur produk dan inventaris Anda.</p>
                        <a href="produk.php" class="btn btn-success">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card text-center bg-light">
                    <div class="card-body">
                        <h5 class="card-title">💰 Manajemen Penjualan</h5>
                        <p class="card-text">Lacak transaksi dan penjualan.</p>
                        <a href="penjualan.php" class="btn btn-success">Lihat</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 Aplikasi Pengelolaan Basis Data. Semua Hak Dilindungi.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>