<?php
include "koneksi.php";

// Inisialisasi variabel
$nama = "";
$alamat = "";
$telepon = "";
$editMode = false;
$idPelanggan = "";

// Jika tombol "Tambah" atau "Update" ditekan
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    
    if ($_POST['idPelanggan'] == "") {
        $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$telepon')";
    } else {
        $idPelanggan = $_POST['idPelanggan'];
        $sql = "UPDATE pelanggan SET NamaPelanggan='$nama', Alamat='$alamat', NomorTelepon='$telepon' WHERE PelangganID=$idPelanggan";
    }

    mysqli_query($conn, $sql);
    header("Location: pelanggan.php");
}

// Jika tombol "Hapus" ditekan
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE PelangganID = $id");
    header("Location: pelanggan.php");
} 

// Jika tombol "Ubah" ditekan
if (isset($_GET['edit'])) {
    $idPelanggan = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM pelanggan WHERE PelangganID = $idPelanggan");
    $data = mysqli_fetch_assoc($result);
    
    if ($data) {
        $nama = $data['NamaPelanggan'];
        $alamat = $data['Alamat'];
        $telepon = $data['NomorTelepon'];
        $editMode = true;
    }
}

// Ambil semua data pelanggan
$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #ffffff;
            color: #1e293b;
            font-family: 'Verdana', sans-serif;
            padding-bottom: 50px;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            background-color: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .table th, .table td {
            vertical-align: middle;
            color: #1e293b;
        }
        .btn {
            border-radius: 20px;
        }
        h2, h5 {
            color: #1e40af;
        }
        footer {
            background-color: #1e3a8a;
            color: #ffffff;
            text-align: center;
            padding: 1.5rem 0;
        }
        a {
            text-decoration: none;
            color: inherit;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">Data Pelanggan</h2>

    <!-- Form Tambah / Edit Pelanggan -->
    <div class="card p-4 mb-4">
        <h5 class="mb-3 text-center"><?= $editMode ? "Edit Pelanggan" : "Tambah Pelanggan" ?></h5>
        <form method="POST">
            <input type="hidden" name="idPelanggan" value="<?= $idPelanggan ?>">
            <div class="mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" value="<?= $nama ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" value="<?= $alamat ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Telepon</label>
                <input type="text" name="telepon" class="form-control" value="<?= $telepon ?>" required>
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" name="simpan" class="btn btn-primary">
                    <?= $editMode ? "Simpan Perubahan" : "Tambah" ?>
                </button>
                <?php if ($editMode) { ?>
                    <a href="pelanggan.php" class="btn btn-warning">Batal</a>
                <?php } ?>
                <a href="index.php" class="btn btn-secondary">Beranda</a>
            </div>
        </form>
    </div>

    <!-- Tabel Data Pelanggan -->
    <div class="card p-4">
        <h5 class="mb-3 text-center">Daftar Pelanggan</h5>
        <table class="table table-hover">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['PelangganID'] ?></td>
                        <td><?= $row['NamaPelanggan'] ?></td>
                        <td><?= $row['Alamat'] ?></td>
                        <td><?= $row['NomorTelepon'] ?></td>
                        <td class="text-center">
                            <a href="pelanggan.php?edit=<?= $row['PelangganID'] ?>" class="btn btn-sm btn-info">Ubah</a>
                            <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<footer>
    <p>&copy; 2025 Sistem Pengelolaan Pelanggan. Dikembangkan dengan ❤️ oleh Tim Dev.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>