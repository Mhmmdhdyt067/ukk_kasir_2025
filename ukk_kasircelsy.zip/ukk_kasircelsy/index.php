<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 50px;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 30px;
        }
        table {
            width: 60%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 20px;
            text-align: center;
            border: 1px solid #ddd;
            font-size: 18px;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        td a {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            color: white;
            background: #007bff;
            border-radius: 5px;
            font-size: 18px;
        }
        td a:hover {
            background: #0056b3;
        }
        .emoji {
            font-size: 24px;
        }
    </style>
</head>
<body>

    <h1>Dashboard Kasir celsy</h1>
    <table>
        <thead>
            <tr>
                <th>Menu</th>
                <th>Link</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><span class="emoji">👤</span> Data Pelanggan</td>
                <td><a href="pelanggan.php">Lihat Data</a></td>
            </tr>
            <tr>
                <td><span class="emoji">📦</span> Data Produk</td>
                <td><a href="produk.php">Lihat Data</a></td>
            </tr>
            <tr>
                <td><span class="emoji">💰</span> Data Penjualan</td>
                <td><a href="penjualan.php">Lihat Data</a></td>
            </tr>
            <tr>
                <td><span class="emoji">📝</span> Detail Penjualan</td>
                <td><a href="detailpenjualan.php">Lihat Data</a></td>
            </tr>
        </tbody>
    </table>

</body>
</html>
