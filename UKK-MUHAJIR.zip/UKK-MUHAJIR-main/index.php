<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Pengelolaan Basis Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0;
        }
        .navbar {
            background-color: #6c757d !important;
            padding: 15px;
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .card {
            border: none;
            background-color: #d6d8db;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .card-body i {
            font-size: 50px;
            color: #495057;
        }
        .btn-outline-secondary {
            border-color: #495057;
            color: #495057;
        }
        .btn-outline-secondary:hover {
            background-color: #495057;
            color: white;
        }
        footer {
            margin-top: 50px;
            padding: 20px;
            background: #6c757d;
            color: white;
            text-align: center;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Dashboard Admin</a>
        </div>
    </nav>

    <!-- Content -->
    <div class="container mt-5">
        <h2 class="text-center text-secondary mb-4">Aplikasi Pengelolaan Basis Data</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <i class="bi bi-people-fill"></i>
                        <h5 class="card-title mt-3">Data Pelanggan</h5>
                        <a href="pelanggan.php" class="btn btn-outline-secondary">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <i class="bi bi-box-seam"></i>
                        <h5 class="card-title mt-3">Manajemen Produk</h5>
                        <a href="produk.php" class="btn btn-outline-secondary">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <i class="bi bi-cart-check-fill"></i>
                        <h5 class="card-title mt-3">Manajemen Penjualan</h5>
                        <a href="penjualan.php" class="btn btn-outline-secondary">Lihat</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        © 2025 Aplikasi Pengelolaan Basis Data | All Rights Reserved
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</body>
</html>
