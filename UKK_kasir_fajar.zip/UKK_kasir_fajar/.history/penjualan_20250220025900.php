<?php
include 'db.php'; // Include koneksi database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Manajemen Penjualan</title>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Sistem Pengelolaan Database</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pelanggan.php">Pelanggan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="penjualan.php">Penjualan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produk.php">Produk</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h1 class="mb-4">Manajemen Penjualan</h1>
        <a href="?action=add" class="btn btn-primary mb-3">Tambah Penjualan</a>

        <?php
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tanggalPenjualan = $_POST['tanggal_penjualan'] ?? '';
            $pelangganID = $_POST['pelanggan_id'] ?? '';
            $produkID = $_POST['produk_id'] ?? '';
            $jumlahProduk = $_POST['jumlah_produk'] ?? '';

            if ($_GET['action'] === 'add') {
                // Insert penjualan
                $stmt = $conn->prepare("INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) VALUES (?, ?, 0)");
                $stmt->bind_param('si', $tanggalPenjualan, $pelangganID);
                $stmt->execute();
                $penjualanID = $stmt->insert_id;

                // Insert detail penjualan
                $stmt = $conn->prepare("INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) VALUES (?, ?, ?, 0)");
                $stmt->bind_param('iii', $penjualanID, $produkID, $jumlahProduk);
                $stmt->execute();

                // Update subtotal and total harga
                $stmt = $conn->prepare("SELECT Harga FROM produk WHERE ProdukID = ?");
                $stmt->bind_param('i', $produkID);
                $stmt->execute();
                $stmt->bind_result($harga);
                $stmt->fetch();
                $stmt->close();

                $subtotal = $harga * $jumlahProduk;

                $stmt = $conn->prepare("UPDATE detailpenjualan SET Subtotal = ? WHERE PenjualanID = ? AND ProdukID = ?");
                $stmt->bind_param('dii', $subtotal, $penjualanID, $produkID);
                $stmt->execute();

                $stmt = $conn->prepare("UPDATE penjualan SET TotalHarga = TotalHarga + ? WHERE PenjualanID = ?");
                $stmt->bind_param('di', $subtotal, $penjualanID);
                $stmt->execute();

                echo "<div class='alert alert-success'>Penjualan berhasil ditambahkan.</div>";
            }
        }

        // Handle delete penjualan
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            $id = $_GET['id'];

            // Delete detail penjualan terlebih dahulu
            $stmt = $conn->prepare("DELETE FROM detailpenjualan WHERE PenjualanID = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();

            // Delete penjualan
            $stmt = $conn->prepare("DELETE FROM penjualan WHERE PenjualanID = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();

            echo "<div class='alert alert-success'>Penjualan berhasil dihapus.</div>";
        }

        // Display penjualan data
        if (isset($_GET['action']) && ($_GET['action'] === 'add')) {
            // Form tambah penjualan


        
            ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="tanggal_penjualan" class="form-label">Tanggal Penjualan</label>
                    <input type="date" class="form-control" id="tanggal_penjualan" name="tanggal_penjualan" required>
                </div>
                <div class="mb-3">
                    <label for="pelanggan_id" class="form-label">Pelanggan</label>
                    <select class="form-control" id="pelanggan_id" name="pelanggan_id" required>
                        <option value="">Pilih Pelanggan</option>
                        <?php
                        $result = $conn->query("SELECT * FROM pelanggan");
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='{$row['PelangganID']}'>{$row['NamaPelanggan']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="produk_id" class="form-label">Produk</label>
                    <select class="form-control" id="produk_id" name="produk_id" required>
                        <option value="">Pilih Produk</option>
                        <?php
                        $result = $conn->query("SELECT * FROM produk");
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='{$row['ProdukID']}'>{$row['NamaProduk']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="jumlah_produk" class="form-label">Jumlah Produk</label>
                    <input type="number" class="form-control" id="jumlah_produk" name="jumlah_produk" required>
                </div>
                <button type="submit" class="btn btn-success">Simpan</button>
                <a href="penjualan.php" class="btn btn-secondary">Batal</a>
            </form>
            <?php
        } else {
            ?>
            <!-- Pencarian -->
            <form method="GET" class="mb-3">
            <div class="row">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Cari ID penjualan..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <a href="penjualan.php" class="btn btn-secondary">Reset</a>
                </div>
            </div>
            </form>

            <?php
        $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
        $query = "SELECT penjualan.*, pelanggan.NamaPelanggan FROM penjualan JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID";
        if (!empty($search)) {
            $query .= " WHERE penjualan.PenjualanID LIKE '%$search%'";
        }

        $result = $conn->query($query);

            echo "<table class='table table-bordered'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tanggal</th>
                        <th>Pelanggan</th>
                        <th>Total Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['PenjualanID']}</td>
                        <td>{$row['TanggalPenjualan']}</td>
                        <td>{$row['NamaPelanggan']}</td>
                        <td>{$row['TotalHarga']}</td>
                        <td>
                            <a href='detailpenjualan.php?id={$row['PenjualanID']}' class='btn btn-info btn-sm'>Detail</a>
                            <a href='?action=delete&id={$row['PenjualanID']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Apakah Anda yakin?')\">Hapus</a>
                    </tr>";
            }
            echo "</tbody>
            </table>";
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
