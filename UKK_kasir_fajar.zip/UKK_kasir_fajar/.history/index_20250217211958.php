<?php
include 'db.php'; // Include koneksi database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Dashboard</title>
</head>
<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Sistem Pengelolaan Database</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produk.php">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pelanggan.php">Pelanggan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="penjualan.php">Penjualan</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Dashboard</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card text-bg-info mb-3">
                    <div class="card-body">
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM produk";
                        $result = $conn->query($query);
                        if ($result) {
                            $data = $result->fetch_assoc();
                        }   else {
                            echo "Error: " . $conn->error;
                        }
                        ?>
                        <h5 class="card-title">Total Produk</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-success mb-3">
                    <div class="card-body">
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM pelanggan";
                        $result = $conn->query($query);
                        if ($result) {
                            $data = $result->fetch_assoc();
                        }   else {
                            echo "Error: " . $conn->error;
                        }
                        ?>
                        <h5 class="card-title">Total Pelanggan</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-warning mb-3">
                    <div class="card-body">
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM penjualan";
                        $result = $conn->query($query);
                        if ($result) {
                            $data = $result->fetch_assoc();
                        }   else {
                            echo "Error: " . $conn->error;
                        }
                        ?>
                        <h5 class="card-title">Total Penjualan</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
