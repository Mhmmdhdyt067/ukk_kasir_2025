<?php
include 'db.php';// Include koneksi database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Manajemen Produk</title>
</head>
<body>
    <!--Navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
            <a class="navbar-brand" href="#">Sistem Pengelolaan Database</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pelanggan.php">Pelanggan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="penjualan.php">Penjualan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produk.php">Produk</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h1 class="mb-4">Manajemen Produk</h1>
        <a href="?action=add" class="btn btn-primary mb-3">Tambah Produk</a>
    
        <?php
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $namaProduk = $_POST['nama_produk'] ?? '';
            $harga = $_POST['harga'] ?? '';
            $stok = $_POST['stok'] ?? '';

            if ($_GET['action'] === 'add') {
                $stmt = $conn->prepare("INSERT INTO produk (NamaProduk, Harga, Stok) VALUES (?, ?, ?)");
                $stmt->bind_param('sdi', $namaProduk, $harga, $stok);
                $stmt->execute();
                echo "<div class='alert alert-success'>Produk berhasil ditambahkan.</div>";
            } elseif ($_GET['action'] === 'edit') {
                $id = $_GET['id'];
                $stmt = $conn->prepare("UPDATE produk SET NamaProduk = ?, Harga = ?, Stok = ? WHERE ProdukID = ?");
                $stmt->bind_param('sdii', $namaProduk, $harga, $stok, $id);
                $stmt->execute();
                echo "<div class='alert alert-success'>Produk berhasil diperbarui.</div>";
            }
        }

        // Handle delete
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            $id = $_GET['id'];
            $stmt = $conn->prepare("DELETE FROM produk WHERE ProdukID = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
        
            if ($stmt->affected_rows > 0) {
                echo "<div class='alert alert-success'>Produk berhasil dihapus.</div>";
            } else {
                echo "<div class='alert alert-danger'>Gagal menghapus produk.</div>";
            }
        
            $stmt->close();
        }
        

        // Show form for add/edit
        if (isset($_GET['action']) && ($_GET['action'] === 'add' || $_GET['action'] === 'edit')) {
            $namaProduk = $harga = $stok = '';
            if ($_GET['action'] === 'edit' && isset($_GET['id'])) {
                $id = $_GET['id'];
                $result = $conn->query("SELECT * FROM produk WHERE ProdukID = $id");
                $data = $result->fetch_assoc();
                $namaProduk = $data['NamaProduk'];
                $harga = $data['Harga'];
                $stok = $data['Stok'];
            }
            ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="nama_produk" class="form-label">Nama Produk</label>
                    <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?php echo $namaProduk; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga</label>
                    <input type="number" step="0.01" class="form-control" id="harga" name="harga" value="<?php echo $harga; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="stok" class="form-label">Stok</label>
                    <input type="number" class="form-control" id="stok" name="stok" value="<?php echo $stok; ?>" required>
                </div>
                <button type="submit" class="btn btn-success">Simpan</button>
                <a href="produk.php" class="btn btn-secondary">Batal</a>
            </form>
            <?php
        } else {
            ?>
            <!-- Pencarian -->
            <form method="GET" class="mb-3">
            <div class="row">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama produk..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <a href="produk.php" class="btn btn-secondary">Reset</a>
                </div>
            </div>
            </form>

            <?php
            $search = isset($_GET['search']) ? $_GET['search'] : '';
            $query = "SELECT * FROM produk WHERE NamaProduk LIKE '%$search%'";
            $result = $conn->query($query);
            // Display produk data
            echo "<table class='table table-bordered'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['ProdukID']}</td>
                        <td>{$row['NamaProduk']}</td>
                        <td>{$row['Harga']}</td>
                        <td>{$row['Stok']}</td>
                        <td>
                            <a href='?action=edit&id={$row['ProdukID']}' class='btn btn-warning btn-sm'>Edit</a>
<a href='?action=delete&id={$row['ProdukID']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Apakah Anda yakin?')\">Hapus</a>

                        </td>
                    </tr>";
            }
            echo "</tbody>
            </table>";
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
</body>
</html>