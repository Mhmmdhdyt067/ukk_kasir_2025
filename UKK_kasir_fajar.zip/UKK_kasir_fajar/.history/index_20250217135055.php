<?php
include 'db.php'; // Include koneksi database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card-custom {
            border-radius: 10px;
            padding: 20px;
            color: white;
        }
        .bg-blue { background-color: #007bff; }
        .bg-green { background-color: #28a745; }
        .bg-yellow { background-color: #ffc107; color: black; }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Sistem Pengelolaan Database</a>
        </div>
    </nav>
    <div class="container mt-4">
        <h2 class="mb-4">Dashboard</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card card-custom bg-blue">
                    <h5>Total Produk</h5>
                    <h3>3</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-custom bg-green">
                    <h5>Total Pelanggan</h5>
                    <h3>3</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-custom bg-yellow">
                    <h5>Total Penjualan</h5>
                    <h3>3</h3>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

    <div class="container mt-5">
        <h1 class="mb-4">Dashboard</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card text-bg-primary mb-3">
                    <div class="card-body">
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM produk";
                        $result = $conn->query($query);
                        if ($result) {
                            $data = $result->fetch_assoc();
                        }   else {
                            echo "Error: " . $conn->error;
                        }

                        ?>
                        <h5 class="card-title">Total Produk</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-success mb-3">
                    <div class="card-body">
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM pelanggan";
                        $result = $conn->query($query);
                        if ($result) {
                            $data = $result->fetch_assoc();
                        }   else {
                            echo "Error: " . $conn->error;
                        }
                        ?>
                        <h5 class="card-title">Total Pelanggan</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-warning mb-3">
                    <div class="card-body">
                        <?php
                        $query = "SELECT COUNT(*) AS total FROM penjualan";
                        $result = $conn->query($query);
                        if ($result) {
                            $data = $result->fetch_assoc();
                        }   else {
                            echo "Error: " . $conn->error;
                        }
                        ?>
                        <h5 class="card-title">Total Penjualan</h5>
                        <p class="card-text fs-3"><?php echo $data['total']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
