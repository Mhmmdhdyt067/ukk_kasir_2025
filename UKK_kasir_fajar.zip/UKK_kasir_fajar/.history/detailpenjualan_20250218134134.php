<?php
include 'db.php'; // Include koneksi database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Detail Penjualan</title>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Sistem Pengelolaan Database</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produk.php">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pelanggan.php">Pelanggan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="penjualan.php">Penjualan</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="mb-4">Detail Penjualan</h1>
        <a href="penjualan.php" class="btn btn-secondary mb-3">Kembali ke Penjualan</a>

        <?php
        if (isset($_GET['id'])) {
            $penjualanID = $_GET['id'];

            // Ambil detail penjualan
            $result = $conn->query("SELECT penjualan.TanggalPenjualan, penjualan.TotalHarga, pelanggan.NamaPelanggan FROM penjualan JOIN pelanggan ON penjualan.PelangganID = pelanggan.PelangganID WHERE penjualan.PenjualanID = $penjualanID");
            $penjualan = $result->fetch_assoc();

            if ($penjualan) {
                echo "<div class='mb-3'>
                        <strong>Tanggal Penjualan:</strong> {$penjualan['TanggalPenjualan']}<br>
                        <strong>Pelanggan:</strong> {$penjualan['NamaPelanggan']}<br>
                        <strong>Total Harga:</strong> Rp" . number_format($penjualan['TotalHarga'], 2, ',', '.') . "
                    </div>";

                // Ambil data detail penjualan
                $result = $conn->query("SELECT detailpenjualan.*, produk.NamaProduk, produk.Harga FROM detailpenjualan JOIN produk ON detailpenjualan.ProdukID = produk.ProdukID WHERE detailpenjualan.PenjualanID = $penjualanID");

                echo "<table class='table table-bordered'>
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['NamaProduk']}</td>
                            <td>Rp" . number_format($row['Harga'], 2, ',', '.') . "</td>
                            <td>{$row['JumlahProduk']}</td>
                            <td>Rp" . number_format($row['Subtotal'], 2, ',', '.') . "</td>
                        </tr>";
                }

                echo "</tbody>
                </table>";
            } else {
                echo "<div class='alert alert-danger'>Detail penjualan tidak ditemukan.</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>ID penjualan tidak valid.</div>";
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
