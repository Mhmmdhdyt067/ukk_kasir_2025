<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    $sql = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) 
            VALUES ('$nama', '$alamat', '$telepon')";
    mysqli_query($conn, $sql);
    header("Location: pelanggan.php");
    exit();
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pelanggan WHERE PelangganID = $id");
    header("Location: pelanggan.php");
    exit();
}

// Ambil Data
$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan 💖</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffe5e5; /* Merah muda pastel */
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #8b0000; /* Merah gelap untuk teks */
        }

        h2 {
            color: #dc143c; /* Crimson */
            text-align: center;
            margin-top: 20px;
            font-size: 2em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container {
            width: 85%;
            max-width: 900px;
            margin: 30px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
            border-radius: 15px;
            flex: 1;
        }

        form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        label {
            display: block;
            width: 100%;
            margin-bottom: 5px;
            color: #8b0000;
        }

        input[type="text"] {
            width: calc(50% - 10px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #dc143c;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #c70039;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #f0f0f0;
            background-color: #fff0f0; /* Merah muda pucat */
            color: #8b0000;
        }

        th {
            background-color: #ffe0e0;
            font-weight: 600;
        }

        tr:hover {
            background-color: #ffd0d0;
        }

        .emoji {
            font-size: 1.1em;
            vertical-align: middle;
        }

        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            input[type="text"] {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Data Pelanggan 💖</h2>
        <form method="POST">
            <label for="nama">Nama <span class="emoji">😊</span>:</label>
            <input type="text" name="nama" id="nama" placeholder="Nama" required>
            <label for="alamat">Alamat <span class="emoji">🏠</span>:</label>
            <input type="text" name="alamat" id="alamat" placeholder="Alamat" required>
            <label for="telepon">Telepon <span class="emoji">📞</span>:</label>
            <input type="text" name="telepon" id="telepon" placeholder="Telepon" required>
            <button type="submit" name="tambah">Tambah <span class="emoji">➕</span></button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID <span class="emoji">#</span></th>
                    <th>Nama <span class="emoji">😊</span></th>
                    <th>Alamat <span class="emoji">🏠</span></th>
                    <th>Telepon <span class="emoji">📞</span></th>
                    <th>Aksi <span class="emoji">⚙️</span></th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['PelangganID'] ?></td>
                        <td><?= $row['NamaPelanggan'] ?></td>
                        <td><?= $row['Alamat'] ?></td>
                        <td><?= $row['NomorTelepon'] ?></td>
                        <td>
                            <a href="pelanggan.php?hapus=<?= $row['PelangganID'] ?>" onclick="return confirm('Yakin hapus?')">
                            <span class="emoji">❌</span> Hapus
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>