<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir ️</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffe5e5; /* Pink pastel */
            color: #8b0000; /* Merah gelap untuk teks */
            margin: 0;
            padding: 0;
            height: 100vh; /* Pastikan halaman menggunakan 100% tinggi layar */
            display: flex;
            justify-content: center; /* Posisi horizontal tengah */
            align-items: center; /* Posisi vertikal tengah */
            text-align: center;
        }

        .container {
            padding: 50px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 80%;
            max-width: 800px;
        }

        h1 {
            color: #dc143c; /* Crimson */
            margin-bottom: 20px;
            font-size: 2em;
        }

        a {
            display: inline-block;
            margin: 10px;
            padding: 12px 18px;
            width: auto;
            text-decoration: none;
            color: white;
            background: linear-gradient(to right, #ff69b4, #c71585); /* Pink cerah ke magenta */
            border-radius: 20px; /* Border radius lebih besar */
            font-size: 14px; /* Ukuran font lebih kecil */
            transition: background 0.3s ease;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
        }

        a:hover {
            background: linear-gradient(to right, #c71585, #ff69b4); /* Magenta ke pink cerah */
        }

        table {
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1);
            border-radius: 15px; /* Border radius tabel */
            overflow: hidden;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0f0f0;
            background-color: #fff0f0; /* Pink muda untuk sel */
            color: #8b0000; /* Merah gelap untuk teks sel */
        }

        th {
            background-color: #ffe0e0; /* Pink lebih muda untuk header */
            font-weight: 600;
        }

        tr:hover {
            background-color: #ffd0d0; /* Pink lebih muda saat hover */
        }

        .emoji {
            font-size: 1.2em; /* Ukuran emoji disesuaikan */
            vertical-align: middle;
        }
    </style>
</head>

<body>

    <div class="container">
        <h1>Dashboard Kasir <span class="emoji">️</span></h1>
        <a href="pelanggan.php">Data Pelanggan <span class="emoji">👥</span></a>
        <a href="produk.php">Data Produk <span class="emoji">🛍️</span></a>
        <a href="penjualan.php">Data Penjualan <span class="emoji">💸</span></a>
        <a href="detailpenjualan.php">Detail Penjualan <span class="emoji">📝</span></a>

        <!-- Tabel Keren dengan Emoji -->
        <table>
            <tr>
                <th>Emoji</th>
                <th>Deskripsi</th>
            </tr>
            <tr>
                <td>🛒</td>
                <td>Keranjang Belanja - Simbol belanja online yang penuh dengan produk</td>
            </tr>
            <tr>
                <td>💳</td>
                <td>Kartu Pembayaran - Alat untuk melakukan transaksi pembayaran</td>
            </tr>
            <tr>
                <td>💸</td>
                <td>Uang yang Dibayarkan - Representasi uang yang keluar dari kasir</td>
            </tr>
            <tr>
                <td>👥</td>
                <td>Data Pelanggan - Menyimpan informasi pelanggan yang berbelanja</td>
            </tr>
            <tr>
                <td>🛍️</td>
                <td>Produk yang Dijual - Menandakan barang yang tersedia di toko</td>
            </tr>
            <tr>
                <td>📝</td>
                <td>Detail Transaksi - Catatan detail tentang transaksi yang terjadi</td>
            </tr>
        </table>
    </div>

</body>

</html>
