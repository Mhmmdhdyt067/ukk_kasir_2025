<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $TotalHarga = $_POST['TotalHarga'];
    $sql = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) VALUES ('$tanggal', '$pelangganID', $TotalHarga)";
    mysqli_query($conn, $sql);
    header("Location: penjualan.php");
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM penjualan");
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan 💖</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #ffe5e5; /* Merah muda pastel */
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #8b0000; /* Merah gelap untuk teks */
        }

        h2 {
            color: #dc143c; /* Crimson */
            text-align: center;
            margin-top: 20px;
            font-size: 2em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container {
            width: 85%;
            max-width: 900px;
            margin: 30px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
            border-radius: 15px;
            flex: 1;
        }

        form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        label {
            display: block;
            width: 100%;
            margin-bottom: 5px;
            color: #8b0000;
        }

        input[type="date"],
        select,
        input[type="number"] {
            width: calc(50% - 10px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #dc143c;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #c70039;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #f0f0f0;
            background-color: #fff0f0; /* Merah muda pucat */
            color: #8b0000;
        }

        th {
            background-color: #ffe0e0; /* Merah muda lebih pucat */
            font-weight: 600;
        }

        tr:hover {
            background-color: #ffd0d0; /* Merah muda lebih pucat */
        }

        .emoji {
            font-size: 1.1em;
            vertical-align: middle;
        }

        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            input[type="date"],
            select,
            input[type="number"] {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Data Penjualan 💖</h2>
        <form method="POST">
            <label for="tanggal">Tanggal <span class="emoji">📅</span>:</label>
            <input type="date" name="tanggal" id="tanggal" required>

            <label for="pelanggan">Pelanggan <span class="emoji">😊</span>:</label>
            <select name="pelangganID" id="pelanggan">
                <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                    <option value="<?= $row['PelangganID'] ?>"><?= $row['NamaPelanggan'] ?></option>
                <?php } ?>
            </select>

            <label for="TotalHarga">Total Harga <span class="emoji">💰</span>:</label>
            <input type="number" name="TotalHarga" id="TotalHarga" required>

            <button type="submit" name="tambah">Tambah <span class="emoji">➕</span></button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID <span class="emoji">#</span></th>
                    <th>Tanggal <span class="emoji">📅</span></th>
                    <th>Pelanggan <span class="emoji">😊</span></th>
                    <th>Total Harga <span class="emoji">💰</span></th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['PenjualanID'] ?></td>
                        <td><?= $row['TanggalPenjualan'] ?></td>
                        <td><?= $row['PelangganID'] ?></td>
                        <td>Rp <?= number_format($row['TotalHarga'], 2) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>