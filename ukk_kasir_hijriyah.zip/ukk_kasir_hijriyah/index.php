<?php
include 'koneksi.php';

// Hitung total produk
$query_produk = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM produk");
$total_produk = mysqli_fetch_assoc($query_produk)['total'];

// Hitung total pelanggan
$query_pelanggan = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM pelanggan");
$total_pelanggan = mysqli_fetch_assoc($query_pelanggan)['total'];

// Hitung total penjualan
$query_penjualan = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM penjualan");
$total_penjualan = mysqli_fetch_assoc($query_penjualan)['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <h2>Sistem Pengelolaan Database</h2>
        <ul>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="pelanggan.php">Pelanggan</a></li>
            <li><a href="penjualan.php">Penjualan</a></li>
            <li><a href="penjualan.php">Detail Penjualan</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <h1>Dashboard</h1>
        <div class="dashboard">
            <div class="card blue">
                <h3>Total Produk</h3>
                <p><?php echo $total_produk; ?></p>
            </div>
            <div class="card green">
                <h3>Total Pelanggan</h3>
                <p><?php echo $total_pelanggan; ?></p>
            </div>
            <div class="card yellow">
                <h3>Total Penjualan</h3>
                <p><?php echo $total_penjualan; ?></p>
            </div>
        </div>
    </div>
</body>
</html>