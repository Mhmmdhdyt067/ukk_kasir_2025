<?php
include 'koneksi.php';

// Hapus penjualan jika ada request
if (isset($_GET['hapus'])) {
    $id_penjualan = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM penjualan WHERE id_penjualan='$id_penjualan'");
    echo "<script>alert('Penjualan berhasil dihapus!'); window.location='penjualan.php';</script>";
}

// Tambah penjualan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_penjualan = $_POST['id_penjualan'];
    $id_pelanggan = $_POST['id_pelanggan'];
    $tanggal = $_POST['tanggal'];
    $total = $_POST['total'];

    mysqli_query($koneksi, "INSERT INTO penjualan (id_penjualan, id_pelanggan, tanggal, total) VALUES ('$id_penjualan', '$id_pelanggan', '$tanggal','$total')");
    echo "<script>alert('Penjualan berhasil ditambahkan!'); window.location='detail_penjualan.php';</script>";
}

// Ambil data penjualan
$result = mysqli_query($koneksi, "SELECT * FROM penjualan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Data Penjualan</h1>
    <form method="POST">
        <input type="text" name="id_penjualan" placeholder="Id_penjualan" required>
        <input type="text" name="id_pelanggan" placeholder="Id_pelanggan" required>
        <input type="text" name="tanggal" placeholder="Tanggal" required>
        <input type="text" name="total" placeholder="Total" required>
        <button type="submit">Tambah Penjualan</button>
    </form>
    <table border="1">
        <tr>
            <th>Id_penjualan</th>
            <th>Id_Pelanggan</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['id_penjualan']; ?></td>
                <td><?php echo $row['id_pelanggan']; ?></td>
                <td><?php echo $row['tanggal']; ?></td>
                <td><?php echo $row['total']; ?></td>
                <td>
                    <a href="penjualan.php?hapus=<?php echo $row['id_penjualan']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>