<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Pengelolaan Basis Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> <!-- Font Awesome for icons -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .navbar {
            background-color:hsl(197, 94.10%, 46.70%);
            box-shadow: 0 4px 12px rgba(6, 160, 248, 0.1);
        }
        .navbar h2 {
            font-weight: bold;
            font-size: 28px;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color:rgb(11, 164, 224);
            padding-top: 30px;
            padding-left: 10px;
            box-shadow: 2px 0px 8px rgba(242, 248, 246, 0.93);
        }
        .sidebar a {
            display: block;
            color: #d1d1d1;
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .sidebar a:hover {
            background-color:rgb(57, 169, 243);
            color: white;
        }
        .content {
            margin-left: 270px;
            padding: 30px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 6px 18px rgba(14, 55, 241, 0.89);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 30px;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        .card-body {
            padding: 30px;
            background: #ffffff;
        }
        .card-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .btn-success {
            background-color:rgb(0, 217, 255);
            border-color: #007bff;
            padding: 15px 30px;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }
        .btn-success:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .header-section {
            background: linear-gradient(to right,rgb(0, 255, 234),rgb(68, 5, 241));
            color: white;
            padding: 40px 0;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .header-section h2 {
            font-size: 40px;
            font-weight: bold;
        }
        .row {
            display: flex;
            justify-content: space-between;
        }
        .col-md-4 {
            padding: 10px;
        }
        .tooltip-inner {
            background-color: #007bff;
            color: white;
            font-size: 14px;
        }
        .tooltip-arrow {
            border-top-color: #007bff;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h4 class="text-white text-center mb-4">Menu Admin</h4>
        <a href="pelanggan.php" data-bs-toggle="tooltip" data-bs-placement="right" title="Lihat data pelanggan">
            <i class="fas fa-users"></i> Data Pelanggan
        </a>
        <a href="produk.php" data-bs-toggle="tooltip" data-bs-placement="right" title="Manajemen produk dan stok">
            <i class="fas fa-box"></i> Manajemen Produk
        </a>
        <a href="penjualan.php" data-bs-toggle="tooltip" data-bs-placement="right" title="Manajemen transaksi penjualan">
            <i class="fas fa-dollar-sign"></i> Manajemen Penjualan
        </a>
    </div>

    <div class="content">
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container d-flex justify-content-center">
                <div class="card-header text-center">
                    <h2>Dashboard Admin</h2>
                </div>
            </div>
        </nav>

        <div class="container mt-5">
            <div class="header-section text-center mb-5">
                <h2>Aplikasi Pengelolaan Basis Data</h2>
                <p class="lead">Pengelolaan Data Pelanggan, Produk, dan Penjualan Anda dalam Satu Tempat</p>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="card" data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat data pelanggan">
                        <div class="card-body text-center">
                            <h5 class="card-title">Data Pelanggan</h5>
                            <a href="pelanggan.php" class="btn btn-success">
                                <i class="fas fa-users"></i> Lihat
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card" data-bs-toggle="tooltip" data-bs-placement="top" title="Manajemen produk dan stok">
                        <div class="card-body text-center">
                            <h5 class="card-title">Manajemen Produk</h5>
                            <a href="produk.php" class="btn btn-success">
                                <i class="fas fa-box"></i> Lihat
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card" data-bs-toggle="tooltip" data-bs-placement="top" title="Manajemen transaksi penjualan">
                        <div class="card-body text-center">
                            <h5 class="card-title">Manajemen Penjualan</h5>
                            <a href="penjualan.php" class="btn btn-success">
                                <i class="fas fa-dollar-sign"></i> Lihat
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tooltips
        var tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        var tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    </script>
</body>
</html>
