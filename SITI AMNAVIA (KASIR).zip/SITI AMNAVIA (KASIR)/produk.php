<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $sql = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES ('$nama', '$harga', '$stok')";
    mysqli_query($conn, $sql);
}

$result = mysqli_query($conn, "SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk</title>
    <style>
        /* Mengubah warna latar belakang halaman */
        body {
            background-color: #f8c8d9; /* Warna latar belakang pink muda */
            color: #d1006e; /* Warna teks utama (merah muda) */
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h2 {
            color: #d1006e; /* Warna judul */
        }

        /* Mengatur tampilan form */
        form {
            background-color: #f2e6f5; /* Warna latar belakang form */
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #d1006e;
            border-radius: 4px;
        }

        button {
            background-color: #d1006e; /* Warna tombol */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #b0005a; /* Warna tombol saat hover */
        }

        /* Mengatur tampilan tabel */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #d1006e;
        }

        table th {
            background-color: #f2e6f5; /* Warna latar belakang tabel */
        }

        table td {
            background-color: #fff;
        }
    </style>
</head>
<body>

    <h2>Data Produk</h2>

    <form method="POST">
        <label>Nama Produk:</label>
        <input type="text" name="nama" required>
        <label>Harga:</label>
        <input type="number" name="harga" required>
        <label>Stok:</label>
        <input type="number" name="stok" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['produkID'] ?></td>
                <td><?= $row['namaProduk'] ?></td>
                <td>Rp <?= number_format($row['harga'], 2) ?></td>
                <td><?= $row['stok'] ?></td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>
