<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kasir 🛍️</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #fff0f5;
            padding: 50px;
        }
        h1 {
            color: #ff1493;
        }
        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
            background-color: #ffebf7;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        th, td {
            padding: 15px;
            border: 1px solid #ff69b4;
            text-align: center;
        }
        th {
            background-color: #ff1493;
            color: white;
        }
        td a {
            display: inline-block;
            padding: 10px 15px;
            text-decoration: none;
            color: white;
            background: #ff69b4;
            border-radius: 5px;
            font-size: 16px;
        }
        td a:hover {
            background: #ff1493;
        }
    </style>
</head>
<body>

    <h1>🎀 Dashboard Kasir 🎀</h1>
    <table>
        <tr>
            <th>📋 Menu</th>
            <th>🔗 Aksi</th>
        </tr>
        <tr>
            <td>👥 Data Pelanggan</td>
            <td><a href="pelanggan.php">Lihat</a></td>
        </tr>
        <tr>
            <td>📦 Data Produk</td>
            <td><a href="produk.php">Lihat</a></td>
        </tr>
        <tr>
            <td>💰 Data Penjualan</td>
            <td><a href="penjualan.php">Lihat</a></td>
        </tr>
        <tr>
            <td>📝 Detail Penjualan</td>
            <td><a href="detail_penjualan.php">Lihat</a></td>
        </tr>
    </table>

</body>
</html>
