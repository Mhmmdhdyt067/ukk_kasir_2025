<?php
include "koneksi.php";

// Tambah Data
if (isset($_POST['tambah'])) {
    $penjualanID = intval($_POST['penjualanID']);
    $produkID = intval($_POST['produkID']);
    $jumlahProduk = intval($_POST['jumlahProduk']);

    // Pastikan ID tidak kosong
    if ($penjualanID == 0 || $produkID == 0 || $jumlahProduk <= 0) {
        echo "<script>alert('Data tidak valid!');</script>";
    } else {
        // Ambil harga dan stok produk
        $queryHarga = mysqli_query($conn, "SELECT harga, stok FROM produk WHERE produkID = '$produkID'");
        $row = mysqli_fetch_assoc($queryHarga);
        
        if ($row) {
            $harga = $row['harga'];
            $stok = $row['stok'];
            
            // Pastikan stok mencukupi sebelum menambahkan transaksi
            if ($stok >= $jumlahProduk) {
                $subtotal = $harga * $jumlahProduk;

                // Insert ke detailpenjualan
                $sql = "INSERT INTO detailpenjualan (penjualanID, produkID, jumlahProduk, subtotal) 
                        VALUES ('$penjualanID', '$produkID', '$jumlahProduk', '$subtotal')";
                mysqli_query($conn, $sql);

                // Kurangi stok produk
                $updateStok = "UPDATE produk SET stok = stok - $jumlahProduk WHERE produkID = '$produkID'";
                mysqli_query($conn, $updateStok);
            } else {
                echo "<script>alert('Stok tidak mencukupi!');</script>";
            }
        } else {
            echo "<script>alert('Produk tidak ditemukan!');</script>";
        }
    }
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    
    // Ambil data sebelum menghapus untuk mengembalikan stok
    $queryDetail = mysqli_query($conn, "SELECT * FROM detailpenjualan WHERE detailID = '$id'");
    $row = mysqli_fetch_assoc($queryDetail);
    
    if ($row) {
        $produkID = $row['produkID'];
        $jumlahProduk = $row['jumlahProduk'];

        // Kembalikan stok produk
        $updateStok = "UPDATE produk SET stok = stok + $jumlahProduk WHERE produkID = '$produkID'";
        mysqli_query($conn, $updateStok);

        // Hapus data dari tabel detailpenjualan
        mysqli_query($conn, "DELETE FROM detailpenjualan WHERE detailID = '$id'");
    }
}

// Ambil Data
$dataQuery = "SELECT detailpenjualan.*, produk.namaProduk, penjualan.tanggalPenjualan 
              FROM detailpenjualan
              JOIN produk ON detailpenjualan.produkID = produk.produkID
              JOIN penjualan ON detailpenjualan.penjualanID = penjualan.penjualanID";
$result = mysqli_query($conn, $dataQuery);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Data Detail Penjualan</h2>
    
    <form method="POST">
        <label>Penjualan:</label>
        <select name="penjualanID" required>
            <option value="">Pilih Penjualan</option>
            <?php
            $penjualan = mysqli_query($conn, "SELECT * FROM penjualan");
            while ($row = mysqli_fetch_assoc($penjualan)) {
                echo "<option value='{$row['penjualanID']}'>ID {$row['penjualanID']} - {$row['tanggalPenjualan']}</option>";
            }
            ?>
        </select>

        <label>Produk:</label>
        <select name="produkID" required>
            <option value="">Pilih Produk</option>
            <?php
            $produk = mysqli_query($conn, "SELECT * FROM produk");
            while ($row = mysqli_fetch_assoc($produk)) {
                echo "<option value='{$row['produkID']}'>{$row['namaProduk']} - Stok: {$row['stok']} - Rp. {$row['harga']}</option>";
            }
            ?>
        </select>

        <label>Jumlah Produk:</label>
        <input type="number" name="jumlahProduk" required>

        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Penjualan ID</th>
            <th>Produk</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['detailID'] ?></td>
                <td><?= $row['penjualanID'] ?> - <?= $row['tanggalPenjualan'] ?></td>
                <td><?= $row['namaProduk'] ?></td>
                <td><?= $row['JumlahProduk'] ?></td>
                <td>Rp. <?= number_format($row['subtotal'], 2, ',', '.') ?></td>
                <td>
                    <a href="detailpenjualan.php?hapus=<?= $row['detailID'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>