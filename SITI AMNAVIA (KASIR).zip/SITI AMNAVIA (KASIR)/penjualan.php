<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $pelangganID = $_POST['pelangganID'];
    $TotalHarga = $_POST['TotalHarga'];
    $sql = "INSERT INTO penjualan (TanggalPenjualan, PelangganID, TotalHarga) VALUES ('$tanggal', '$pelangganID', $TotalHarga)";
    mysqli_query($conn, $sql);
}

$result = mysqli_query($conn, "SELECT * FROM penjualan");
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penjualan</title>
    <style>
        <?php include "style.css"; ?>
    </style>
</head>
<body>

    <h2>Data Penjualan</h2>

    <form method="POST">
        <label>Tanggal:</label>
        <input type="date" name="tanggal" required>
        <label>Pelanggan:</label>
        <select name="pelangganID">
            <?php while ($row = mysqli_fetch_assoc($pelanggan)) { ?>
                <option value="<?= $row['pelangganID'] ?>"><?= $row['namaPelanggan'] ?></option>
            <?php } ?>
        </select>

        <label>Total Harga:</label>
        <input type="number" name="TotalHarga" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Total Harga</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['penjualanID'] ?></td>
                <td><?= $row['tanggalPenjualan'] ?></td>
                <td><?= $row['pelangganID'] ?></td>
                <td>Rp <?= number_format($row['totalHarga'], 2) ?></td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>